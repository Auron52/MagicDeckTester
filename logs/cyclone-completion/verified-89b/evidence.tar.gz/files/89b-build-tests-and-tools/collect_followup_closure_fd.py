#!/usr/bin/env python3
"""Engine-free immutable addendum to the pre-strict mechanical audit."""
import datetime, hashlib, json, pathlib, re, subprocess, os
P=pathlib.Path(__file__).resolve().parent
W=pathlib.Path('/workspaces/MagicDeckTester/.claude/worktrees/cyclone-landing905')
A=P/'followup-normal-regression'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(pathlib.Path(p).read_text())
def rec(p): return {'path':str(p),'sha256':sha(p)}
def row(p,gi):
 rows=[s.strip() for s in p.read_text().splitlines() if s.strip() and not s.startswith('#') and s.split()[0]==str(gi)]
 assert len(rows)==1,(p,gi,rows)
 return rows[0]
def git(*args): return subprocess.check_output(['git','-C',str(W),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
status=load(A/'status.json');audit=load(A/'audit/audit.json');log=(A/'harness.log').read_text()
assert status['status']=='CLOSED' and status['returncode']==1
assert status['source_tree']=='89b146d10406063213d9abe41e1cfdf1a616c021'
assert status['binary_sha256']=='20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80'
assert sha(A/'harness.log')==status['log_sha256']
assert re.search(r'Result: 246 passed, 7 failed, 0 new',log)
strict=next(s for s in log.splitlines() if s.startswith('Viewer protocol:'))
assert strict=='Viewer protocol: 266 ok, 442 repaired, 1 beaten, 0 play-drift, 0 shuffle-dead, 0 board-diverged, 0 enum-gap, 0 mull-drift, 0 contract-fail  (709 refs)'
assert 'REQUIRE-BEAT: all 2 game(s) strictly beaten by the search' in log
assert audit['jobs']==253 and audit['games']==72413 and audit['requested_games']==72414
assert audit['diagnostic_counts']=={'fd':3,'nonconv':0,'counter_overflow':0}
old=load(P/'fd-three-exact-2c-postrun-review.json');bridge=load(P/'regression-exact-controls/assets-bridge.json')
newjobs={j['name']:j for j in load(A/'audit/manifest.json')['jobs']}
oldjobs={j['name']:j for j in load(P/'regression-exact-controls/current-manifest.json')['jobs']}
comparison={x['control']:x for x in load(P/'regression-exact-controls/comparison.json')['cases']}
results=[]; assets={}
for o in old['observations']:
 key=o['source_job'];gi=o['global_gi'];j=newjobs[key];oj=oldjobs[f'{key}_exact_gi{gi}']
 projection=dict(j);projection.update(name=oj['name'],games=1,seed=j['seed']+gi,game_index=gi)
 weight_difference={'new':projection.pop('weight',None),'old':oj.get('weight')}
 compare_old={k:v for k,v in oj.items() if k!='weight'}
 assert projection==compare_old, (key,projection,compare_old)
 freshdiag=[x for x in audit['diagnostic_attention'] if f'job={key} ' in x['text']];assert len(freshdiag)==1
 fields=dict(re.findall(r'(\w+)=([^ ]+)',freshdiag[0]['text']))
 assert fields['gi']==str(gi) and fields['blind_salt']=='-1'
 assert all(fields[k]==v for k,v in o['exact_forecast_tuple'].items())
 wins=W/'test/logs/regression/wins'/f'{key}.wins';units=wins.with_suffix('.units')
 wr=row(wins,gi);u=int(row(units,gi).split()[1]);assert wr==o['wins_digest_row'] and u==o['units']
 c=comparison[oj['name']]
 assert c['current']['wins_row']==wr==c['baseline']['wins_row']
 assert c['current']['units']==u==c['baseline']['units']
 deckparent=str((W/j['deck']).parent)+'/'
 relevant={k:v for k,v in bridge['asset_sha256']['current'].items() if k.startswith(deckparent) or k.endswith('/src/cards/data/cards.json')}
 assert relevant and str(W/j['deck']) in relevant and str(W/j['profile']) in relevant
 for f,h in relevant.items():
  fp=pathlib.Path(f);assert sha(fp)==h,(f,'asset changed')
  rel=str(fp.relative_to(W));assert hashlib.sha256(git('show',f'dfcb18cb90ae65aeb4968787550a10b1fb9bc55e:{rel}')).hexdigest()==h
  assets[rel]=h
 results.append({'source_job':key,'global_gi':gi,'actual_seed':int(fields['seed']),
   'new89b_forecast':freshdiag[0], 'exact_tuple_matches_old_C2_and_upstream_control':True,
   'new89b_wins_row':wr,'new89b_units':u,'new89b_files':{'wins':rec(wins),'units':rec(units)},
   'singleton_simulation_fields_equal':True,'scheduling_weight':weight_difference,'new_job':j,'old_singleton_job':oj,
   'old_source_context':{'source_trees':old['source_trees'],'binary_sha256':old['binary_sha256'],
    'old_C2_fulltrace':o['current_fulltrace'],'old_upstream_fulltrace':o['baseline_fulltrace'],
    'old_physical_traces_equal':o['exact_trace_equal_excluding_only_run_labels']},
   'new89b_fulltrace_captured':False,
   'classification':'EXACT_OBSERVED_FORECAST_OUTCOME_DIGEST_UNITS_MATCH_PREEXISTING_CONTROL',
   'limit':'New measured rows/diagnostics only. Historical physical traces are old source context; no new fulltrace equality or defect repair is claimed.'})
omission=next(x for x in audit['cases'] if x['key']=='melira_regression_d5_s30001')
assert omission['games']==19 and omission['requested_games']==20 and omission['baseline_equal_abandoned_gis']==[11]
err=(A/'audit/batch.err').read_text();witness=next(s for s in err.splitlines() if 'ABANDONED job=melira_regression_d5_s30001 gi=11 ' in s)
assert 'units=2000000 limit=2000000 cause=UNITS' in witness
out={'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'CLOSED_MECHANICAL_REVIEW_NOT_ACCEPTED','engine_build_model_calls':0,
 'source_tree':status['source_tree'],'binary_sha256':status['binary_sha256'],'baseline_commit':audit['baseline_commit'],
 'raw_receipts':{'status':rec(A/'status.json'),'harness':rec(A/'harness.log'),'mechanical_audit_preserved':rec(A/'audit/audit.json'),'old_FD_receipt':rec(P/'fd-three-exact-2c-postrun-review.json'),'old_control_comparison':rec(P/'regression-exact-controls/comparison.json')},
 'harness':{'actual_returncode':1,'actual_finished':status['finished'],'passed':246,'failed':7,'new':0,'strict_raw_summary':strict,'suboptimal_games_strictly_beaten':2,'strict_gate_pass':True,'overall_pass_claimed':False},
 'batch':{'jobs':253,'actual_games':72413,'requested_games':72414,'tallies':audit['tallies'],'changed':audit['changed'],'diagnostics':audit['diagnostic_counts']},
 'bounded_omission':{'case':omission,'raw_witness':witness,'interpretation':'Same accepted baseline absent GI; not filled or fabricated.'},
 'FD_observations':results,'actual_asset_hashes_equal_old_C2_bridge_and_latest_dfcb_baseline':assets,
 'environment_bridge':{'both_threads':32,'both_observation_flags':{'MTG_FD_ORACLE':'1','MTG_FLAG_NONCONV':'1','MTG_DUMP_UNITS':'1'},'old_extra_observation':'MTG_SLOW_GAME_MS=1','mode':'ordinary; no positive job blind salt, new raw blind_salt=-1; legacy baseline omitted field'},
 'scope':'No acceptance, GT edits, engine runs or new physical traces. Seven changed searched rows remain under separate controls/legality/recovery review. Pending-at-collection audit remains byte-preserved; this addendum records actual later closure.'}
path=A/'closure-fd-review.json'
with path.open('x') as f: json.dump(out,f,indent=2);f.write('\n')
print(path);print('FD exact matches',len(results),'assets',len(assets),'rc',status['returncode'])
