#!/usr/bin/env python3
"""Root-owned standard filtered smoke; preparation-only unless --run is explicit."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
HERE=Path(__file__).resolve().parent
ROOT=Path('/workspaces/MagicDeckTester/.claude/worktrees/cyclone-landing905')
INPUTS=HERE.parent/'v7-905-lean/prepared-89b146d-final'
sys.path.insert(0,str(INPUTS/'helpers'))
import v6_common as c
SOURCE='89b146d10406063213d9abe41e1cfdf1a616c021'
PGO='20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80'
BINARY=ROOT/'build/PGO/mtg'
OLD=HERE/'followup-release-smoke/measured-smoke-files'
OUT=HERE/'followup-artifact-smoke'
DECKS='pd,pd2hg,slivers,slivers2hg'
TIES=('bruna_smoke_d3_s1001','edf_smoke_d5_s1001','landfall_smoke_d5_s1001')

def envrows(path):
    return dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line and not line.startswith('#'))

def guard():
    context,_,_=c.guard(INPUTS,sealed=False)
    assert context['expected_source']==SOURCE and c.sha(BINARY)==PGO
    assert BINARY.parent.joinpath('SRC_TREE').read_text().strip()==SOURCE
    artifact=c.read(HERE/'artifact-dfcb-audit/audit.json')
    for model in artifact['only_two_model_value_play_blocks_change'].values():
        assert c.sha(ROOT/model['path'])==model['new_sha256'], 'Latest adopted sidecar not installed'
    index=c.read(OLD/'INDEX.json')
    assert index['source_tree']==SOURCE and all(c.sha(OLD/p)==h for p,h in index['files'].items())
    measured=envrows(OLD/'smoke.env');current=envrows(ROOT/'test/regression_gt.txt')
    for key in TIES:
        assert current[key]==measured[key], 'Review and filtered-accept original3ties before replacing last smoke results'
        assert c.sha(ROOT/'test/gt_logs'/(key+'.wins'))==c.sha(OLD/'logs/wins'/(key+'.wins')), 'Original reviewed wins not promoted'
    return dict(index_sha256=c.sha(OLD/'INDEX.json'),ties={k:measured[k] for k in TIES},sidecar_hashes={m['path']:m['new_sha256']for m in artifact['only_two_model_value_play_blocks_change'].values()})

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true');p.add_argument('--prior-smoke-review-closed',action='store_true');a=p.parse_args()
    argv=['bash','test/regression.sh','--smoke','--deck='+DECKS]
    if not a.run:
        print(json.dumps(dict(prepared=True,source_tree=SOURCE,PGO_sha256=PGO,argv=argv,threads=32,selected_cells=8,games=2600,prior_review_and_filtered_accept_required=True,output=str(OUT),engine_launched=False),indent=2));return
    assert a.prior_smoke_review_closed, 'Root must close original3ties review before this smoke replaces last results'
    before=guard()
    assert not c.competitors(), 'Finish other engine/build workloads before normal32 throughput'
    OUT.mkdir(exist_ok=False)
    env={k:v for k,v in os.environ.items()if not k.startswith(('MTG_','VPC_'))}
    settings=dict(THREADS='32',MTG_BIN=str(BINARY),MTG_PGO='1',MTG_DUMP_UNITS='1',MTG_FD_ORACLE='1',MTG_FLAG_NONCONV='1',VPC_SKIP='0',GIT_OPTIONAL_LOCKS='0');env.update(settings)
    status=dict(status='RUNNING',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_tree=SOURCE,binary_sha256=PGO,commit=c.git(ROOT,'rev-parse','HEAD'),argv=argv,cwd=str(ROOT),env=settings,prerequisites=before,prior_smoke_review_closed=True)
    c.write(OUT/'status.json',status)
    with (OUT/'harness.log').open('x')as log:
        rc=subprocess.run(argv,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    # Preserve the actual harness exit before any postguard/result inspection can fail.
    status.update(status='PROCESS_CLOSED',returncode=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=c.sha(OUT/'harness.log'))
    c.write(OUT/'status.json',status)
    assert guard()==before
    manifest=c.read(ROOT/'test/logs/smoke/manifest.json');jobs=manifest['jobs']
    assert len(jobs)==8 and sum(j['games']for j in jobs)==2600
    assert {j['name'].split('_smoke_',1)[0]for j in jobs}==set(DECKS.split(','))
    preserved=OUT/'measured-files';preserved.mkdir()
    paths=['test/logs/smoke/manifest.json','test/logs/smoke/batch.log','test/logs/smoke/batch.err','test/results/smoke.env','test/regression_result_smoke.txt']
    paths += ['test/logs/smoke/wins/'+j['name']+suffix for j in jobs for suffix in ('.wins','.units')]
    copied={}
    for rel in paths:
        src=ROOT/rel
        if not src.exists():continue
        dest=preserved/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);copied[rel]=c.sha(dest)
    c.write(preserved/'INDEX.json',dict(source_tree=SOURCE,binary_sha256=PGO,files=copied))
    status.update(status='CLOSED',returncode=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=c.sha(OUT/'harness.log'),measured_index_sha256=c.sha(preserved/'INDEX.json'))
    c.write(OUT/'status.json',status);print(json.dumps(status,indent=2));raise SystemExit(rc)

if __name__=='__main__':main()
