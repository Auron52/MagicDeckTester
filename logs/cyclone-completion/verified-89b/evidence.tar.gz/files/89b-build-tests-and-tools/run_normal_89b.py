#!/usr/bin/env python3
"""Run one normal test tier with exact source/binary receipts; no time limit."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspaces/MagicDeckTester/.claude/worktrees/cyclone-landing905')
OUT = Path(__file__).resolve().parent
SOURCE = '89b146d10406063213d9abe41e1cfdf1a616c021'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT,
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).decode().strip()

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('mode', choices=['regression'])
    p.add_argument('--binary-sha256', required=True)
    a = p.parse_args()
    binary = ROOT / 'build/PGO/mtg'
    def guard():
        assert git('rev-parse', 'HEAD:src') == SOURCE
        assert not git('status', '--porcelain', '--untracked-files=all', '--', 'src')
        assert (ROOT / 'build/PGO/SRC_TREE').read_text().strip() == SOURCE
        assert sha(binary) == a.binary_sha256
    guard()
    folder = OUT / ('followup-normal-' + a.mode)
    folder.mkdir(exist_ok=False)
    env = {k:v for k,v in os.environ.items() if not k.startswith(('MTG_', 'VPC_'))}
    settings = dict(THREADS='32', MTG_BIN=str(binary), MTG_DUMP_UNITS='1',
        MTG_FD_ORACLE='1', MTG_FLAG_NONCONV='1', VPC_SKIP='0', GIT_OPTIONAL_LOCKS='0')
    env.update(settings)
    argv = ['bash', 'test/regression.sh', '--' + a.mode]
    record = dict(status='RUNNING', started=now(), source_tree=SOURCE,
        commit=git('rev-parse', 'HEAD'), binary_sha256=a.binary_sha256,
        argv=argv, cwd=str(ROOT), env=settings, log=str(folder/'harness.log'))
    status = folder/'status.json'
    status.write_text(json.dumps(record, indent=2)+'\n')
    with (folder/'harness.log').open('x') as log:
        rc = subprocess.run(argv, cwd=ROOT, env=env, stdout=log,
                            stderr=subprocess.STDOUT).returncode
    guard()
    record.update(status='CLOSED', returncode=rc, finished=now(),
        log_sha256=sha(folder/'harness.log'))
    status.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2), flush=True)
    raise SystemExit(rc)

if __name__ == '__main__':
    main()
