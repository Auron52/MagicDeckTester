Prepared engine-free archive; **not finalized**. The closed evidence selection is frozen in `selection.PREPARED.json` (1124 files,9174607 uncompressed bytes). This preparer did not inspect active memory1 or native-Claude outputs. Existing C2 archive and all runtime inputs/results remain unchanged.

Check current prepared evidence:

```
python3 build/scratch/cyclone-finish/landing905-review/archive-89b-preparation/archive.py
```

Exit2 is expected until all four required future groups have actual closed evidence. This checks every frozen file hash, source89b, clean src, actual reviewed normal-accept0, parity and VERIFY. The initial smoke/regression exits1 remain in their original receipts; acceptance0 is a separate event. Old C2/native FD traces and paired C2 controls are source-labeled, never89b aliases. The old prepared/pending filenames within closed trees are preserved for chronology; later authoritative closure receipts determine status.

After root supplies final closed report paths, prepare a **new** `final-groups.json` with exactly these four keys:

- `full-four-context-memory`: official full memory1/normal32/tiny32/unbounded32 report, actual positive20480KB/refusal proof, each stage DONE0/status, original manifests, wins/units and logs; include300shape checks and exact168core comparisons.
- `quiet855`: quiet host/prerequisite receipt, sealed plan/env/source/binary/assets, full855job/outcome/unit/time output, DONE0 and final three-arm gate report with original535view. No partial/mixed timing verdict.
- `native-Claude-actual15-and-benchmark-reviewed`: actual completed15game receipts, parsed diagnostics/physical reviews, benchmark closure, engine input/trace outputs, exact source/PGO and reviewed flags. **Explicit selected files only; no directory recursion**, raw conversation/agent transcript streams or credentials.
- `latest-PD-Slivers-filtered-smoke`: actual normal8cell/2600game run, initial result/review and acceptance closure if needed; retain upstream artifacts and existing unfiltered3889-measured smoke evidence separately.

Each group has `gates` (explicit receipt paths and JSON dot-path/value predicates) and `files` (explicit path, SHA256, archive_name, content_class). Example schema, with no invented success receipt:

```
{
  "full-four-context-memory": {
    "gates": [{"receipt":"ABS_ACTUAL_CLOSED_REPORT", "equals":{"ACTUAL_SOURCE_FIELD":"89b146d10406063213d9abe41e1cfdf1a616c021", "ACTUAL_PGO_FIELD":"20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80", "ACTUAL_COMPLETE_PASS_FIELD":true}}],
    "files": [{"path":"ABS_ACTUAL_CLOSED_REPORT", "sha256":"ACTUAL_SHA256", "archive_name":"report.json", "content_class":"receipt"}]
  }
}
```

Supply all four groups. Permitted classes: receipt,engine_input,engine_trace,engine_output,review,helper. Every gate receipt must also be an archived explicit file. Predicates must enforce actual DONE0/full comparison status and exact89b/20de where the receipt supports those fields; include the sealed source/binary proof as another gate when a summary omits them. Do not create synthetic closure receipts to satisfy the archive. Native reviews must state actual reviewed scope and any unresolved flags; archive completion does not override a failed quality/cost gate.

Final read-only readiness check, then **only after root confirms all final gates closed and acceptable** build once:

```
python3 build/scratch/cyclone-finish/landing905-review/archive-89b-preparation/archive.py --final-groups ABS_FINAL_GROUPS_JSON
python3 build/scratch/cyclone-finish/landing905-review/archive-89b-preparation/archive.py --final-groups ABS_FINAL_GROUPS_JSON --build
```

Default output is persistent checkout `logs/cyclone-completion/verified-89b/{README.md,index.json,evidence.tar.gz}`. Output must not exist. No Git commands mutate anything; root reviews and force-adds/pushes this folder separately. Tar metadata is deterministic; the script rechecks bytes during packing and rereads every member/hash before publishing. It rejects binaries, symlinks and transcript/credential-style paths; records original file paths and individual SHA256; fails on any changed frozen evidence. If a newly completed stage legitimately edits a previously frozen proof, preserve this selection and create an explicitly reviewed new selection rather than updating hashes silently.
