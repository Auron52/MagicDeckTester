#!/usr/bin/env python3
"""Check/finalize compact89b evidence. No engines, git writes, or receipt invention."""
import argparse,datetime,gzip,hashlib,io,json,os,pathlib,re,shutil,subprocess,tarfile,tempfile
HERE=pathlib.Path(__file__).resolve().parent
CLASSES={'receipt','engine_input','engine_trace','engine_output','review','helper'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def get(x,k):
 for part in k.split('.'):x=x[int(part)] if isinstance(x,list) else x[part]
 return x
def safe_path(p):
 p=pathlib.Path(p)
 if p.is_symlink() or not p.is_file():raise ValueError(f'Not a regular file: {p}')
 low=p.name.lower()
 if p.suffix.lower() in {'.jsonl','.ndjson','.exe','.dll','.so','.a','.o','.pkl','.bin'} or re.search(r'(conversation|credential|secret|token|transcript|sessionlog)',low):raise ValueError(f'Forbidden evidence: {p}')
 with p.open('rb') as f:magic=f.read(4)
 if magic==b'\x7fELF' or magic[:2]==b'MZ':raise ValueError(f'Binary forbidden: {p}')
 return p
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--selection',type=pathlib.Path,default=HERE/'selection.PREPARED.json');ap.add_argument('--final-groups',type=pathlib.Path);ap.add_argument('--build',action='store_true');ap.add_argument('--output',type=pathlib.Path)
 args=ap.parse_args();plan=json.loads(args.selection.read_text());files=list(plan['files']);gates=list(plan['gates']);missing=list(plan['pending_required_groups'])
 errors=[]
 if args.final_groups:
  groups=json.loads(args.final_groups.read_text())
  if set(groups)!=set(missing):errors.append(f'Final group keys must equal {missing}')
  else:
   for name,group in groups.items():
    if not group or not group.get('gates') or not group.get('files'):errors.append(f'Incomplete group {name}');continue
    for g in group['gates']:
     if not g.get('equals') or not g.get('receipt'):errors.append(f'No explicit closed predicates: {name}');continue
     gates.append({'name':name,**g})
    for f in group['files']:
     if f.get('content_class') not in CLASSES:errors.append(f'Bad file content class: {f}');continue
     p=safe_path(f['path']);files.append({'source_path':str(p),'archive_path':f"89b-final/{name}/{f['archive_name']}",'source_role':'89b-final-'+name,'sha256':f['sha256'],'bytes':p.stat().st_size,'content_class':f['content_class']})
   missing=[]
 for g in gates:
  try:
   p=safe_path(g['receipt']);x=json.loads(p.read_text())
   for k,v in g['equals'].items():
    if get(x,k)!=v:errors.append(f"Gate {g['name']} mismatch {k}")
   if not any(f['source_path']==str(p) for f in files):errors.append(f"Receipt must be archived explicitly: {p}")
  except (OSError,ValueError,KeyError,TypeError) as e:errors.append(f"Gate {g['name']}: {e}")
 names=set()
 for f in files:
  try:
   p=safe_path(f['source_path']);archive=pathlib.PurePosixPath(f['archive_path'])
   if archive.is_absolute() or '..' in archive.parts or str(archive) in names:raise ValueError('Unsafe/duplicate archive name')
   names.add(str(archive))
   if sha(p)!=f['sha256']:raise ValueError('Frozen bytes changed')
  except (OSError,ValueError) as e:errors.append(f"File {f['source_path']}: {e}")
 w=pathlib.Path(plan['worktree']);env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 if subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD:src'],env=env,text=True).strip()!=plan['source_tree']:errors.append('Current source mismatch')
 if subprocess.check_output(['git','-C',str(w),'status','--porcelain','--untracked-files=all','--','src'],env=env,text=True).strip():errors.append('Current src dirty')
 result={'status':'READY' if not errors and not missing else 'INCOMPLETE_NOT_ARCHIVED','files':len(files),'bytes':sum(f['bytes'] for f in files),'pending_required_groups':missing,'errors':errors,'source_tree':plan['source_tree'],'pgo_sha256':plan['pgo_sha256']}
 print(json.dumps(result,indent=2))
 if not args.build:return 0 if result['status']=='READY' else 2
 if result['status']!='READY':raise SystemExit('Refusing incomplete final archive')
 dest=args.output or pathlib.Path(plan['archive_destination'])
 if dest.exists():raise SystemExit('Exclusive output already exists')
 dest.parent.mkdir(parents=True,exist_ok=True);tmp=pathlib.Path(tempfile.mkdtemp(prefix='.verified-89b-',dir=dest.parent))
 try:
  files.sort(key=lambda f:f['archive_path']);index={'scope':'Closed89b final validation with explicitly labeled paired/historical sources; initial harness rc1 preserved separately from reviewed acceptance0. No native conversations, credentials or binaries. See all staged receipts for measured limits.','source_tree':plan['source_tree'],'pgo_sha256':plan['pgo_sha256'],'prepared_selection_sha256':sha(args.selection),'final_groups_sha256':sha(args.final_groups),'stage_summaries':{name:g.get('summary') for name,g in groups.items()},'files':files,'gates':gates}
  archive=tmp/'evidence.tar.gz'
  with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
   for f in files:
    data=pathlib.Path(f['source_path']).read_bytes()
    if hashlib.sha256(data).hexdigest()!=f['sha256']:raise ValueError('Evidence changed during archive')
    info=tarfile.TarInfo('files/'+f['archive_path']);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
  index['archive_sha256']=sha(archive)
  (tmp/'index.json').write_text(json.dumps(index,indent=2)+'\n')
  (tmp/'README.md').write_text(f"# Cyclone89b validation evidence: cost gate failed\n\nSource `{plan['source_tree']}`; PGO `{plan['pgo_sha256']}`.\n\nThe quiet855 cost gate failed for all three measured arms: live13.6866x, PB3.5175x and PB+KEEP+MYRIAD3.5503x versus same-run Hinata2040.213ms/game (bar3x). This archive permits no suite admission, artifact generation or policy adoption.\n\nThe native controller's original exit2/INCOMPLETE is preserved alongside a separate read-only parser recovery closure validating15 actual native Claude games; it is not relabeled as controller0.\n\n`evidence.tar.gz` and `index.json` preserve the closed gates, raw engine inputs/outcomes/diagnostic traces, initial versus accepted normal results, source-focused tests and reviewer limits. Paired baseline and historical C2 evidence has separate labels; it is never aliased as89b measurement. Native conversation transcripts, credentials and compiled binaries are excluded.\n\nThe normal initial harness exits remain1; later reviewed acceptance is separately0. Existing FD observations are classified by exact tuples and outcomes, not described as repaired. The final per-stage receipts govern the scope of memory, native-Claude, VERIFY and cost claims.\n")
  # Verify the archive content manifest before publishing the directory.
  with tarfile.open(archive,'r:gz') as tar:
   members=tar.getmembers();assert len(members)==len(files)
   for m,f in zip(members,files):assert m.name=='files/'+f['archive_path'] and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==f['sha256']
  os.rename(tmp,dest);print('ARCHIVED',dest)
 except BaseException:
  shutil.rmtree(tmp);raise
 return 0
if __name__=='__main__':raise SystemExit(main())
