#!/usr/bin/env python3
"""Explicit selection of now-closed89b receipts, engine artifacts, and safe metadata."""
import pathlib,json,hashlib
H=pathlib.Path(__file__).resolve().parent;P=H.parent;B=P.parent
Q=B/'v7-905-lean/prepared-89b146d-final';N=B/'claude-sweep-89b146d';R=B/'claude-sweep-89b146d-parser-recovery'
SRC='89b146d10406063213d9abe41e1cfdf1a616c021';PGO='20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(R/'RECOVERY-REPORT.json')=='3d7a28945a13c7fba3849c28eddc8cf8ed8f6e9fec7e4e2839bc6f8ba68d1e12'
assert sha(R/'CLOSURE.json')=='fd9b39ef976a7f6e493152e1ad539a840b32666bb46bb0c95ea06f63ecb06881'
plan=json.loads((H/'selection.PREPARED.json').read_text());seen={f['source_path'] for f in plan['files']};groups={name:{'gates':[],'files':[]} for name in plan['pending_required_groups']}
def add(name,p,klass='engine_output',base=B):
 p=pathlib.Path(p)
 if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:return
 if str(p) in seen:return
 seen.add(str(p));groups[name]['files'].append({'path':str(p),'sha256':sha(p),'archive_name':str(p.relative_to(base)),'content_class':klass})
def tree(name,p,klass='engine_output'):
 for f in sorted(p.rglob('*')):
  if f.suffix in {'.json','.md','.py','.log','.err','.wins','.units','.tsv','.txt','.env','.meta'} or f.name=='DONE':add(name,f,klass)
def gate(name,p,equals):groups[name]['gates'].append({'receipt':str(p),'equals':equals});add(name,p,'receipt')
mem='full-four-context-memory';m=P/'followup-memory-report/memory-report.json'
gate(mem,m,{'source_tree':SRC,'binary_sha256':PGO,'V6_proof_pass':True,'normal32_complete':True,'tiny32_positive20MiB':True,'unbounded32_budget_proven':True,'fidelity_clean':True,'FSL_review_required':False,'problems':[]})
for stage in ['memory1','memory32','memory-tiny32','memory-unbounded32']:
 gate(mem,Q/f'runs/{stage}/status.json',{'status':'DONE','returncode':0,'source_tree':SRC,'binary_sha256':PGO});tree(mem,Q/'runs'/stage)
tree(mem,P/'followup-memory-report');tree(mem,P/'memory32-tiny32-early89b')
# Selected source/input/guard/helper recipes only; no models, binaries, or unselected older queues.
for f in ['context.json','stage-plans.json','verify_small.json','final-runtime-plan.json','cost_gate_arms.json','run-plan.json','run_v6.py','factory.RECIPE.py','memory_invariance.json','seal.json','memory_cyclone_shapes.json','report_v6.py','apparatus-v5-bridge.json','phasec-recipe-binding.json','README.md','v5-shape-observation.json']:
 add(mem,Q/f,'engine_input' if f.endswith('.json') else 'helper')
tree(mem,Q/'helpers','helper');tree(mem,Q/'runs/verify');add(mem,P/'final-gates-closure89b.json','receipt')
gate(mem,P/'final-gates-closure89b.json',{'source_tree':SRC,'binary_sha256':PGO,'all_selected_other_stages_closed':True,'no_optional_policy_adoption':True,'no_artifact_generation_started':True})
closure=json.loads((P/'final-gates-closure89b.json').read_text())
for st in closure['stages']:
 p=pathlib.Path(st['evidence_path']);assert sha(p)==st['evidence_sha256'],p;add(mem,p,'review')
assert '912   STALE: 0   missing: 0' in (P/'followup-all-gt-consistency.log').read_text()
assert 'scanned 34' in (P/'references-safe34-followup.log').read_text() and 'OK: every' in (P/'references-safe34-followup.log').read_text()
for f in ['followup-all-gt-consistency.log','references-safe34-followup.log']:add(mem,P/f,'receipt')
groups[mem]['summary']='Fresh168core exact in1/32/tiny32/unbounded32; all300normal32shapes closed; positive20MiB pressure88408refusals; FSL0. No final6/12/24 proof claimed.'
cost='quiet855';c=P/'followup-cost-report/cost-report.json'
gate(cost,c,{'source_tree':SRC,'binary_sha256':PGO,'complete':True,'total_games':855,'shared_hinata_games':375,'primary_quality_timing_used':False,'requires_additional_review':False,'gates.live.observed_point_gate':'FAIL','gates.pb_on.observed_point_gate':'FAIL','gates.pb_keep_myriad.observed_point_gate':'FAIL','quiet_provenance.status':'DONE','quiet_provenance.returncode':0,'quiet_provenance.competing_process_samples':[]})
tree(cost,P/'followup-cost-report');tree(cost,Q/'runs/cost')
groups[cost]['summary']='COST FAIL all arms: live13.686632x, PB3.517524x, PB+KEEP+MYRIAD3.550266x vs same-run Hinata2040.213333ms/game; quiet855closed0. NO admission/generation/adoption.'
native='native-Claude-actual15-and-benchmark-reviewed'
gate(native,R/'RECOVERY-REPORT.json',{'source_tree':SRC,'binary_sha256':PGO,'actual_original_controller_exit':2,'actual_cli_exits':[0]*15,'native_models':['claude-sonnet-5'],'genuine_actual_games_validated':15,'engine_or_model_calls_by_recovery':0,'guard_tests':10,'all_original_files_unchanged':True,'reported_flags':0,'earlier_win_candidates':[]})
gate(native,R/'CLOSURE.json',{'status':'CHECK_ONLY_CLOSED_PASS','original_controller_exit_preserved':2,'recovery_engine_model_calls':0,'native_model':'claude-sonnet-5','games':15,'flags':0,'earlier_win_candidates':0,'decision_frames':560,'all1931_original_files_unchanged':True,'guard_tests_passed':10})
guards=json.loads((R/'guard-tests.json').read_text());assert len(guards)==10 and all(x['PASS'] for x in guards)
gate(native,R/'guard-tests.json',{f'{i}.PASS':True for i in range(10)})
for f in ['README.md','audited-readonly-commands.json','native-cat-audit.json','observational-types.json','oracle_verify.py','original-files-before.json','original-immutability.json','recover.py']:add(native,R/f,'helper' if f.endswith('.py') else 'receipt')
tree(native,R/'recovered','receipt');tree(native,B/'claude-sweep-89b146d-review','review')
# Explicit native metadata whitelist. No prompts, CLI stream, native stderr or conversations.
for f in ['INCOMPLETE.json','PREPARATION-CHECKS.json','README.md','ROOT-LAUNCH-GRANT.json','audited-readonly-commands.json','benchmark-manifest.json','benchmark.py','cards22.json','controller.log','expected-decisions.json','sealed-plan.json','sweep.py','observational_types.py','oracle_verify.py']:add(native,N/f,'helper' if f.endswith('.py') else 'receipt')
gate(native,N/'benchmark/status.json',{'source_tree':SRC,'binary_sha256':PGO,'status':'DONE','returncode':0,'engine_returncode':0,'validation_pass':True})
tree(native,N/'benchmark')
for seed in range(1900001,1900016):
 game=N/'games'/str(seed)
 gate(native,game/'ENGINE-COMPLETE.json',{'source_tree':SRC,'binary_sha256':PGO,'engine_returncode':0})
 for f in ['CLAUDE-COMPLETE.json','CLAUDE-FAILED.json','benchmark.json','MODEL-RUNNING.json']:
  if (game/f).exists():add(native,game/f,'receipt')
 for folder in ['steps','engine-traces']:
  for f in sorted((game/folder).rglob('*')):
   if f.is_file() and f.suffix in {'.json','.stdout','.stderr','.log','.err','.wins','.units'}:add(native,f,'engine_trace' if folder=='engine-traces' else 'engine_output')
groups[native]['summary']='Original controller exit2/INCOMPLETE preserved. Separate read-only recovery validates actual15Sonnet5/15CLI0/full22/560frames/11types/0flags/0earlier;10guardsPASS;1931original bytes unchanged. No raw native conversations included.'
smoke='latest-PD-Slivers-filtered-smoke';s=P/'followup-artifact-smoke/accept-closure.json'
gate(smoke,s,{'status':'FILTERED_ARTIFACT_SMOKE_ACCEPTED','returncode':0,'source_tree':SRC,'binary_sha256':PGO,'measured_harness_returncode':0,'configs':8,'games':2600,'all_outcomes_and_digests_equal_latest_gt':True,'all_gt_keys_unchanged':True,'all_binding_notes_preserved':True})
tree(smoke,P/'followup-artifact-smoke');groups[smoke]['summary']='Latest PD/Slivers normal filtered8cells2600games measured0/accepted0; all outcomes/digests exact and all GT keys/binding notes preserved.'
# Keep the exact archival selection and its implementation reviewable inside its own artifact.
for f in ['selection.PREPARED.json','prepare.py','archive.py','README.md','test_archive.py','finalize_selection.py']:add(mem,H/f,'helper')
with (H/'final-groups.json').open('x') as f:json.dump(groups,f,indent=2);f.write('\n')
print('Added closed files',sum(len(g['files']) for g in groups.values()))
