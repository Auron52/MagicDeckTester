#!/usr/bin/env python3
"""Freeze selection of already closed evidence only; never reads active future stages."""
import pathlib,json,hashlib
HERE=pathlib.Path(__file__).resolve().parent;P=HERE.parent
W=pathlib.Path('/workspaces/MagicDeckTester/.claude/worktrees/cyclone-landing905')
SRC='89b146d10406063213d9abe41e1cfdf1a616c021';PGO='20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80'
files=[];seen=set()
allowed={'.json','.md','.txt','.log','.err','.wins','.units','.tsv','.py','.env','.meta'}
def add(p,role,base=P):
 p=pathlib.Path(p)
 if p.is_symlink() or not p.is_file(): return
 if p.suffix not in allowed and p.name not in {'DONE','DONE.json'}: return
 if any(s in p.name.lower() for s in ['conversation','credential','secret','token','stdout.jsonl']): raise ValueError(p)
 if p in seen:return
 seen.add(p);files.append({'source_path':str(p),'archive_path':f'{role}/{p.relative_to(base)}','source_role':role,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
def tree(rel,role):
 for p in sorted((P/rel).rglob('*')):
  if '__pycache__' not in p.parts:add(p,role)
for rel in ['followup-normal-regression','followup-release-smoke','normal-accept89b','followup89-combined-controls','preflight-89b32','cache-unit123021-release89b','followup-verify-report']:
 tree(rel,'89b-or-explicit-paired-source-evidence')
for name in ['followup-focused-units.log','followup-full-units.log','followup-source-independent-review.json','followup-source-preparation.json','followup-final-pgo.json','followup-release-build.log','followup-pgo-build.log','collect_followup_closure_fd.py','run_normal_89b.py','run_artifact_smoke_89b.py']:
 add(P/name,'89b-build-tests-and-tools')
# Whole normal outcomes and units are closed; actual simulator binary is deliberately excluded.
for p in sorted((W/'test/logs/regression/wins').iterdir()):add(p,'89b-closed-normal-all-outcomes',W)
for name in ['manifest.json','batch.log','batch.err','mtg.run.meta']:add(W/'test/logs/regression'/name,'89b-closed-normal-all-outcomes',W)
old=json.loads((P/'fd-three-exact-2c-postrun-review.json').read_text())
for name in ['fd-three-exact-2c-postrun-review.json','regression-exact-controls/assets-bridge.json','regression-exact-controls/comparison.json','regression-exact-controls/sealed-plan.json','regression-exact-controls/current-manifest.json','regression-exact-controls/baseline-manifest.json']:
 add(P/name,'HISTORICAL-C2-native-FD-context')
for obs in old['observations']:
 for k in ['current_fulltrace','baseline_fulltrace']:add(pathlib.Path(obs[k]['path']),'HISTORICAL-C2-native-FD-context')
plan={'status':'PREPARED_NOT_FINAL_ARCHIVE','source_tree':SRC,'pgo_sha256':PGO,'worktree':str(W),'archive_destination':str(W/'logs/cyclone-completion/verified-89b'),'files':files,
 'gates':[{'name':'normal-accept','receipt':str(P/'normal-accept89b/closure.json'),'equals':{'status':'NORMAL_ACCEPTED_AFTER_FULL_PHYSICAL_REVIEW','returncode':0,'source_tree':SRC,'binary_sha256':PGO,'all_other_gt_keys_unchanged':True,'latest_pd_slivers_gt_preserved':True,'overnight_unchanged':True}}, {'name':'parity','receipt':str(P/'preflight-89b32/review.json'),'equals':{'compiler_parity_ok':True}}, {'name':'verify','receipt':str(P/'followup-verify-report/verify-report.json'),'equals':{'DONE0':True,'source_tree':SRC,'binary_sha256':PGO,'exercise.pass_':True}}],
 'pending_required_groups':{'full-four-context-memory':None,'quiet855':None,'native-Claude-actual15-and-benchmark-reviewed':None,'latest-PD-Slivers-filtered-smoke':None},
 'future_group_contract':'Supply explicit closed receipt paths, JSON exact-value predicates and explicit artifact file paths only. No recursive native-Claude selection. No future stage is passed until the supplied predicates validate. Future file class must be receipt,engine_input,engine_trace,engine_output,review,or helper; raw native conversations forbidden.',
 'excluded':'All binaries/model payloads/credentials/native conversation or agent transcript streams; C2 archive itself is unchanged. Older source context is separately labeled and never aliased as89b measurement.'}
with (HERE/'selection.PREPARED.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
print('Frozen closed files',len(files),'bytes',sum(f['bytes'] for f in files));print(HERE/'selection.PREPARED.json')
