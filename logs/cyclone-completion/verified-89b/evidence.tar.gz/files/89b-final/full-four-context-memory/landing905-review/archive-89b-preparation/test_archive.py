import hashlib,json,pathlib,subprocess,sys,tarfile,tempfile,unittest
HERE=pathlib.Path(__file__).resolve().parent
class ArchiveTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name);self.receipt=self.p/'synthetic-receipt.json';self.receipt.write_text('{"synthetic_pass":true}\n');self.out=self.p/'out'
  self.plan={'files':[{'source_path':str(self.receipt),'archive_path':'SYNTHETIC-ONLY/receipt.json','source_role':'SYNTHETIC-ONLY','sha256':hashlib.sha256(self.receipt.read_bytes()).hexdigest(),'bytes':self.receipt.stat().st_size}], 'gates':[{'name':'SYNTHETIC-ONLY','receipt':str(self.receipt),'equals':{'synthetic_pass':True}}], 'pending_required_groups':{},'source_tree':'89b146d10406063213d9abe41e1cfdf1a616c021','pgo_sha256':'SYNTHETIC-NOT-AN-ENGINE','worktree':'/workspaces/MagicDeckTester/.claude/worktrees/cyclone-landing905','archive_destination':str(self.out)}
  self.selection=self.p/'selection.json';self.groups=self.p/'groups.json';self.groups.write_text('{}')
 def tearDown(self):self.tmp.cleanup()
 def run_archive(self,build=True):
  self.selection.write_text(json.dumps(self.plan));return subprocess.run([sys.executable,str(HERE/'archive.py'),'--selection',str(self.selection),'--final-groups',str(self.groups)]+(['--build'] if build else []),capture_output=True,text=True)
 def test_roundtrip_synthetic_only(self):
  x=self.run_archive();self.assertEqual(x.returncode,0,x.stdout+x.stderr)
  with tarfile.open(self.out/'evidence.tar.gz') as t:self.assertEqual(t.extractfile(t.getmembers()[0]).read(),self.receipt.read_bytes())
  idx=json.loads((self.out/'index.json').read_text());self.assertEqual(idx['archive_sha256'],hashlib.sha256((self.out/'evidence.tar.gz').read_bytes()).hexdigest())
 def test_missing_group_fails_without_output(self):
  self.plan['pending_required_groups']={'not-closed':None};x=self.run_archive();self.assertNotEqual(x.returncode,0);self.assertFalse(self.out.exists())
 def test_changed_bytes_fail_without_output(self):
  self.receipt.write_text('{"synthetic_pass":true,"modified":true}');x=self.run_archive();self.assertNotEqual(x.returncode,0);self.assertFalse(self.out.exists())
 def test_conversation_rejected(self):
  forbidden=self.p/'conversation.json';forbidden.write_text('{}');self.plan['files'][0]['source_path']=str(forbidden);x=self.run_archive();self.assertNotEqual(x.returncode,0);self.assertFalse(self.out.exists())
if __name__=='__main__':unittest.main()
