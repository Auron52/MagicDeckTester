#!/usr/bin/env python3
"""Prepare/seal/check only lean V6 memory972 + VERIFY24 + quiet855. Never runs engines."""
import argparse
import datetime
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'helpers'))
import v6_common as c
V5=Path('/workspaces/MagicDeckTester/build/scratch/cyclone-finish/v5/final-pgo-inputs')
V5ROOT=Path('/workspaces/MagicDeckTester/.claude/worktrees/cyclone-current')
V5COST=Path('/workspaces/MagicDeckTester/build/scratch/cyclone-finish/v5-analysis/selected-cost-pbkeep855')
COST_ARMS={'live':{},'pb_on':{'MTG_CYCLONE_PB_PLANS':True},'pb_keep_myriad':{'MTG_CYCLONE_PB_PLANS':True,'MTG_CYCLONE_KEEP_AMEND':True,'MTG_CYCLONE_KEEP_MYRIAD':True}}
GENERATION_POLICY='Unpredictable Cyclone.buckets.json'
GENERATION_POLICY_SHA='8d54582851fa6c31638ee35b7e81eec49c961c74d0930a68fbdce6d57e6256d2'

def prepare(a):
    root=a.worktree.resolve();out=a.inputs.resolve();binary=a.bin.resolve()
    assert re.fullmatch('[0-9a-f]{40}',a.expected_source)
    assert c.git(root,'rev-parse','HEAD:src')==a.expected_source and not c.git(root,'status','--porcelain','--untracked-files=all','--','src')
    mapping=c.slots(root)
    prior=c.read(Path('/workspaces/MagicDeckTester/build/scratch/cyclone-finish/v6-final-lean/prepared-bad569b-final/context.json'))
    assert mapping[:755]==prior['slot_mapping'], 'Prior755 mapping changed'
    upstream_text=c.git(root,'show','90503a7783c32e4cf7622cb3073421ebfcc67752:src/ai/HeuristicArm.h')
    ee=upstream_text[upstream_text.index('enum Slot'):];ee=ee[:ee.index('\n};')]
    nn=upstream_text[upstream_text.index('static const char* const kNames[COUNT] = {'):];nn=nn[:nn.index('\n    };')]
    aa=re.findall(r'^\s*([A-Z][A-Z0-9_]*)\s*(?:=[^,]+)?\s*,',ee,re.M);bb=re.findall(r'^\s*"(MTG_[A-Z0-9_]+)"',nn,re.M)
    upstream=[[x,y] for x,y in zip(aa,bb)]
    assert len(upstream)==713 and [p for p in mapping if p in upstream]==upstream, 'Upstream905 ordered713 mapping changed'
    edf_defaults={}
    for filename in ('src/ai/EngineFlags.h','src/ai/TurnSolver.cpp','src/core/SpellEffects.h'):
        text=(root/filename).read_text()
        for _,flag in mapping[755:]:
            match=re.search(r'EnvOn\("'+flag+r'", (true|false)\)',text)
            if match:edf_defaults[flag]=dict(default=match[1]=='true',file=filename,line=text.count('\n',0,match.start())+1,reader=match[0])
    assert {k:v['default'] for k,v in edf_defaults.items()}==dict(MTG_ENERGY_AURA_PIP=True,MTG_TAPAHEAD_ENERGY_COVER=True,MTG_PAINLAND_TAPAHEAD_CAST_AUTO=True,MTG_EF_SCALAR_REFUND=False,MTG_ETB_BOUND_AURA=True)

    assert mapping[:751]==c.slots(V5ROOT,751), 'Prior751 slot/name prefix changed'
    new_defaults={}
    for filename in ('src/ai/EngineFlags.h','src/ai/TurnSolver.cpp'):
        text=(root/filename).read_text()
        for flag in ('MTG_REAL_PAY_ATTACK_PIN','MTG_DORK_ATK_PROVIDER_HOLD','MTG_DEV_SEQ_TAIL_SKIP','MTG_DEV_SEQ_DIRTY_READ','MTG_REAL_PAY_SCRIPT'):
            match=re.search(r'EnvOn\("'+flag+r'", (true|false)\)',text)
            if match:new_defaults[flag]=dict(default=match[1]=='true',file=filename,line=text.count('\n',0,match.start())+1,reader=match[0])
    assert {k:v['default'] for k,v in new_defaults.items()}=={'MTG_REAL_PAY_ATTACK_PIN':True,'MTG_DORK_ATK_PROVIDER_HOLD':False,'MTG_DEV_SEQ_TAIL_SKIP':True,'MTG_DEV_SEQ_DIRTY_READ':True,'MTG_REAL_PAY_SCRIPT':False}
    apparatus={};bridge={}
    for deck in ('Unpredictable Cyclone','Hinata2','KittyEquipment'):
        old=c.inventory(V5ROOT/'decks'/deck);new=c.inventory(root/'decks'/deck)
        assert new==prior['apparatus'][deck], 'All26 assets must exactly match committed ce2 apparatus'
        addition={}
        if deck=='Unpredictable Cyclone' and GENERATION_POLICY in new:
            assert GENERATION_POLICY not in old
            assert new[GENERATION_POLICY]==GENERATION_POLICY_SHA, 'Approved generation-only policy bytes changed'
            policy=c.read(root/'decks'/deck/GENERATION_POLICY)
            assert set(policy)=={'merge'} and len(policy['merge'])==1
            assert policy['merge'][0]['cards']==['Ulamog, the Ceaseless Hunger','Ulamog, the Infinite Gyre']
            addition={GENERATION_POLICY:new[GENERATION_POLICY]}
        assert old=={k:v for k,v in new.items() if k not in addition}, 'Original25 V5/current apparatus differs: '+deck
        apparatus[deck]=new;bridge[deck]=dict(V5_directory=str(V5ROOT/'decks'/deck),current_directory=str(root/'decks'/deck),identical_original_files=old,generation_only_addition=addition)
    # Snapshot only frozen source inputs/helpers, never active V5 runtime output.
    oldpaths=[*V5.glob('*.json'),*V5.rglob('profiles/*.json'),*V5COST.glob('*')]
    oldpaths=[p for p in oldpaths if p.is_file() and p.name not in ('primary-quality-plan.json','final-runtime-plan.json')]
    before={str(p.resolve()):c.sha(p) for p in oldpaths}
    out.mkdir(parents=True,exist_ok=False);shutil.copytree(HERE/'helpers',out/'helpers',ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('run_v6.py','report_v6.py'):shutil.copyfile(HERE/name,out/name)
    shutil.copyfile(HERE/'factory.py',out/'factory.RECIPE.py')
    c.write(out/'v5-frozen-files-before.json',before)
    command=[sys.executable,str(out/'helpers/make_validation_manifests.py'),'--worktree',str(root),'--bin',str(binary),'--out',str(out),'--build-mode','pgo','--threads','32','--experiment','memory','--experiment','verify','--experiment','cost','--cost-arms',json.dumps(COST_ARMS)]
    subprocess.run(command,check=True)
    own=c.read(out/'run-plan.json');assert not own['warnings'];generated={p['name']:p for p in own['plans']}
    c.write(out/'generator-run-plan.UNSELECTED.json',own)
    core=c.read(out/'memory_invariance.json')['jobs'];shapes=c.read(out/'memory_cyclone_shapes.json')['jobs'];cost=c.read(out/'cost_gate_arms.json')['jobs'];verify=c.read(out/'verify_small.json')['jobs']
    assert sum(j['games'] for j in core)==168 and sum(j['games'] for j in shapes)==300 and sum(j['games'] for j in cost)==855 and sum(j['games'] for j in verify)==24
    for filename,old in [('memory_invariance.json',V5/'memory_invariance.json'),('memory_cyclone_shapes.json',V5/'memory_cyclone_shapes.json'),('verify_small.json',V5/'verify_small.json'),('cost_gate_arms.json',V5COST/'cost_gate_arms.json')]:
        mapped=json.loads(old.read_text().replace(str(V5ROOT),str(root)))
        assert c.read(out/filename)==mapped, 'Recipe drift beyond worktree-path rebinding: '+filename
    c.write(out/'memory-both-reference.json',dict(jobs=core+shapes))
    original=[j for j in cost if not any('_'+arm+'_' in j['name'] for arm in ('pb_on','pb_keep_myriad'))]
    prior=[j for j in cost if '_pb_keep_myriad_' not in j['name']]
    c.write(out/'cost_gate_live.json',dict(jobs=original));(out/'prior695-recipe').mkdir();c.write(out/'prior695-recipe/cost_gate_arms.json',dict(jobs=prior))
    assert sum(j['games'] for j in original)==535 and sum(j['games'] for j in prior)==695
    plans={}
    def plan(stage,source,manifest=None,workers=None):
        p=json.loads(json.dumps(generated[source]));p['name']=stage
        if manifest:p['argv'][p['argv'].index('--batch')+1]=str(out/manifest)
        if workers:p['argv'][p['argv'].index('--threads')+1]=str(workers)
        run=out/'runs'/stage;p['stdout']=str(run/'batch.log');p['stderr']=str(run/'batch.err')
        p['argv'][p['argv'].index('--game-log-dir')+1]=str(run/'wins')
        p['manifest']=p['argv'][p['argv'].index('--batch')+1];plans[stage]=p
    plan('memory1','memory_t1_normal')
    plan('memory32','memory_t24_normal','memory-both-reference.json',32)
    plan('memory-tiny32','memory_t12_tiny',workers=32);plan('memory-unbounded32','memory_t6_unbounded',workers=32);plan('verify','verify_small',workers=32);plan('cost','cost_gate_arms',workers=32)
    totals={name:sum(j['games'] for j in c.read(p['manifest'])['jobs']) for name,p in plans.items()};assert sum(v for n,v in totals.items() if n.startswith('memory'))==972
    # Compatibility metadata for the existing strict memory comparator; this is
    # the standalone468-game normal32 reference, not a new quality sweep.
    p24=plans['memory32'];maps={j['name']:dict(family='memory_invariance' if j['name'] in {x['name'] for x in core} else 'memory_cyclone_shapes',logical_cell=j['name']) for j in core+shapes}
    primary=dict(p24,src_tree=a.expected_source,binary_sha256=None,binary=str(binary),threads=32,job_map=maps)
    c.write(out/'primary-quality.json',dict(jobs=core+shapes));c.write(out/'primary-quality-plan.json',primary)
    schedule=dict(primary_quality=primary,memory_comparisons=[])
    names={'memory1':'memory_t1_normal','memory-tiny32':'memory_t32_tiny','memory-unbounded32':'memory_t32_unbounded'}
    for stage,name in names.items():schedule['memory_comparisons'].append(dict(plans[stage],name=name))
    c.write(out/'final-runtime-plan.json',schedule)
    c.write(out/'stage-plans.json',plans)
    c.write(out/'run-plan.json',dict(worktree=str(root),source_tree=a.expected_source,binary=str(binary),primary_threads=32,plans=list(plans.values()),unset_before_run=own['unset_before_run'],note='Only these6 selected stages are runnable. Generator archive is recipe provenance, not an additional queue. No13koptional quality repeat.'))
    c.write(out/'apparatus-v5-bridge.json',dict(source_recipe='V5 src8b; no outcome/quality carry implied',current_source=a.expected_source,apparatus=bridge,prior751_slot_prefix_exact=True,new_four_slots=mapping[751:755],prior755_exact_prefix=True,upstream905_ordered713_retained=True,new_five_EDF_slots=mapping[755:],new_EDF_default_readers=edf_defaults,default_readers=new_defaults,real_pay_attack_scope='Pin reader defaultsON but script defaultsOFF, so default script path remains inert; dork hold defaultsOFF. TailSkip/DirtyRead defaultON are fresh source behavior, not V5 quality carry.',exact_recipe_rebind_files=['memory_invariance.json','memory_cyclone_shapes.json','verify_small.json','cost_gate_arms.json'],V5_frozen_files_unchanged=before))
    oldbinding=c.read(V5COST/'phasec-package-binding.json')
    c.write(out/'phasec-recipe-binding.json',dict(V5_quality_recipe_source=oldbinding['source_tree'],V5_quality_binary_sha256=oldbinding['binary_sha256'],current_source=a.expected_source,full_phasec_flags=oldbinding['full_phasec_flags'],cost_flags=COST_ARMS['pb_keep_myriad'],profile=str(root/Path(oldbinding['profile']).relative_to(V5ROOT)),profile_sha256=oldbinding['profile_sha256'],scope='Same apparatus/three-flag recipe only. V5 PhaseC quality is historical; new source is not a wholesale quality carry or adoption.'))
    shape_plan=c.read(V5/'final-runtime-plan.json')
    historical=[]
    for v in shape_plan['memory_comparisons']:
        if v['name'] not in ('memory_t6_both_reference_sets','memory_t12_both_reference_sets'):continue
        wins=Path(v['stdout']).parent/'wins'
        files={str(wins/(j['name']+suffix)):c.sha(wins/(j['name']+suffix)) for j in shapes for suffix in ('.wins','.units')}
        historical.append(dict(name=v['name'],wins=str(wins),files=files))
    c.write(out/'v5-shape-observation.json',dict(source_tree='8b0bc5ea046ce748c456f7e4aceef4ea11807aa5',binary_sha256=c.read(V5/'primary-quality-plan.json')['binary_sha256'],jobs=c.read(V5/'memory_cyclone_shapes.json')['jobs'],runs=historical,scope='Optional cross-source observation only. Never final-source6/12/24 invariance or automatic outcome carry.'))
    prepared_files={str(p):c.sha(p) for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('primary-quality-plan.json','final-runtime-plan.json')}
    c.write(out/'context.json',dict(version='V7-905-lean32',worktree=str(root),expected_source=a.expected_source,binary=str(binary),forbidden_active_V5_binary=c.read(V5/'primary-quality-plan.json')['binary'],apparatus=apparatus,slot_mapping=mapping,prepared_files=prepared_files,execution_metadata_sha256=c.metadata_digest(out),stage_plans_sha256=c.sha(out/'stage-plans.json'),apparatus_bridge_sha256=c.sha(out/'apparatus-v5-bridge.json'),unset_before_run=own['unset_before_run'],totals=totals,expected_memory_total=972,prepared_only=True,authorization='Prepared only. Fresh final-source PGO SHA seal required; root owns scheduling/launch and default32worker throughput, except targeted memory1. Previous1908 packet is superseded/unrun.'))
    assert all(c.sha(p)==v for p,v in before.items()), 'Frozen V5 input/helper mutated during preparation'
    print(json.dumps(dict(prepared=str(out),sealed=False,source=a.expected_source,PGO_sha='REQUIRED_AFTER_FRESH_BUILD',stage_games=totals,memory_games=972,VERIFY_games=24,cost_games=855,engine_launched=False),indent=2))

def seal(a):
    inputs=a.inputs.resolve();context,_,plans=c.guard(inputs,sealed=False)
    assert not (inputs/'seal.json').exists(), 'Preserve sealed packet; use a fresh directory for rebind'
    assert re.fullmatch('[0-9a-f]{64}',a.pgo_sha256 or ''), 'Explicit actual fresh PGO SHA256 required'
    binary=Path(context['binary']);assert c.sha(binary)==a.pgo_sha256
    assert binary.parent.joinpath('SRC_TREE').read_text().strip()==context['expected_source']
    primary=c.read(inputs/'primary-quality-plan.json');primary['binary_sha256']=a.pgo_sha256;c.write(inputs/'primary-quality-plan.json',primary)
    schedule=c.read(inputs/'final-runtime-plan.json');schedule['primary_quality']=primary;c.write(inputs/'final-runtime-plan.json',schedule)
    files={str(p):c.sha(p) for p in inputs.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'runs' not in p.parts}
    c.write(inputs/'seal.json',dict(source_tree=context['expected_source'],binary=str(binary),binary_sha256=a.pgo_sha256,files=files,reporter=str(inputs/'helpers/report_final_results.py'),commit=c.git(Path(context['worktree']),'rev-parse','HEAD'),sealed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),no_actual_runs_claimed=True))
    c.guard(inputs);print(json.dumps(dict(sealed=True,source=context['expected_source'],PGO_sha256=a.pgo_sha256,engine_launched=False),indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='action',required=True)
    x=sub.add_parser('prepare');x.add_argument('--worktree',type=Path,required=True);x.add_argument('--expected-source',required=True);x.add_argument('--bin',type=Path,required=True);x.add_argument('--inputs',type=Path,required=True)
    x=sub.add_parser('seal');x.add_argument('--inputs',type=Path,required=True);x.add_argument('--pgo-sha256',required=True)
    x=sub.add_parser('check');x.add_argument('--inputs',type=Path,required=True)
    a=p.parse_args()
    if a.action=='prepare':prepare(a)
    elif a.action=='seal':seal(a)
    else:
        ctx,_,_=c.guard(a.inputs,sealed=(a.inputs/'seal.json').exists());print(json.dumps(dict(prepared_source=ctx['expected_source'],sealed=(a.inputs/'seal.json').exists(),stage_games=ctx['totals'],engine_launched=False),indent=2))
if __name__=='__main__':main()
