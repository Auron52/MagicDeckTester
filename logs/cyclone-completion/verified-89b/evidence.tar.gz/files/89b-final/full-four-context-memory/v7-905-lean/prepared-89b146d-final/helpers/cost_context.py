"""Adapt the existing855 cost math to this packet's common guard/metadata."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import v6_common as c
INPUTS=HERE.parent
_context=c.read(INPUTS/'context.json')
ROOT=Path(_context['worktree']);SRC=_context['expected_source']
BINSHA=c.read(INPUTS/'seal.json')['binary_sha256'] if (INPUTS/'seal.json').exists() else None
PRIOR695=INPUTS/'prior695-recipe'
sha=c.sha
read=c.read
save=c.write
def guard():
    _,seal,plans=c.guard(INPUTS);p=plans['cost'];return seal,p,c.read(p['manifest'])['jobs']
def prerequisites():return c.prerequisites(INPUTS)
def other_stages_receipt(path):return c.receipt(INPUTS,path)
def validate_results(jobs,plan,seal):return c.validate_results(INPUTS,jobs,plan)
