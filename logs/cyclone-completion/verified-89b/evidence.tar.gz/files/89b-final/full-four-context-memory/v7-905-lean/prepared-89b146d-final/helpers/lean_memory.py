"""Lean final-source memory proof; prior-source shapes remain observational."""
from pathlib import Path
import v6_common as c

FIELDS=('win','digest','units')

def compare(base,trial,expected):
    result=dict(expected=expected,compared=0,differences=[],problems=[])
    for cell,rows in trial['data'].items():
        control=base['data'].get(cell,{})
        if len(rows)!=trial['expected'][cell] or set(rows)!=set(control):
            result['problems'].append(dict(cell=cell,error='Missing or different physical game identities'))
        for key in sorted(set(rows)&set(control)):
            result['compared']+=1
            changed=[field for field in FIELDS if rows[key][field]!=control[key][field]]
            if changed:result['differences'].append(dict(cell=cell,seed=key[0],gi=key[1],changed=changed,normal32={k:control[key][k] for k in FIELDS},trial={k:rows[key][k] for k in FIELDS}))
    result['exact']=result['compared']==expected and not result['differences'] and not result['problems']
    return result

def pressure_ok(pressure,tiny=False,unbounded=False):
    pool=pressure['plan_pool']
    return (not pressure['problems'] and pool is not None
            and (not tiny or pool['budget_kb']==20480 and pool['refused_stores']>0)
            and (not unbounded or pool['budget_kb']==0))

def analyze(inputs,plans,reader,observe=False):
    stages=('memory1','memory32','memory-tiny32','memory-unbounded32')
    result=dict(scope='Fresh final-source core1vs32/tiny32/unbounded32; normal32 shapes complete. No final-source6/12/24 proof claimed.',comparisons={},cache_pressure={},fidelity={},problems=[],shape_observations={})
    datasets={}
    for name in stages:
        plan=plans[name];jobs=c.read(plan['manifest'])['jobs'];wins=Path(plan['stdout']).parent/'wins'
        data=reader.load_cells(jobs,wins);datasets[name]=data
        result['problems'] += [dict(stage=name,**p) for p in data['problems']]
        pressure=reader.cache_pressure(plan['stderr']);result['cache_pressure'][name]=pressure
        result['problems'] += [dict(stage=name,error=p) for p in pressure['problems']]
        result['fidelity'][name]=reader.memory_diagnostics(plan['stderr'],plan)
    base=datasets['memory32']
    for name in stages:
        if name!='memory32':result['comparisons'][name]=compare(base,datasets[name],168)
    result['normal32_complete']=not base['problems'] and sum(len(x) for x in base['data'].values())==468
    result['tiny32_positive20MiB']=pressure_ok(result['cache_pressure']['memory-tiny32'],tiny=True)
    result['unbounded32_budget_proven']=pressure_ok(result['cache_pressure']['memory-unbounded32'],unbounded=True)
    result['FSL_review_required']=any((p['fsl_refused_stores'] or 0)>0 or p['fsl_warnings'] for p in result['cache_pressure'].values())
    result['fidelity_clean']=all(x['clean'] for x in result['fidelity'].values())
    result['V6_proof_pass']=(not result['problems'] and result['normal32_complete'] and all(x['exact'] for x in result['comparisons'].values()) and result['tiny32_positive20MiB'] and result['unbounded32_budget_proven'] and all(pressure_ok(p) for p in result['cache_pressure'].values()) and result['fidelity_clean'] and not result['FSL_review_required'])
    if observe:
        historical=c.read(inputs/'v5-shape-observation.json')
        shape_names={j['name'] for j in historical['jobs']}
        shapes=dict(data={k:v for k,v in base['data'].items() if k in shape_names},expected={k:v for k,v in base['expected'].items() if k in shape_names},problems=[])
        assert sum(shapes['expected'].values())==300
        for run in historical['runs']:
            assert all(c.sha(p)==h for p,h in run['files'].items()), 'Historical V5 shape evidence changed'
            trial=reader.load_cells(historical['jobs'],Path(run['wins']))
            observation=compare(shapes,trial,300);observation['problems']+=trial['problems'];observation['exact']=observation['exact'] and not trial['problems']
            result['shape_observations'][run['name']]=observation
        result['historical_shape_scope']=dict(source_tree=historical['source_tree'],binary_sha256=historical['binary_sha256'],note='Cross-source observational comparison; differences do not establish a thread defect, equality does not supply final-source6/12 checks. Does not change V6_proof_pass.')
    return result
