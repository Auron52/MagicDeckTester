#!/usr/bin/env python3
"""Report the closed V6 quiet855 only. Never starts an engine or updates suite GT.

--self-test uses synthetic parser/math data. --output requires the real exclusive
DONE/0 result and all855 identities; missing/partial/mixed results produce no report.
"""
import argparse
import collections
import importlib.util
import json
import math
import random
import re
from pathlib import Path

if not __debug__:
    raise SystemExit('Safety guards require ordinary Python execution.')
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('quiet_launcher',HERE/'cost_context.py')
launch=importlib.util.module_from_spec(spec);spec.loader.exec_module(launch)

def percentile(values,p):
    values=sorted(values); index=(len(values)-1)*p
    low=int(index); high=min(low+1,len(values)-1)
    return values[low]+(values[high]-values[low])*(index-low)

def interval(values):
    n=len(values);mean=sum(values)/n
    return dict(p025=percentile(values,.025),p975=percentile(values,.975),
        bootstrap_se=math.sqrt(sum((x-mean)**2 for x in values)/(n-1)) if n>1 else None)

def parse_summaries(text,jobs):
    found={}
    pattern=re.compile(r'^(\S+): played=(\d+) avg=([\d.]+) digest=(\S+) ms=(\d+) units=(\d+)$')
    for line in text.splitlines():
        if m:=pattern.fullmatch(line):
            assert m[1] not in found, 'Duplicate completion marker: '+m[1]
            found[m[1]]=dict(games=int(m[2]),raw_avg=m[3],raw_digest=m[4],ms=int(m[5]),units=int(m[6]))
    assert set(found)=={j['name'] for j in jobs}, 'Missing/unexpected completion markers'
    assert all(found[j['name']]['games']==j['games'] for j in jobs), 'Incomplete completion marker'
    footer=f"=== BATCH done ({len(jobs)} jobs, {sum(j['games'] for j in jobs)} games) ==="
    assert text.splitlines().count(footer)==1, 'Missing/duplicate exact BATCH footer'
    return found

def sampled_mean(chunks,indices):
    return sum(chunks[i]['ms'] for i in indices)/sum(chunks[i]['games'] for i in indices)

def contrast_key(old,new):
    return new+'-vs-'+old

def bootstrap(cells,pairs,iterations=10000,seed=8552026):
    rng=random.Random(seed);gates={a:[] for a in ('live','pb_on','pb_keep_myriad')}
    contrasts={contrast_key(old,new):dict(delta=[],ratio=[]) for old,new in pairs}
    hinata=[k for k in cells if cells[k]['arm']=='hinata' and cells[k]['searched']]
    live=[k for k in cells if cells[k]['arm']=='live']
    arms={arm:[k for k in cells if cells[k]['arm']==arm and cells[k]['searched']] for arm in gates}
    for _ in range(iterations):
        sampled={}
        for old in live:
            group=[old,old.replace('_live_','_pb_on_'),old.replace('_live_','_pb_keep_myriad_')]
            aa=cells[old]['chunks'];picks=[rng.randrange(len(aa)) for _ in aa]
            for name in group:
                cc=cells[name]['chunks'];assert [(x['seed'],x['gi'],x['games']) for x in aa]==[(x['seed'],x['gi'],x['games']) for x in cc]
                sampled[name]=sampled_mean(cc,picks)
        for old,new in pairs:
            key=contrast_key(old,new);contrasts[key]['delta'].append(sampled[new]-sampled[old]);contrasts[key]['ratio'].append(sampled[new]/sampled[old])
        for name in hinata:
            aa=cells[name]['chunks'];sampled[name]=sampled_mean(aa,[rng.randrange(len(aa)) for _ in aa])
        yardstick=max(sampled[k] for k in hinata)
        for arm in gates:gates[arm].append(max(sampled[k] for k in arms[arm])/yardstick)
    return dict(method='Descriptive percentile cluster bootstrap: resample chunks within original seed/configuration, sharing indices across allthree matched Cyclone arms; independent Hinata chunks; recompute every deck maximum per draw. No per-game wall variance is invented.',
        iterations=iterations,seed=seed,
        limitations='Only2-4 Cyclone chunks per logical cell and8/15 Hinata chunks; intervals are coarse and conditional on this sample/quiet schedule. Host/compiler systematics are omitted. This does not change the existing point-estimate3x gate.',
        gates={a:interval(v) for a,v in gates.items()},contrasts={k:{metric:interval(values) for metric,values in row.items()} for k,row in contrasts.items()})

def self_test():
    jobs=[dict(name='x',games=1)]
    text='x: played=1 avg=4.0000 digest=abc ms=10 units=9\n=== BATCH done (1 jobs, 1 games) ===\n'
    assert parse_summaries(text,jobs)['x']['ms']==10
    for bad in (text.splitlines()[0],text+text,text.replace('played=1','played=0')):
        try:parse_summaries(bad,jobs)
        except AssertionError:pass
        else:raise RuntimeError('Incomplete/duplicate parser input accepted')
    cells={}
    for name,arm,ms in [('cyclone_live_d3_s1','live',20),('cyclone_pb_on_d3_s1','pb_on',10),('cyclone_pb_keep_myriad_d3_s1','pb_keep_myriad',5),('hinata_d5_s1','hinata',5)]:
        cells[name]=dict(arm=arm,searched=True,chunks=[dict(ms=ms,games=1,seed=i,gi=i) for i in range(3)])
    b=bootstrap(cells,[('cyclone_live_d3_s1','cyclone_pb_on_d3_s1'),('cyclone_pb_on_d3_s1','cyclone_pb_keep_myriad_d3_s1')],iterations=100)
    assert b['gates']['live']['p025']==b['gates']['live']['p975']==4
    assert b['gates']['pb_on']['p025']==b['gates']['pb_on']['p975']==2
    assert b['gates']['pb_keep_myriad']['p025']==b['gates']['pb_keep_myriad']['p975']==1
    assert b['contrasts']['cyclone_pb_on_d3_s1-vs-cyclone_live_d3_s1']['ratio']['p025']==.5
    assert b['contrasts']['cyclone_pb_keep_myriad_d3_s1-vs-cyclone_pb_on_d3_s1']['ratio']['p025']==.5
    print(json.dumps(dict(self_test='PASS',checks=['complete parser','missing footer rejected','duplicates rejected','incomplete game rejected','constant bootstrap gates','paired chunk ratio']),indent=2))

def report(output):
    seal,plan,jobs=launch.guard()
    run=Path(plan['stdout']).parent
    assert not output.is_relative_to(run) and not output.is_relative_to(launch.INPUTS) and not output.is_relative_to(launch.ROOT), 'Reports must use a fresh analysis directory outside runtime/guarded inputs/source'
    done=launch.read(run/'DONE');status=launch.read(run/'status.json')
    assert done==status and done['status']=='DONE' and done['returncode']==0, 'Exclusive DONE0 absent/inconsistent'
    assert done['source_tree']==launch.SRC and done['binary_sha256']==launch.BINSHA
    assert done['argv']==plan['argv'] and done['cwd']==plan['cwd'] and done['env']==plan['env']
    assert done['guard_sha256']==launch.sha(launch.INPUTS/'seal.json'), 'Runtime guard bytes changed'
    assert done['quiet_start']['load_average'][0]<=2 and done['quiet_start']['active_cpus_one_second']<=2
    assert not done['competing_process_samples'], 'Mixed-host process sample invalidates timing'
    launch.prerequisites()
    receipt=done['other_selected_stages']
    assert launch.sha(receipt['path'])==receipt['sha256'];launch.other_stages_receipt(receipt['path'])
    validated=launch.validate_results(jobs,plan,seal)
    assert validated==done['result_validation'], 'Closed result hashes changed'
    summaries=parse_summaries(Path(plan['stdout']).read_text(),jobs)
    err=Path(plan['stderr']).read_text(errors='replace')
    play={}
    for line in err.splitlines():
        if m:=re.match(r'^\[play\] (\S+) depth=(\d+) budget=(\d+)ms source=(\S+) provider=(\S+)',line):
            assert m[1] not in play, 'Duplicate play apparatus line'
            play[m[1]]=dict(depth=int(m[2]),budget_ms=int(m[3]),source=m[4],provider=m[5])
    assert set(play)=={j['name'] for j in jobs}, 'Effective searched configuration evidence absent'
    r_spec=importlib.util.spec_from_file_location('cost_result_reader',seal['reporter'])
    reader=importlib.util.module_from_spec(r_spec);r_spec.loader.exec_module(reader)
    wins=run/'wins';cells={};rows={}
    for j in jobs:
        name=j['name'];cell=re.sub(r'_off\d+$','',name)
        arm='hinata' if name.startswith('hinata_') else 'pb_on' if '_pb_on_' in name else 'pb_keep_myriad' if '_pb_keep_myriad_' in name else 'live'
        item=cells.setdefault(cell,dict(arm=arm,games=0,total_ms=0,total_units=0,chunks=[],effective_play=play[name],searched=play[name]['depth']>0 and play[name]['budget_ms']>0))
        assert item['effective_play']==play[name], 'Chunk play settings differ within logical cell'
        game_rows=reader.read_job(j,wins);assert len(game_rows)==j['games']
        assert summaries[name]['units']==sum(x['units'] for x in game_rows.values()), 'Summary/per-game units disagree'
        assert not set(rows.setdefault(cell,{}))&set(game_rows), 'Duplicate physical identity within cell'
        rows[cell].update(game_rows)
        item['games']+=j['games'];item['total_ms']+=summaries[name]['ms'];item['total_units']+=summaries[name]['units']
        item['chunks'].append(dict(name=name,seed=j['seed'],gi=j.get('game_index',0),games=j['games'],ms=summaries[name]['ms'],units=summaries[name]['units'],ms_per_game=summaries[name]['ms']/j['games']))
    for name,item in cells.items():
        item['chunks'].sort(key=lambda c:c['gi'])
        item.update(ms_per_game=item['total_ms']/item['games'],units_per_game=item['total_units']/item['games'],
            wins=sum(r['win']>0 for r in rows[name].values()),mean_penalized_win_round=sum(r['score'] for r in rows[name].values())/item['games'])
    assert sum(v['games'] for v in cells.values())==855
    controls=[name for name in cells if cells[name]['arm']=='live']
    assert len(controls)==5
    pairs=[]
    for old in controls:
        pb=old.replace('_live_','_pb_on_');package=old.replace('_live_','_pb_keep_myriad_')
        assert pb in cells and package in cells
        pairs.extend([(old,pb),(old,package),(pb,package)])
    contrasts={}
    for old,new in pairs:
        assert cells[old]['games']==cells[new]['games'] and cells[old]['effective_play']==cells[new]['effective_play']
        key=contrast_key(old,new)
        contrasts[key]=dict(control=old,candidate=new,quality=reader.paired(rows[old],rows[new],cells[old]['games']),
            old_ms_per_game=cells[old]['ms_per_game'],new_ms_per_game=cells[new]['ms_per_game'],
            paired_chunk_ms_delta=cells[new]['ms_per_game']-cells[old]['ms_per_game'],
            paired_chunk_ms_ratio=cells[new]['ms_per_game']/cells[old]['ms_per_game'])
        assert contrasts[key]['quality']['complete'] and not contrasts[key]['quality']['unpaired_old'] and not contrasts[key]['quality']['unpaired_new']
    hinata={n:c for n,c in cells.items() if c['arm']=='hinata' and c['searched']}
    reference=max(hinata,key=lambda n:hinata[n]['ms_per_game']);yardstick=hinata[reference]['ms_per_game']
    gates={}
    for arm in ('live','pb_on','pb_keep_myriad'):
        candidates={n:c for n,c in cells.items() if c['arm']==arm and c['searched']}
        worst=max(candidates,key=lambda n:candidates[n]['ms_per_game']);ratio=candidates[worst]['ms_per_game']/yardstick
        gates[arm]=dict(worst_searched_cell=worst,cost_per_game_ms=candidates[worst]['ms_per_game'],
            same_run_hinata_worst_cell=reference,hinata_cost_per_game_ms=yardstick,ratio=ratio,limit=3,
            observed_point_gate='PASS' if ratio<=3 else 'FAIL',
            each_row_ratio={n:c['ms_per_game']/yardstick for n,c in candidates.items()},
            unit_ratio_at_wall_worst=candidates[worst]['units_per_game']/hinata[reference]['units_per_game'])
    uncertainty=bootstrap(cells,pairs)
    for arm,g in gates.items():
        g['descriptive_chunk_bootstrap']=uncertainty['gates'][arm]
        lo,hi=(uncertainty['gates'][arm][k] for k in ('p025','p975'))
        g['interval_vs_bar']='entirely_below_or_at3' if hi<=3 else 'entirely_above3' if lo>3 else 'crosses3_marginal'
    for old,c in contrasts.items():c['wall_uncertainty']=uncertainty['contrasts'][old]
    original=launch.read(launch.INPUTS/'cost_gate_live.json')['jobs'];original_names={j['name'] for j in original}
    result=dict(complete=True,source_tree=launch.SRC,binary_sha256=launch.BINSHA,
        methodology='Original suite gate: max(sum exact job ms / completed games) across searched depth>0,budget>0 logical seed/configuration cells, divided by same-run Hinata maximum. BatchRunner ms is summed integer steady-clock per-game wall duration, historically called core-ms; it is not measured thread CPU or batch makespan.',
        quiet_provenance=done,primary_quality_timing_used=False,
        manifest_sha256=launch.sha(launch.INPUTS/'cost_gate_arms.json'),stdout_sha256=launch.sha(plan['stdout']),stderr_sha256=launch.sha(plan['stderr']),
        original535_view=dict(input_manifest=str(launch.INPUTS/'cost_gate_live.json'),sha256=launch.sha(launch.INPUTS/'cost_gate_live.json'),jobs=len(original),games=535,
            original_manifest_job_order=[j['name'] for j in original],
            completion_summaries={n:summaries[n] for n in sorted(original_names)},logical_cells={n:c for n,c in cells.items() if c['arm'] in ('live','hinata')},gate=gates['live']),
        shared_hinata_games=375,PB_on_extra_games=160,PB_KEEP_MYRIAD_extra_games=160,total_games=855,total_jobs=86,cells=cells,candidate_contrasts=contrasts,gates=gates,uncertainty=uncertainty,
        raw_result_hashes=validated,logical_games={name:[{k:r[k] for k in ('seed','gi','win','digest','units','job_name')} for _,r in sorted(data.items())] for name,data in rows.items()},
        fidelity_note='Quiet timing uses its controlled cost environment; FD/nonconv oracles are not enabled here. Candidate quality evidence is separate. V5 histories are not relabelled as fresh integrated-source quality.',
        determinism_warning_lines=[l for l in err.splitlines() if '[determinism]' in l],
        phasec_package_binding=launch.read(launch.INPUTS/'phasec-recipe-binding.json'),
        decisions='Three configurations are measured without adopting any. PB-only and PB+KEEP_AMEND+KEEP_MYRIAD preserve the current leaf/profile/all other defaults. No policy, suite membership, GT or artifact generation changes; other leaf/Ponder combinations are unmeasured.')
    result['fsl_warning_lines']=[l for l in result['determinism_warning_lines'] if 'WARNING:' in l and 'FSL' in l]
    result['fidelity_diagnostic_lines']=[l for l in err.splitlines() if '[fd-diverge]' in l or '[nonconv]' in l]
    result['requires_additional_review']=bool(result['fsl_warning_lines'] or result['fidelity_diagnostic_lines'])
    prior=launch.read(launch.PRIOR695/'cost_gate_arms.json')['jobs']
    result['preserved695_view']=dict(input_manifest=str(launch.PRIOR695/'cost_gate_arms.json'),
        sha256=launch.sha(launch.PRIOR695/'cost_gate_arms.json'),jobs=70,games=695,
        original_manifest_job_order=[j['name'] for j in prior],
        completion_summaries={j['name']:summaries[j['name']] for j in prior},
        logical_cells={n:c for n,c in cells.items() if c['arm']!='pb_keep_myriad'},
        gates={a:gates[a] for a in ('live','pb_on')},note='Filtered view of this same855 run, not a separate695 measurement.')
    # Nothing is written until the complete provenance/data/quiet checks above pass.
    output.mkdir(parents=True,exist_ok=False)
    launch.save(output/'cost-report.json',result)
    launch.save(output/'original535-view.json',result['original535_view'])
    launch.save(output/'preserved695-view.json',result['preserved695_view'])
    lines=['# V6 quiet855 cost measurement','',result['methodology'],'',
        '| Arm | Worst searched cell | ms/game | Same-run Hinata ms/game | Ratio | Observed3x point gate | Descriptive95% interval |',
        '|---|---|---:|---:|---:|---|---|']
    for arm,g in gates.items():
        ci=g['descriptive_chunk_bootstrap'];lines.append(f"| {arm} | {g['worst_searched_cell']} | {g['cost_per_game_ms']:.3f} | {yardstick:.3f} | {g['ratio']:.3f} | {g['observed_point_gate']} | [{ci['p025']:.3f}, {ci['p975']:.3f}] |")
    lines+=['','Original535 controls are preserved in original535-view.json. Hinata375 games appear once; PB-only adds160 and PB+KEEP_AMEND+KEEP_MYRIAD adds160 matched games. All855 per-game outcomes/digests/units and exact86 job timings were validated after exclusive DONE/0.','',
        '| Candidate contrast | n | Win-round delta ± SE | Faster/slower/tied | Digest changes | Unit ratio | Candidate/control ms ratio |',
        '|---|---:|---:|---|---:|---:|---:|']
    for old,c in contrasts.items():
        q=c['quality'];lines.append(f"| {old} | {q['n']} | {q['delta']:.4f} ± {q['se']:.4f} | {q['faster']}/{q['slower']}/{q['ties']} | {q['digest_changed']} | {q['units_ratio']:.4f} | {c['paired_chunk_ms_ratio']:.4f} |")
    lines+=['',uncertainty['method'],'',uncertainty['limitations'],'',result['fidelity_note'],'',result['decisions']]
    if result['requires_additional_review']:
        lines+=['','Additional review required: FSL admission warnings or unexpected fidelity diagnostics were recorded. These observations must accompany any point-gate interpretation.']
        lines+=['',*result['fsl_warning_lines'],*result['fidelity_diagnostic_lines']]
    (output/'cost-report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(report=str(output/'cost-report.json'),complete=True,gates=gates),indent=2))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--self-test',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args()
    assert a.self_test != bool(a.output), 'Choose --self-test or --output FRESH_DIRECTORY'
    self_test() if a.self_test else report(a.output.resolve())

if __name__=='__main__':main()
