"""Small shared guard/result parser for this source-specific V6 packet."""
import hashlib
import importlib.util
import json
import os
import re
import subprocess
from pathlib import Path

if not __debug__:
    raise SystemExit('Run guarded validation without Python optimization.')

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):Path(p).write_text(json.dumps(value,indent=2)+'\n')
def git(root,*args):
    return subprocess.check_output(['git','-C',str(root),*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'},text=True).strip()
def inventory(directory):
    return {str(p.relative_to(directory)):sha(p) for p in sorted(Path(directory).rglob('*')) if p.is_file()}
def slots(root,expected=760):
    text=(root/'src/ai/HeuristicArm.h').read_text();enum=text[text.index('enum Slot'):];enum=enum[:enum.index('\n};')]
    names=text[text.index('static const char* const kNames[COUNT] = {'):];names=names[:names.index('\n    };')]
    a=re.findall(r'^\s*([A-Z][A-Z0-9_]*)\s*(?:=[^,]+)?\s*,',enum,re.M);b=re.findall(r'^\s*"(MTG_[A-Z0-9_]+)"',names,re.M)
    assert len(a)==len(b)==expected and len(set(a))==len(set(b))==expected, 'Expected'+str(expected)+'distinct slot/name mapping'
    return [[slot,name] for slot,name in zip(a,b)]

def metadata_digest(inputs):
    primary=read(inputs/'primary-quality-plan.json');schedule=read(inputs/'final-runtime-plan.json')
    assert primary==schedule['primary_quality'], 'Standalone/reference metadata disagree'
    primary['binary_sha256']=None;schedule['primary_quality']['binary_sha256']=None
    return hashlib.sha256(json.dumps([primary,schedule],sort_keys=True).encode()).hexdigest()

def guard(inputs,sealed=True):
    inputs=Path(inputs).resolve();context=read(inputs/'context.json');root=Path(context['worktree'])
    assert git(root,'rev-parse','HEAD:src')==context['expected_source'], 'Source changed: prepare a fresh explicitly bound packet'
    assert not git(root,'status','--porcelain','--untracked-files=all','--','src'), 'Dirty/untracked source'
    assert slots(root)==context['slot_mapping'], '760slot mapping changed'
    for deck,expected in context['apparatus'].items():
        assert inventory(root/'decks'/deck)==expected, 'Apparatus bytes/presence changed: '+deck
    assert sha(inputs/'stage-plans.json')==context['stage_plans_sha256'], 'Execution plan changed'
    assert sha(inputs/'apparatus-v5-bridge.json')==context['apparatus_bridge_sha256'], 'Recipe bridge changed'
    for name,expected in context['prepared_files'].items():assert sha(name)==expected, 'Prepared input/helper changed: '+name
    assert metadata_digest(inputs)==context['execution_metadata_sha256'], 'Execution metadata changed beyond explicit PGO binding'
    if sealed:assert (inputs/'seal.json').is_file(), 'Unsealed packet: explicit actual fresh PGO SHA256 is required after build'
    seal=read(inputs/'seal.json') if sealed else None
    if sealed:
        assert seal['source_tree']==context['expected_source'] and seal['binary']==context['binary']
        assert re.fullmatch('[0-9a-f]{64}',seal['binary_sha256']), 'Explicit actual PGO SHA absent'
        assert sha(seal['binary'])==seal['binary_sha256'], 'PGO bytes changed'
        assert Path(seal['binary']).parent.joinpath('SRC_TREE').read_text().strip()==seal['source_tree'], 'PGO source stamp stale'
        for name,expected in seal['files'].items():assert sha(name)==expected, 'Guarded file changed: '+name
    return context,seal,read(inputs/'stage-plans.json')

def reader(inputs):
    spec=importlib.util.spec_from_file_location('v6_result_reader',Path(inputs)/'helpers/report_final_results.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def validate_results(inputs,jobs,plan):
    r=reader(inputs);wins=Path(plan['argv'][plan['argv'].index('--game-log-dir')+1]);counts={}
    for line in Path(plan['stdout']).read_text().splitlines():
        if m:=re.fullmatch(r'(\S+): played=(\d+) avg=[\d.]+ digest=\S+ ms=(\d+) units=(\d+)',line):
            assert m[1] not in counts, 'Duplicate completion marker'
            counts[m[1]]=(int(m[2]),int(m[4]))
    assert set(counts)=={j['name'] for j in jobs}, 'Missing/unexpected completed jobs'
    footer=f"=== BATCH done ({len(jobs)} jobs, {sum(j['games'] for j in jobs)} games) ==="
    assert Path(plan['stdout']).read_text().splitlines().count(footer)==1, 'Full batch footer absent/duplicated'
    proof={}
    for j in jobs:
        rows=r.read_job(j,wins)
        assert counts[j['name']]==(j['games'],sum(x['units'] for x in rows.values())), 'Summary/per-game units or count mismatch'
        proof[j['name']]=dict(games=len(rows),wins_sha256=sha(wins/(j['name']+'.wins')),units_sha256=sha(wins/(j['name']+'.units')))
    return proof

def done(inputs,name):
    context,seal,plans=guard(inputs);plan=plans[name];run=Path(plan['stdout']).parent
    status=read(run/'status.json');assert status==read(run/'DONE') and status['status']=='DONE' and status['returncode']==0, 'Stage lacks exclusive DONE0: '+name
    assert status['source_tree']==seal['source_tree'] and status['binary_sha256']==seal['binary_sha256']
    assert status['argv']==plan['argv'] and status['env']==plan['env'] and status['cwd']==plan['cwd']
    assert status['guard_sha256']==sha(Path(inputs)/'seal.json'), 'Runtime used a different seal'
    jobs=read(plan['manifest'])['jobs'];assert validate_results(inputs,jobs,plan)==status['result_validation']
    return status

def prerequisites(inputs):
    return {name:done(inputs,name) for name in ('memory1','memory32','memory-tiny32','memory-unbounded32','verify')}

def receipt(inputs,path):
    context,seal,_=guard(inputs);obj=read(path)
    assert obj['source_tree']==seal['source_tree'] and obj['binary_sha256']==seal['binary_sha256']
    assert obj['all_selected_other_stages_closed'] is True and obj['stages']
    assert any(s['kind']=='regression' for s in obj['stages']), 'Reviewed regression closure evidence absent'
    for stage in obj['stages']:
        assert stage['status']=='DONE' and stage['returncode']==0
        assert sha(stage['evidence_path'])==stage['evidence_sha256']
    return dict(path=str(Path(path).resolve()),sha256=sha(path),receipt=obj)

def competitors(exclude=()):
    names={'mtg','mtg.exe','mtg-test','mtg-test.exe','cmake','ninja','make','gmake','cc1','cc1plus','lto1','lto-wrapper','ld','ld.lld','clang','clang++','g++','gcc','collect2'};found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit() or int(p.name) in exclude:continue
        try:
            name=(p/'comm').read_text().strip();state=(p/'stat').read_text().rsplit(')',1)[1].split()[0]
            cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
        except FileNotFoundError:continue
        if state!='Z' and (name in names or name in ('bash','sh') and 'build.sh' in cmd):found.append(dict(pid=int(p.name),name=name,command=cmd))
    return found
