#!/usr/bin/env python3
"""Source-specific closed V6 memory/VERIFY/cost analysis; never starts engines."""
import argparse
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'helpers'))
import v6_common as c
import lean_memory

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['memory','verify','cost']);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--observe-v5-shapes',action='store_true');a=p.parse_args();inputs=a.inputs.resolve();out=a.output.resolve();context,seal,plans=c.guard(inputs)
    assert not out.exists() and not out.is_relative_to(inputs/'runs'), 'Use a fresh analysis output directory'
    if a.mode=='cost':
        c.done(inputs,'cost');raise SystemExit(subprocess.run([sys.executable,str(inputs/'helpers/report_cost.py'),'--output',str(out)]).returncode)
    if a.mode=='verify':
        status=c.done(inputs,'verify');proof=c.read(Path(plans['verify']['stdout']).parent/'verify-exercise.json');assert proof['pass_'];out.mkdir(parents=True);c.write(out/'verify-report.json',dict(source_tree=seal['source_tree'],binary_sha256=seal['binary_sha256'],DONE0=True,exercise=proof,status=status));print(json.dumps(proof,indent=2));return
    names=('memory1','memory32','memory-tiny32','memory-unbounded32');statuses={name:c.done(inputs,name) for name in names}
    report=lean_memory.analyze(inputs,plans,c.reader(inputs),a.observe_v5_shapes)
    report.update(stage_DONE0=statuses,source_tree=seal['source_tree'],binary_sha256=seal['binary_sha256'])
    out.mkdir(parents=True);c.write(out/'memory-report.json',report)
    print(json.dumps(dict(V6_proof_pass=report['V6_proof_pass'],tiny_positive20MiB=report['tiny32_positive20MiB'],FSL_review_required=report['FSL_review_required']),indent=2));raise SystemExit(0 if report['V6_proof_pass'] else 1)
if __name__=='__main__':main()
