#!/usr/bin/env python3
"""Launch one explicitly sealed V6 stage. Root owns scheduling; no builds/timeouts."""
import argparse
import datetime
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent/'helpers'))
import v6_common as c

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp');c.write(tmp,obj);tmp.replace(path)
def quiet():
    assert not c.competitors(), 'Other engine/build active; root must release V5 lease and finish all heavy work'
    def sample():
        xs=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9]));return sum(xs),xs[3]+xs[4]
    start=time.monotonic();a=sample();time.sleep(1);b=sample();elapsed=time.monotonic()-start
    busy=((b[0]-a[0])-(b[1]-a[1]))/os.sysconf('SC_CLK_TCK')/elapsed;load=os.getloadavg()
    assert busy<=2 and load[0]<=2 and not c.competitors(), 'Host is not quiet'
    return dict(at=now(),load_average=load,active_cpus_one_second=busy)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',choices=['memory1','memory32','memory-tiny32','memory-unbounded32','verify','cost']);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--closed-stages',type=Path);p.add_argument('--quiet-host-reviewed',action='store_true');p.add_argument('--dry-run',action='store_true');a=p.parse_args()
    inputs=a.inputs.resolve();context,seal,plans=c.guard(inputs);plan=plans[a.stage];jobs=c.read(plan['manifest'])['jobs']
    if a.dry_run:print(json.dumps(dict(plan=plan,source_tree=seal['source_tree'],binary_sha256=seal['binary_sha256'],engine_launched=False),indent=2));return
    visible=c.competitors()
    assert not any(context['forbidden_active_V5_binary'] in p['command'] for p in visible), 'Frozen V5 engine active: root must release its lease first'
    prior={};other=None;quiet_start=None
    if a.stage=='cost':
        assert a.quiet_host_reviewed and a.closed_stages, 'Cost requires root quiet scheduling and reviewed closure evidence'
        prior=c.prerequisites(inputs);other=c.receipt(inputs,a.closed_stages);quiet_start=quiet()
    # All inherited MTG settings are explicitly cleared before configured stage
    # settings: this includes new760-slot defaults and unregistered diagnostics.
    env=dict(os.environ);cleared=sorted(k for k in env if k.startswith('MTG_'))
    for key in cleared:env.pop(key)
    env.update(plan['env']);env['GIT_OPTIONAL_LOCKS']='0'
    c.guard(inputs);run=Path(plan['stdout']).parent;run.mkdir(parents=True,exist_ok=False)
    Path(plan['argv'][plan['argv'].index('--game-log-dir')+1]).mkdir()
    record=dict(stage=a.stage,name=plan['name'],owner_pid=os.getpid(),started=now(),argv=plan['argv'],cwd=plan['cwd'],env=plan['env'],cleared_inherited_MTG_names=cleared,source_tree=seal['source_tree'],binary_sha256=seal['binary_sha256'],guard_sha256=c.sha(inputs/'seal.json'),status='STARTING',stdout=plan['stdout'],stderr=plan['stderr'],quiet_start=quiet_start,prerequisites=prior,other_selected_stages=other,competing_process_samples=[])
    save(run/'status.json',record);child=None;rc=1
    def forward(sig,frame):
        if child is not None and child.poll() is None:os.killpg(child.pid,sig)
    signal.signal(signal.SIGINT,forward);signal.signal(signal.SIGTERM,forward)
    try:
        with Path(plan['stdout']).open('x') as out,Path(plan['stderr']).open('x') as err:
            child=subprocess.Popen(plan['argv'],cwd=plan['cwd'],env=env,stdout=out,stderr=err,start_new_session=True)
            record.update(status='RUNNING',child_pid=child.pid);save(run/'status.json',record);print(json.dumps(dict(child_pid=child.pid,status=str(run/'status.json')),indent=2),flush=True)
            while True:
                try:rc=child.wait(timeout=15);break
                except subprocess.TimeoutExpired:
                    if a.stage=='cost':
                        try:found=c.competitors(exclude=(child.pid,))
                        except Exception as error:found=[dict(monitor_error=str(error))]
                        if found:record['competing_process_samples'].append(dict(at=now(),processes=found));save(run/'status.json',record)
        assert rc==0, 'Engine exited '+str(rc)
        c.guard(inputs);record['result_validation']=c.validate_results(inputs,jobs,plan)
        if a.stage=='verify':
            result=run/'verify-exercise.json'
            with result.open('x') as f:rc=subprocess.run([sys.executable,str(inputs/'helpers/check_small_verify.py'),plan['stdout'],plan['stderr']],stdout=f).returncode
            assert rc==0, 'VERIFY counters missing or mismatch'
        if a.stage=='cost':
            assert not record['competing_process_samples'], 'Competing process invalidated quiet measurement'
            assert c.sha(a.closed_stages)==other['sha256'];c.receipt(inputs,a.closed_stages)
        record.update(status='DONE',returncode=0,finished=now())
    except Exception as error:record.update(status='STOPPED',returncode=rc if rc else 2,error=str(error),finished=now())
    save(run/'status.json',record);save(run/record['status'],record);raise SystemExit(record['returncode'])
if __name__=='__main__':main()
