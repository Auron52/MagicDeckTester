# Fresh 89b Claude sweep: separate post-run audit closure

All 15 real Claude CLI executions (native `claude-sonnet-5`) and their engine games completed. This separate read-only recovery validates all 15 from the immutable raw streams. No models or engines were replayed. All 15 structured answers report zero flags; none beats its paired AI benchmark. This is a correctness backstop, not an independent quality/adoption sample or a proof of all branches.

The original controller really exited **2**, leaving 14 validated receipts and one exact-command audit rejection. Its `INCOMPLETE.json`, `CLAUDE-FAILED.json`, sealed plan, original verifier and raw outputs remain intact. All 1,931 original files hash-identical before/after; see `original-immutability.json`. Only the separate recovery is closed.

The one additional exact root-audited command was `cat` of Claude's native persisted output. The preceding actual wrapper command produced decision25/T7; its native persisted file, the cat's persisted output and actual `steps/0025.stdout` are all 30,919 identical bytes (SHA263d94a801f712118a26e88f45cd3173917bddd3d1fc505416dc015be0348a4f). A subsequent successful native Read delivered that exact full output. `native-cat-audit.json` records tool IDs and ordering. The verifier was copied byte-for-byte; the sole whitelist addition is this exact command, after provenance verification. Arbitrary cat/shell suffixes remain forbidden.

`guard-tests.json` has ten passing actual-event/negative checks, preserving native Claude identity, full22 successful card Read before Bash, complete real step/result chain, literal string metadata support, true final choice/win claims and engine closure. `recovered/` holds separate receipts; `RECOVERY-REPORT.json` is authoritative. `CLOSURE.json` records a fresh check-only pass and artifact hashes.

The actual saved frames cover 560 decisions across 11 observed types. `observational-types.json` retains exact source-labelled frames, options/variants and per-card classification limits. An observed type does not certify every legal opportunity or every card variant; forced and unobserved paths are not claimed tested.

These are fresh89b executions with the same15 seed identities as the earlier C2 iterative correctness sweep. No prior C2 outcomes or judgments were used to validate them. No source, ground truth, reference or original packet edits.
