#!/usr/bin/env python3
"""Read-only recovery of actual Claude streams. No subprocess/network/engine/model entry points."""
import collections,hashlib,importlib.util,json,re,shlex,sys
sys.dont_write_bytecode=True
from pathlib import Path
ORIGINAL=Path(__file__).resolve().parent
OUT=Path(__file__).resolve().parent

def need(v,msg):
 if not v:raise ValueError(msg)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_new(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def events(path):
 out=[]
 for line in Path(path).read_text().splitlines():
  if not line.strip():continue
  obj=json.loads(line);need(isinstance(obj,dict),'stream event must be object');out.append(obj)
 return out

def transcript(es):
 """System metadata may have string messages; never treat strings as tool objects."""
 calls={};results={};metadata=[];models=set();text_blocks=[]
 for pos,e in enumerate(es):
  typ=e.get('type');msg=e.get('message')
  if typ not in ('assistant','user'):
   if msg is not None:metadata.append({'position':pos,'type':typ,'subtype':e.get('subtype'),'message_shape':type(msg).__name__,'event':e})
   continue
  need(isinstance(msg,dict),'malformed actual assistant/user message')
  if typ=='assistant':
   model=msg.get('model');need(isinstance(model,str),'assistant native model missing');models.add(model)
  content=msg.get('content',[])
  if isinstance(content,str):text_blocks.append({'position':pos,'event_type':typ,'text':content});continue
  need(isinstance(content,list),'content must be list or literal text')
  for block in content:
   if not isinstance(block,dict):
    need(isinstance(block,str),'invalid content block shape');text_blocks.append({'position':pos,'event_type':typ,'text':block});continue
   bt=block.get('type')
   if bt=='tool_use':
    need(typ=='assistant' and isinstance(block.get('id'),str) and isinstance(block.get('input'),dict),'invalid tool-use object')
    identity=block['id']
    if identity in calls:need(calls[identity]['block']==block,'conflicting repeated tool-use ID')
    else:calls[identity]={'position':pos,'block':block}
   if bt=='tool_result':
    need(typ=='user' and isinstance(block.get('tool_use_id'),str),'invalid tool-result object')
    identity=block['tool_use_id']
    if identity in results:need(results[identity]['block']==block,'conflicting repeated tool-result ID')
    else:results[identity]={'position':pos,'block':block}
 return {'calls':calls,'results':results,'metadata':metadata,'models':sorted(models),'non_tool_text_blocks':text_blocks}

def json_payload(raw,kind):
 blocks=re.findall(r'<<<CLAUDE_'+kind+r'>>>\s*(.*?)\s*<<<END_'+kind+r'>>>',raw,re.S);need(len(blocks)==1,'one exact protocol block required');return json.loads(blocks[0])
def normalize_path(value):
 p=Path(value);return (p if p.is_absolute() else ORIGINAL/p).resolve()
def schema(answer):
 need(isinstance(answer,dict) and set(answer)=={'ai_win','claude_win','choices','flags','summary'},'exact final answer fields required')
 for key in ('ai_win','claude_win'):need(type(answer[key]) is int and answer[key] in {-1,*range(1,9)},'invalid win turn')
 need(isinstance(answer['choices'],str) and (not answer['choices'] or re.fullmatch(r'-?\d+(,-?\d+)*',answer['choices'])),'invalid final CSV')
 need(isinstance(answer['summary'],str) and isinstance(answer['flags'],list),'invalid summary/flags')
 for flag in answer['flags']:
  need(isinstance(flag,dict) and {'category','decision_index','choices_prefix','evidence','card_data_basis','rules_basis'}<=set(flag),'flag required evidence fields missing')
  need(type(flag['decision_index']) is int and all(isinstance(flag[k],str) for k in ('category','choices_prefix','evidence','card_data_basis','rules_basis')),'invalid flag value types')
 return True

def verify_game(seed,plan,actual_cli_exit):
 game=ORIGINAL/'games'/str(seed);stream=game/'claude.stream.jsonl';es=events(stream);t=transcript(es);models=t['models']
 need(models and all(v.startswith('claude-') and 'sonnet' in v.lower() for v in models),'NoFakeOracle: actual native Claude Sonnet IDs required')
 finals=[e for e in es if e.get('type')=='result'];need(len(finals)==1 and finals[0].get('subtype')=='success' and finals[0].get('is_error') is False,'actual CLI success result required')
 final=finals[0];usage=final.get('modelUsage',{});need(isinstance(usage,dict) and set(models)<=set(usage),'native model usage attestation missing')
 need(all(v.startswith('claude-') and 'sonnet' in v.lower() for v in usage),'unexpected fallback model usage')
 need(actual_cli_exit==0,'controller attested actual CLI exit must be0')
 running=read(game/'MODEL-RUNNING.json');argv=running['argv'];need(argv[argv.index('--model')+1]=='sonnet' and '--fallback-model' not in argv,'actual requested model differs')
 need(running['source_tree']==plan['source_tree'] and running['binary_sha256']==plan['binary_sha256'],'actual model launch source/binary differs')
 bashcalls=[v for v in t['calls'].values() if v['block'].get('name')=='Bash'];need(bashcalls,'no actual Bash tool calls');firstbash=min(v['position'] for v in bashcalls)
 cards=read(ORIGINAL/'cards22.json');need(len(cards['cards'])==22,'not22 complete card defs');allnames=[c['name'] for c in cards['cards']];reads=[];successful_reads=[]
 for identity,call in t['calls'].items():
  block=call['block']
  if block.get('name')!='Read':continue
  result=t['results'].get(identity);path=normalize_path(block['input'].get('file_path',''))
  if result and result['block'].get('is_error') is not True and result['position']<firstbash and call['position']<firstbash:
   successful_reads.append(str(path))
   if path==(ORIGINAL/'cards22.json').resolve():
    text=json.dumps(result['block'].get('content',''),ensure_ascii=False)
    if all(name in text for name in allnames):reads.append({'tool_use_id':identity,'call_position':call['position'],'result_position':result['position'],'all22_names_present':True})
 need(reads,'NoFakeOracle: successful full22 card Read result before first Bash is mandatory')
 required=[Path(plan['worktree'])/'CLAUDE.md',Path(plan['worktree'])/'.claude/skills/claude-play.md',Path(plan['worktree'])/'.claude/skills/mtg-rules.md',ORIGINAL/'cards22.json',game/'benchmark.json']
 read_status={str(p):str(p.resolve()) in successful_reads for p in required}
 # Card-before-any-Bash stays mandatory; other reads are checked before the first actual game command below.
 successful_commands=[];denied_commands=[];readonly_side_commands=[]
 for call in bashcalls:
  block=call['block'];result=t['results'].get(block['id']);need(result is not None,'Bash tool result missing');command=block['input'].get('command');need(isinstance(command,str),'Bash command missing')
  if result['block'].get('is_error') is True:denied_commands.append({'tool_use_id':block['id'],'command':command,'result':result['block']});continue
  parts=shlex.split(command,comments=True);prefix=['python3',str(ORIGINAL/'sweep.py'),'step','--seed',str(seed),'--choices']
  if not (len(parts)==7 and parts[:6]==prefix):
   need(command in read(OUT/'audited-readonly-commands.json')['commands'],'unexpected successful non-wrapper command; requires root audit')
   readonly_side_commands.append({'command':command,'tool_use_id':block['id'],'classification':'OBSERVED_READONLY_INSTRUCTION_OR_DECK_INSPECTION_NOT_ENGINE_EXECUTION'});continue
  csv=parts[6];need(csv=='' or re.fullmatch(r'-?\d+(,-?\d+)*',csv),'invalid successful CSV');successful_commands.append({'csv':csv,'tool_use_id':block['id'],'position':call['position']})
 need(successful_commands,'no successful real game wrapper calls')
 first_game=min(v['position'] for v in successful_commands)
 instruction_reads={}
 for path in required:
  matches=[(identity,call) for identity,call in t['calls'].items() if call['block'].get('name')=='Read' and normalize_path(call['block']['input'].get('file_path',''))==path.resolve()]
  instruction_reads[str(path)]=any(identity in t['results'] and t['results'][identity]['block'].get('is_error') is not True and call['position']<first_game and t['results'][identity]['position']<first_game for identity,call in matches)
 need(all(instruction_reads.values()),'instruction/rules/benchmark successful Read absent before actual play')
 complete_path=game/'ENGINE-COMPLETE.json';complete=read(complete_path);need(complete['seed']==seed and complete['game_index']==0 and complete['engine_returncode']==0,'actual final engine closure missing')
 actual_csv=complete['choices_csv'];actual_choices=complete['choices'];need(actual_choices==([] if actual_csv=='' else [int(v) for v in actual_csv.split(',')]),'actual final choice representation differs')
 step_paths=sorted((game/'steps').glob('*.json'));need(len(step_paths)==len(actual_choices)+1,'complete no-gap step chain required');step_evidence=[]
 for ordinal,path in enumerate(step_paths):
  r=read(path);need(path.name==f'{ordinal:04d}.json' and r['choices']==actual_choices[:ordinal] and r['choices_csv']==','.join(map(str,r['choices'])),'exact append-only recorded trajectory missing')
  need(r['seed']==seed and r['game_index']==0 and r['source_tree']==plan['source_tree'] and r['binary_sha256']==plan['binary_sha256'],'step source/identity differs')
  need(any(v['csv']==r['choices_csv'] for v in successful_commands),'step lacks actual successful Claude Bash invocation')
  for key in ('stdout','stderr'):need(sha(r[key])==r[key+'_sha256'],'raw engine output hash changed')
  expected_rc=0 if ordinal==len(actual_choices) else 70;need(r['engine_returncode']==expected_rc,'wrong decision/result progression')
  parsed=json_payload(Path(r['stdout']).read_text(),'RESULT' if expected_rc==0 else 'DECISION');need(parsed==r['protocol'],'saved protocol differs from actual raw engine dump')
  av=r['argv'];need(av[0]==plan['binary'] and '--claude-play' in av and av[av.index('--seed')+1]==str(seed) and av[av.index('--game-index')+1]=='0' and av[av.index('--choices')+1]==r['choices_csv'] and av[av.index('--reveal')+1]=='6','actual engine command differs from standard sealed protocol')
  step_evidence.append({'receipt':str(path),'sha256':sha(path),'choices_csv':r['choices_csv'],'engine_returncode':r['engine_returncode'],'actual_type':r['protocol'].get('type')})
 need(read(step_paths[-1])==complete,'ENGINE-COMPLETE does not equal actual terminal step')
 answer=final.get('structured_output')
 if answer is None:answer=json.loads(final['result'])
 schema(answer);need(answer['ai_win']==read(game/'benchmark.json')['ai_win'],'paired AI benchmark changed');need(answer['claude_win']==complete['protocol']['win_turn'] and answer['choices']==actual_csv,'NoFakeOracle: model claim differs from actual terminal result/choices')
 return {'status':'VALIDATED_NEW_ACTUAL_CLAUDE_GAME','seed':seed,'game_index':0,'source_tree':plan['source_tree'],'binary_sha256':plan['binary_sha256'],'requested_model':'sonnet','native_assistant_models':models,'native_model_usage':usage,'actual_cli_exit':0,'live_controller_attested_cli_exit':actual_cli_exit,'stream':{'path':str(stream),'sha256':sha(stream)},'stderr':{'path':str(game/'claude.stderr'),'sha256':sha(game/'claude.stderr')},'model_launch':{'path':str(game/'MODEL-RUNNING.json'),'sha256':sha(game/'MODEL-RUNNING.json')},'engine_complete':{'path':str(complete_path),'sha256':sha(complete_path)},'observed_Reads_before_first_Bash':read_status,'all_instruction_Reads_before_first_game_command':instruction_reads,'readonly_side_commands_retained':readonly_side_commands,'full22_card_Read_witnesses':reads,'retained_metadata_events':t['metadata'],'denied_Bash_attempts_retained':denied_commands,'actual_successful_wrapper_calls':successful_commands,'step_evidence':step_evidence,'answer':answer,'scope':'Fresh actual Claude judgments and current engine trajectory only. V3-compatible metadata parser; no reused old game outcomes. Flags preserved for root verification.'}
