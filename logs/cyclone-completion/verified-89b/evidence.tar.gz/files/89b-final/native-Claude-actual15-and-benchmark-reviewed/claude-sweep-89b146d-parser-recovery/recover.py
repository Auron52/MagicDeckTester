#!/usr/bin/env python3
"""Read-only audit of existing Claude/engine evidence. No engine/model/subprocess calls."""
import copy, datetime, hashlib, importlib.util, json, re, shlex, sys
from pathlib import Path
sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
ORIGINAL = OUT.parent / 'claude-sweep-89b146d'
SPEC = importlib.util.spec_from_file_location('v89_recovery_verifier', OUT / 'oracle_verify.py')
V = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(V)
V.ORIGINAL, V.OUT = ORIGINAL, OUT
COMMAND = 'cat /home/vscode/.claude/projects/-workspaces-MagicDeckTester-build-scratch-cyclone-finish-claude-sweep-89b146d/8f1be110-920d-45cb-aed8-136dc113faab/tool-results/bsme9b8nl.txt'
CAT_ID = 'toolu_01HGhWbcAwcGYuX4HduJx8D2'
STEP_ID = 'toolu_01GnmAw2Svc2pSdfhpvwULdm'
READ_ID = 'toolu_01TFPkTKPyEmRMmfpZqYLw69'
EXPECTED_OUTPUT_SHA = '263d94a801f712118a26e88f45cd3173917bddd3d1fc505416dc015be0348a4f'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_text())
def new(p, d):
    with Path(p).open('x') as f: json.dump(d, f, indent=2); f.write('\n')
def saved_path(result):
    matches = re.findall(r'Full output saved to: ([^\n]+)', result['block']['content'])
    V.need(len(matches) == 1, 'native persisted-output path ambiguous')
    return Path(matches[0])

def audit_cat(es, byte_override=None):
    t = V.transcript(es)
    calls, results = t['calls'], t['results']
    cat, step, rd = calls[CAT_ID], calls[STEP_ID], calls[READ_ID]
    V.need(cat['block']['name'] == 'Bash' and cat['block']['input']['command'] == COMMAND,
           'only the exact root-audited cat command is eligible')
    catpath = Path(shlex.split(COMMAND)[1])
    source = saved_path(results[STEP_ID])
    copy_path = saved_path(results[CAT_ID])
    V.need(catpath == source, 'cat did not read the preceding native wrapper output')
    V.need(step['position'] < results[STEP_ID]['position'] < cat['position'] < results[CAT_ID]['position']
           < rd['position'] < results[READ_ID]['position'], 'native output/read ordering differs')
    for identity in [STEP_ID, CAT_ID, READ_ID]:
        V.need(results[identity]['block'].get('is_error') is not True, 'native source/cat/Read failed')
    step_parts = shlex.split(step['block']['input']['command'])
    receipt = read(ORIGINAL / 'games/1900010/steps/0025.json')
    V.need(step_parts == ['python3', str(ORIGINAL/'sweep.py'), 'step', '--seed', '1900010',
                         '--choices', receipt['choices_csv']], 'persisted source is not actual step25 wrapper')
    V.need(rd['block']['name'] == 'Read' and Path(rd['block']['input']['file_path']) == copy_path,
           'follow-up native Read differs from cat persisted result')
    paths = [source, copy_path, Path(receipt['stdout'])]
    contents = [p.read_bytes() for p in paths] if byte_override is None else byte_override
    V.need(contents[0] == contents[1] == contents[2], 'native persisted copies differ from actual engine stdout')
    V.need(hashlib.sha256(contents[0]).hexdigest() == EXPECTED_OUTPUT_SHA, 'actual native fixture bytes changed')
    parsed = V.json_payload(contents[0].decode(), 'DECISION')
    V.need(parsed == receipt['protocol'] and parsed['decision_index'] == 25 and parsed['turn'] == 7,
           'native output is not the actual recorded protocol')
    read_text = results[READ_ID]['block']['content']
    read_text = re.sub(r'^\s*\d+\t', '', read_text, flags=re.M)
    V.need(read_text.rstrip('\n') == contents[0].decode().rstrip('\n'), 'native Read did not deliver the complete real output')
    return {'classification':'BENIGN_EXACT_NATIVE_PERSISTED_OUTPUT_READ', 'command':COMMAND,
            'source_wrapper_tool_id':STEP_ID, 'source_wrapper_position':step['position'],
            'source_result_position':results[STEP_ID]['position'], 'cat_tool_id':CAT_ID,
            'cat_position':cat['position'], 'cat_result_position':results[CAT_ID]['position'],
            'read_tool_id':READ_ID, 'read_position':rd['position'],
            'read_result_position':results[READ_ID]['position'],
            'files':[{'path':str(p),'bytes':len(c),'sha256':hashlib.sha256(c).hexdigest()} for p,c in zip(paths,contents)],
            'actual_seed':1900010,'decision_index':25,'turn':7,
            'side_effects':'cat only reads an already-produced native output file. No engine or model invocation and no file mutation in this command.',
            'root_authorization':'Root explicitly authorized exact read-only command audit after source/origin/ordering verification.'}

def guard_tests(plan, original_es):
    tests=[]
    def run(name, fn, reject=False):
        try: fn()
        except (ValueError, KeyError) as e:
            if not reject: raise
            tests.append({'name':name,'PASS':True,'rejected':str(e)})
        else:
            V.need(not reject, 'negative guard unexpectedly accepted: '+name)
            tests.append({'name':name,'PASS':True})
    def verify(es):
        previous=V.events
        V.events=lambda _:es
        try: return V.verify_game(1900010, plan, 0)
        finally: V.events=previous
    def mutate(fn):
        es=copy.deepcopy(original_es);fn(es);return es
    run('actual native persisted-output origin/order/content audit',lambda:audit_cat(original_es))
    run('actual complete one-game verifier passes exact extra command audit',lambda:verify(original_es))
    def change_command(es, command):
        for e in es:
            msg=e.get('message')
            if isinstance(msg,dict):
                for x in msg.get('content',[]):
                    if isinstance(x,dict) and x.get('id')==CAT_ID: x['input']['command']=command
    run('another arbitrary cat remains forbidden',lambda:verify(mutate(lambda es:change_command(es,COMMAND+'.other'))),True)
    run('shell suffix remains forbidden',lambda:verify(mutate(lambda es:change_command(es,COMMAND+'; true'))),True)
    def remove_cards(es):
        for e in es:
            msg=e.get('message')
            if isinstance(msg,dict):
                for x in msg.get('content',[]):
                    if isinstance(x,dict) and x.get('name')=='Read' and x.get('input',{}).get('file_path')==str(ORIGINAL/'cards22.json'):
                        x['input']['file_path']=str(ORIGINAL/'not-the-cards.json')
    run('successful full22 card Read before Bash remains required',lambda:verify(mutate(remove_cards)),True)
    def fake_model(es):
        for e in es:
            if e.get('type')=='assistant': e['message']['model']='gpt-not-Claude'
    run('non-Claude model remains rejected',lambda:verify(mutate(fake_model)),True)
    def wrong_claim(es):
        for e in es:
            if e.get('type')=='result': e['structured_output']['claude_win']=1
    run('false terminal win claim remains rejected',lambda:verify(mutate(wrong_claim)),True)
    run('nonzero attested actual CLI exit remains rejected',lambda:V.verify_game(1900010,plan,1),True)
    data=[Path(x['path']).read_bytes() for x in audit_cat(original_es)['files']]
    run('persisted output substitution remains rejected',lambda:audit_cat(original_es,[data[0],b'fake output',data[2]]),True)
    meta=copy.deepcopy(original_es);meta.insert(0,{'type':'system','subtype':'permission_denied','message':'literal native string metadata'})
    run('native string metadata remains accepted without becoming a tool call',lambda:verify(meta))
    return tests

def main():
    before=read(OUT/'original-files-before.json')
    V.need(sha(OUT/'oracle_verify.py')==sha(ORIGINAL/'oracle_verify.py'), 'copied verifier changed; guards must stay exact')
    audit=read(OUT/'audited-readonly-commands.json');old_audit=read(ORIGINAL/'audited-readonly-commands.json')
    V.need(audit['commands']==old_audit['commands']+[COMMAND], 'readonly whitelist widened beyond exact root audit')
    plan=read(ORIGINAL/'sealed-plan.json');es=V.events(ORIGINAL/'games/1900010/claude.stream.jsonl')
    proof=audit_cat(es);new(OUT/'native-cat-audit.json',proof)
    new(OUT/'guard-tests.json',guard_tests(plan,es))
    (OUT/'recovered').mkdir()
    receipts=[]
    for seed in plan['seeds']:
        g=ORIGINAL/'games'/str(seed)
        attestation=read(g/('CLAUDE-FAILED.json' if seed==1900010 else 'CLAUDE-COMPLETE.json'))
        rec=V.verify_game(seed,plan,attestation['actual_cli_exit'])
        rec['recovery_scope']='Separate read-only post-run validation; preserves original controller exit2 and original fourteen validated receipts/one failed audit receipt. No engine/model replay.'
        new(OUT/'recovered'/f'{seed}.json',rec);receipts.append(rec)
    obs_spec=importlib.util.spec_from_file_location('v89_observational',ORIGINAL/'observational_types.py')
    obs=importlib.util.module_from_spec(obs_spec);obs_spec.loader.exec_module(obs)
    records=[];flags=[]
    for rec in receipts:
        flags.extend(dict(flag,seed=rec['seed']) for flag in rec['answer']['flags'])
        for ev in rec['step_evidence']:
            step=read(ev['receipt'])
            if step['engine_returncode']!=70: continue
            step['ref']={'receipt':ev['receipt'],'receipt_sha256':ev['sha256'],
                         'stdout':step['stdout'],'stdout_sha256':step['stdout_sha256']}
            records.append(step)
    observed=obs.summarize(read(ORIGINAL/'expected-decisions.json'),records,flags)
    observed.update(completed_actual_claude_seeds=[r['seed'] for r in receipts],decision_receipts=len(records),
                    expected_manifest=str(ORIGINAL/'expected-decisions.json'),
                    expected_manifest_sha256=sha(ORIGINAL/'expected-decisions.json'),
                    unverified_or_incomplete_game_frames=[])
    new(OUT/'observational-types.json',observed)
    after={str(p.relative_to(ORIGINAL)):sha(p) for p in sorted(ORIGINAL.rglob('*')) if p.is_file()}
    V.need(before==after,'original packet changed during recovery')
    new(OUT/'original-immutability.json',{'all_original_files_identical':True,'files_checked':len(before),
        'before_manifest_sha256':sha(OUT/'original-files-before.json'),'original_controller_exit':2,
        'original_INCOMPLETE_sha256':sha(ORIGINAL/'INCOMPLETE.json'),
        'original_failed_receipt_sha256':sha(ORIGINAL/'games/1900010/CLAUDE-FAILED.json')})
    answers=[{'seed':r['seed'],**r['answer']} for r in receipts]
    earlier=[a for a in answers if a['claude_win']>=0 and (a['ai_win']<0 or a['claude_win']<a['ai_win'])]
    report={'status':'READ_ONLY_POSTRUN_RECOVERY_VALIDATED_15_GENUINE_ACTUAL_CLAUDE_GAMES',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_tree':plan['source_tree'],
        'binary_sha256':plan['binary_sha256'],'actual_original_controller_exit':2,
        'original_controller_status':'INCOMPLETE:14 validation receipts +1 exact-command audit rejection; preserved unchanged',
        'actual_cli_exits':[r['actual_cli_exit'] for r in receipts],
        'native_models':sorted({m for r in receipts for m in r['native_assistant_models']}),
        'genuine_actual_games_validated':len(receipts),'engine_or_model_calls_by_recovery':0,
        'new_exact_readonly_audit':proof,'guard_tests':len(read(OUT/'guard-tests.json')),
        'all_original_files_unchanged':before==after,'reported_flags':sum(len(a['flags']) for a in answers),
        'earlier_win_candidates':earlier,'answers':answers,
        'flag_adjudication':'All fifteen actual answers report zero flags. No earlier-win candidates. No reported flag or candidate remains to adjudicate; this does not certify unobserved branches or solver optimality.',
        'observational_types':str(OUT/'observational-types.json'),
        'limits':'Same15 seed identities as preceding C2 iterative correctness sweep; fresh89b engine/model executions only, no old outcomes carried. No independent quality/adoption inference. Original exit2 not relabeled success; only separate post-run audit closes its single read-only command gate.'}
    new(OUT/'RECOVERY-REPORT.json',report)
    print(json.dumps({k:report[k] for k in ['status','genuine_actual_games_validated','reported_flags','earlier_win_candidates','guard_tests','all_original_files_unchanged']}))

if __name__=='__main__':main()
