Updated-source standard Claude-play correctness packet: source89b146d10406063213d9abe41e1cfdf1a616c021 only. It intentionally repeats seeds1900001–1900015 as iterative correctness tests; it is not a fresh independent quality sample. No old C2 benchmarks, choices, answers, CLI/model receipts or engine outputs are reused. Old C2 packet and v3 recovery remain unchanged. A historical string-metadata fixture is parser-test data only.

PGO SHA is mandatory and currently NULL. Source/appartus/sidecar presence and all22 complete card definitions are freshly bound. No model or engine has been launched by preparation.

After root’s newPGO build, benchmark exactly once (root owns scheduling):
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/claude-sweep-89b146d/benchmark.py --binary-sha256 FINAL_NEW_PGO_SHA256 run
Receipt: benchmark/status.json plus identical benchmark/DONE; one32-requested-worker pool,15games atGI0, fulltraces/wins/units/footer, hermetic observers, no timeout.

Then data-only seal:
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/claude-sweep-89b146d/sweep.py seal --binary-sha256 FINAL_NEW_PGO_SHA256 --benchmark-status /workspaces/MagicDeckTester/build/scratch/cyclone-finish/claude-sweep-89b146d/benchmark/status.json

Only after explicit root launch grant, record that grant and run:
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/claude-sweep-89b146d/sweep.py grant --root-message 'EXPLICIT ROOT GRANT'
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/claude-sweep-89b146d/sweep.py run

The15 actual Sonnet agents each drive one serial source-engine protocol; root may overlap a separate one-worker memory diagnostic (max16 active engines), not another32-worker build/batch. Expected outputs: games/SEED/{claude.stream.jsonl,claude.stderr,ENGINE-COMPLETE.json,CLAUDE-COMPLETE.json}, append-only steps/, and final DONE.json or INCOMPLETE.json with observational-types.json. Actual native model IDs, successful all22-card Read before any Bash, full actual engine-prefix chain, claimed/actual finalCSV and root-owned benchmark are checked. The typed-event parser retains string-valued system metadata and denial/read-only-attempt audits; it never treats metadata strings as tool evidence. No alternative model or automatic policy substitutes.

Prompts read the oversized962-line CLAUDE.md in four explicit256-line chunks (final194), not one oversized Read; require exact absolute step Bash only; and distinguish main_phase enumerated_proposals / not_verified / known_drops from certified payable execution. They verify sequential ritual mana and actual resolution/drop behavior, including interactive fetch-entry choices when reached. Prior10 ritual allegations are not blanket labelled illegal casts (the old7>6 sum ignored Song’s sequential output). No old flag verdict is carried to new games. All new flags still need root card-data/rules review; unobserved types/routes stay unobserved.
