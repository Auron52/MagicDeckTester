#!/usr/bin/env python3
"""Root-owned exact15 paired AI games in one32-worker pool; no timeout or model calls."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys
sys.dont_write_bytecode=True
import sweep as s
HERE=s.HERE

def atomic(path,value):
 temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)
def validate(config,run,status):
 raw=(run/'batch.log').read_text();rows=re.findall(r'^(\S+): played=(\d+) avg=([0-9.]+) digest=([0-9a-f]{16}) ms=(\d+) units=(\d+)$',raw,re.M)
 jobs=s.read(config['benchmark_manifest'])['jobs'];names={j['name'] for j in jobs}
 s.need(len(rows)==15 and len({r[0] for r in rows})==15 and {r[0] for r in rows}==names,'exact15 unique result rows required')
 s.need(re.findall(r'^=== BATCH done \((\d+) jobs, (\d+) games\) ===$',raw,re.M)==[('15','15')],'missing/incorrect batch footer')
 s.need(all(r[1]=='1' for r in rows),'benchmark shortened')
 evidence=s.benchmark(config,run/'status.json');byseed={v['seed']:v for v in evidence['games']}
 for name,played,avg,digest,ms,units in rows:
  j=next(j for j in jobs if j['name']==name);item=byseed[j['seed']]
  s.need(float(avg)==(item['ai_win'] if item['ai_win']>0 else 9) and int(units)==item['units'],'summary score/units differ from physical singleton')
 s.need(not list((run/'wins').glob('*.abandoned')),'benchmark abandoned games')
 diagnostics=[line for line in (run/'batch.err').read_text().splitlines() if '[fd-diverge]' in line or '[nonconv]' in line]
 s.need(not diagnostics,'ordinary benchmark diagnostics require root review; retained in batch.err')
 return dict(footer_exact15=True,result_rows_exact15=True,wins_units_fulltraces_validated=True,ordinary_diagnostic_records=0,paired_games=evidence['games'])

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--binary-sha256',required=True);ap.add_argument('action',choices=('check','run'));a=ap.parse_args()
 config=s.read(s.PREP);config['binary_sha256']=a.binary_sha256;s.source_check(config,True)
 run=Path(config['benchmark_run']);argv=[config['binary'],'--batch',config['benchmark_manifest'],'--cards-json',str(Path(config['worktree'])/'src/cards/data/cards.json'),'--threads','32','--game-log-dir',str(run/'wins'),'--game-trace-dir',str(run/'traces')]
 env={k:v for k,v in os.environ.items() if not k.startswith('MTG_')};mtg=dict(MTG_PGO='1',MTG_DUMP_UNITS='1',MTG_FD_ORACLE='1',MTG_FLAG_NONCONV='1',MTG_SLOW_GAME_MS='1');env.update(mtg);env['GIT_OPTIONAL_LOCKS']='0'
 plan=dict(source_tree=config['source_tree'],src_tree=config['source_tree'],binary_sha256=a.binary_sha256,binary=config['binary'],cwd=config['worktree'],manifest=config['benchmark_manifest'],manifest_sha256=config['benchmark_manifest_sha256'],argv=argv,env=mtg,cleanup_policy='Remove ALL inherited MTG_* keys before applying exact observer-only environment',timeout=None,workers=32,jobs=15,games=15,asset_sha256=config['asset_sha256'],launcher_sha256=s.sha(__file__),sweep_runner_sha256=s.sha(s.__file__))
 if a.action=='check':print(json.dumps(dict(check='PASS',engine_launched=False,plan=plan)));return 0
 run.mkdir(exist_ok=False);(run/'wins').mkdir();(run/'traces').mkdir();s.write_new(run/'launch-plan.json',plan);s.write_new(run/'environment.json',mtg);s.write_new(run/'argv.json',argv)
 status=dict(plan,status='STARTING',started=s.now(),stdout=str(run/'batch.log'),stderr=str(run/'batch.err'));atomic(run/'status.json',status)
 with (run/'batch.log').open('x') as out,(run/'batch.err').open('x') as err:
  child=subprocess.Popen(argv,cwd=config['worktree'],env=env,stdout=out,stderr=err);status.update(status='RUNNING',child_pid=child.pid);atomic(run/'status.json',status);print(json.dumps({'status':'RUNNING','child_pid':child.pid,'status_file':str(run/'status.json')}),flush=True);rc=child.wait()
 status.update(status='DONE' if rc==0 else 'STOPPED',returncode=rc,engine_returncode=rc,finished=s.now());atomic(run/'status.json',status)
 if rc!=0:s.write_new(run/'STOPPED',status);return rc
 try:
  s.source_check(config,True);checked=validate(config,run,status)
 except Exception as error:
  status.update(status='FAILED_VALIDATION',returncode=2,engine_returncode=0,validation_error=repr(error));atomic(run/'status.json',status);s.write_new(run/'FAILED_VALIDATION.json',status);raise
 status.update(validation_pass=True,checks=checked,raw_sha256={n:s.sha(run/n) for n in ('batch.log','batch.err','environment.json','argv.json')});atomic(run/'status.json',status);s.write_new(run/'DONE',status)
 print(json.dumps({'status':'DONE','returncode':0,'validation_pass':True,'paired_games':15,'status_file':str(run/'status.json')}),flush=True);return 0
if __name__=='__main__':raise SystemExit(main())
