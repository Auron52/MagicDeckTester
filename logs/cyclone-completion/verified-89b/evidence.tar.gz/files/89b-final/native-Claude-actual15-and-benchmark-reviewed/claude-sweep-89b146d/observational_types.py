#!/usr/bin/env python3
"""Summarize saved real decision frames; no engine/model calls and no coverage invention."""
import argparse
import collections
import hashlib
import json
from pathlib import Path

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
def summarize(expected,records,model_flags):
 names={c['name'] for c in expected['cards']};types=collections.Counter();attributed=collections.defaultdict(collections.Counter);items=collections.Counter();variants=collections.defaultdict(lambda:collections.defaultdict(dict));markers=collections.defaultdict(collections.Counter);frames=[]
 def variant(card,key,value,ref):
  token=canonical(value);bucket=variants[card][key]
  if token not in bucket:bucket[token]={'value':value,'observations':0,'first_ref':ref}
  bucket[token]['observations']+=1
 for rec in records:
  d=rec['protocol'];ref=rec['ref'];dtype=d.get('type');effective=dtype if dtype is not None else 'LEGACY_MAIN_PHASE_TYPE_NOT_EXPLICIT'
  types[effective]+=1;source=d.get('source','');source_cards=[name for name in names if isinstance(source,str) and name in source]
  for name in source_cards:attributed[name][effective]+=1
  frame={'ref':ref,'seed':rec['seed'],'choices_prefix':rec.get('choices_csv',''),'actual_type':dtype,'source':source,'source_label_cards':sorted(source_cards),'top_level_keys':sorted(d),'variants':{k:d[k] for k in ('operation','away_zone','paid_cast','paid_cost','paid_target','paid_outcome','pay_life','reveal_types','note') if k in d}}
  if dtype=='main_phase':
   for plan in d.get('plans',[]):
    for key,value in plan.items():
     if key not in ('index','summary','casts','actions'):variant('@plan',key,value,dict(ref,plan_index=plan.get('index')))
   frame['offered_plans']=len(d.get('plans',[]));frame['plan_variant_refs']=[]
   for plan in d.get('plans',[]):
    pref=dict(ref,plan_index=plan.get('index'));land=plan.get('land')
    if land in names:
     items[land]+=1
     for key,value in plan.items():
      if key not in ('index','summary','casts','actions','land'):variant(land,'plan.'+key,value,pref)
    for index,act in enumerate(plan.get('actions',[])):
     card=act.get('card');aref=dict(pref,action_index=index)
     if card not in names:continue
     items[card]+=1
     for rider in ('remand_by','remand_chain_by'):
      if act.get(rider) in names:variant(act[rider],'rider.'+rider,{'target_card':card,'rider':act[rider]},aref)
     for key,value in act.items():
      if key!='card':variant(card,'action.'+key,value,aref)
     if act.get('activate'):markers[card]['activate']+=1
     if act.get('verb'):markers[card]['verb:'+act['verb']]+=1
     if act.get('channel'):markers[card]['verb:channel']+=1
     frame['plan_variant_refs'].append(dict(card=card,ref=aref,actual_action_keys=sorted(act)))
  frames.append(frame)
 cards=[]
 for c in expected['cards']:
  name=c['name'];statuses={}
  for dtype in c['expected_types']:
   if dtype=='main_phase' and items[name]:status='PLAN_ITEMS_OFFERED_SUBDECISIONS_REQUIRE_VARIANT_REVIEW'
   elif attributed[name][dtype]:status='OBSERVED_SOURCE_LABELLED_TYPE_OPTIONS_NOT_PROVEN_EXHAUSTIVE'
   elif types[dtype]:status='TYPE_SEEN_ELSEWHERE_THIS_CARD_UNOBSERVED'
   else:status='UNOBSERVED_IN_THIS_SWEEP'
   statuses[dtype]={'status':status,'source_labelled_frames':attributed[name][dtype],'global_frames_of_type':types[dtype]}
  board={m:{'observed_offers':markers[name][m],'status':'OBSERVED_OFFER_NOT_FULL_LEGALITY_PROOF' if markers[name][m] else 'UNOBSERVED_APPLICABILITY_REQUIRES_REVIEW'} for m in c['expected_board_markers']}
  main_surfaces={}
  for param,classification in c.get('parameters',{}).items():
   if classification.get('bucket')!='existing main-phase classification':continue
   if param=='cycling_life_cost':status='COST_ONLY_NO_NEW_CHOOSER_EXPECTED'
   elif param=='cycling_cost':status='OBSERVED_CYCLE_PLAN_ITEM' if canonical(True) in variants[name].get('action.dig',{}) else 'UNOBSERVED_CYCLE_PLAN_ITEM'
   elif param=='counters_target_spell_to_hand':status='OBSERVED_REMAND_RIDER_VARIANT' if variants[name].get('rider.remand_by') or variants[name].get('rider.remand_chain_by') else 'UNOBSERVED_REMAND_RIDER_VARIANT'
   else:status='CLASSIFIED_MAIN_PHASE_SUBDECISION_REQUIRES_VARIANT_REVIEW'
   main_surfaces[param]={'status':status,'existing_reason':classification.get('reason')}
  cards.append({'name':name,'main_phase_surfaces':main_surfaces,'existing_classification':c,'type_observations':statuses,'plan_item_offers':items[name],'actual_variant_fields':{key:list(vals.values()) for key,vals in variants[name].items()},'board_markers':board,'dedicated_type_status':'NO_DEDICATED_TYPE_EXPECTED_PER_EXISTING_CLASSIFICATION' if not statuses else 'SEE_PER_TYPE_OBSERVATIONS'})
 review=[]
 for f in model_flags:
  category=str(f.get('category','')).lower();evidence=str(f.get('evidence','')).lower()
  if any(token in category+' '+evidence for token in ('silent','missing_choice','missing choice','missing decision','auto-resolv','auto resolv')):
   review.append(dict(f,review_status='RULES_REVIEW_REQUIRED_NOT_AUTOMATICALLY_CONFIRMED',note='Check real opportunity, mandatory/optional and forced-choice conditions against card data/rules and exact frames.'))
 return {'scope':'Observed saved actual decision types/variants only. No extra game/protocol probing. Type occurrence is not exhaustive per-card choice coverage; unobserved is not absent or passed. Source-label matching is disclosed, not inferred from battlefield presence.','decision_types':dict(types),'top_level_plan_variants':{key:list(vals.values()) for key,vals in variants['@plan'].items()},'frames':frames,'cards':cards,'silent_or_missing_choice_rules_review':review,'unobserved_expected':[{'card':c['name'],'type':t,'status':r['status']} for c in cards for t,r in c['type_observations'].items() if 'UNOBSERVED' in r['status']],'unclassified_existing_params':[{'card':c['name'],'keys':c['unclassified_params']} for c in expected['cards'] if c['unclassified_params']],'coverage_verdict':'OBSERVATIONAL_ONLY_ROOT_RULES_REVIEW_REQUIRED'}

def build(packet):
 expected=read(packet/'expected-decisions.json');records=[];unverified=[];flags=[];actual=[]
 for game in sorted((packet/'games').iterdir()):
  complete=game/'CLAUDE-COMPLETE.json'
  if complete.exists():
   result=read(complete);actual.append(int(game.name));flags.extend(dict(flag,seed=int(game.name)) for flag in result['answer']['flags'])
  steps=game/'steps'
  if not steps.exists():continue
  for path in sorted(steps.glob('*.json')):
   r=read(path)
   if r['engine_returncode']!=70:continue
   # This exact frame was shown by an actual model's wrapper call; no inferred resolution frames.
   r['ref']={'receipt':str(path),'receipt_sha256':sha(path),'stdout':r['stdout'],'stdout_sha256':r['stdout_sha256']}
   if complete.exists():records.append(r)
   else:unverified.append(dict(seed=int(game.name),ref=r['ref'],actual_type=r['protocol'].get('type'),status='RAW_FRAME_RETAINED_GAME_NOT_YET_VERIFIED_AS_COMPLETE_CLAUDE_ORACLE'))
 report=summarize(expected,records,flags);report.update(expected_manifest=str(packet/'expected-decisions.json'),expected_manifest_sha256=sha(packet/'expected-decisions.json'),completed_actual_claude_seeds=actual,decision_receipts=len(records),unverified_or_incomplete_game_frames=unverified);return report

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--packet',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();report=build(a.packet)
 with a.output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print(json.dumps({'report':str(a.output),'decision_receipts':report['decision_receipts'],'types':report['decision_types'],'unobserved_expected':len(report['unobserved_expected']),'rules_review_candidates':len(report['silent_or_missing_choice_rules_review'])}))
if __name__=='__main__':main()
