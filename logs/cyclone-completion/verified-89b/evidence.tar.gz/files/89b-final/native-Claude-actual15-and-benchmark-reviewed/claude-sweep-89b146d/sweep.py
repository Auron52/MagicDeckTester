#!/usr/bin/env python3
"""Guarded actual-Claude correctness sweep. Preparation/check launch nothing."""
import argparse
import concurrent.futures
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREP=HERE/'preparation.json'
PLAN=HERE/'sealed-plan.json'
GRANT=HERE/'ROOT-LAUNCH-GRANT.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def need(ok,message):
 if not ok:raise ValueError(message)
def write_new(path,value):
 with Path(path).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def git(wt,*args):return subprocess.check_output(['git','--no-optional-locks','-C',wt,*args],text=True).strip()
def source_check(config,binary=False):
 need(config['source_tree']=='89b146d10406063213d9abe41e1cfdf1a616c021','wrong source pin')
 need(git(config['worktree'],'rev-parse','HEAD:src')==config['source_tree'],'source differs')
 need(not git(config['worktree'],'status','--porcelain','--untracked-files=no','--','src'),'dirty source')
 for path,digest in config['asset_sha256'].items():need(sha(path)==digest,'asset differs '+path)
 need(sha(config['cards22'])==config['cards22_sha256'],'card extract changed')
 need(sha(config['expected_decisions'])==config['expected_decisions_sha256'],'expected decision classification changed')
 need(sha(HERE/'observational_types.py')==config['observational_reporter_sha256'],'observational reporter changed')
 need(sha(HERE/'oracle_verify.py')==config['oracle_verifier_sha256'],'robust oracle verifier changed')
 need(sha(HERE/'audited-readonly-commands.json')==config['readonly_audit_sha256'],'readonly attempt audit changed')
 defs=read(config['cards22']);need(len(defs['cards'])==defs['distinct_main_definitions']==22,'need all22 main definitions')
 deck=Path(defs['main_deck']);present={str(p) for p in deck.parent.glob(deck.stem+'.*') if p.is_file()};frozen={p for p in config['asset_sha256'] if Path(p).parent==deck.parent and Path(p).name.startswith(deck.stem+'.')};need(present==frozen,'autoload sidecar presence/absence changed')
 need(sha(config['benchmark_manifest'])==config['benchmark_manifest_sha256'],'benchmark manifest changed')
 if binary:
  need(bool(re.fullmatch('[0-9a-f]{64}',config.get('binary_sha256') or '')),'final PGO SHA required')
  need(sha(config['binary'])==config['binary_sha256'],'final PGO binary differs')
  need(Path(config['pgo_stamp']).read_text().strip()==config['source_tree'],'stale PGO stamp')
 return True

def benchmark(config,statusfile):
 status=read(statusfile);need(status.get('status')=='DONE' and status.get('returncode')==0,'root-owned benchmark must be DONE0')
 values=[status[k] for k in ('src_tree','source_tree') if k in status];need(values and all(v==config['source_tree'] for v in values),'benchmark source missing/differs')
 need(status['binary_sha256']==config['binary_sha256'],'benchmark binary differs')
 argv=status['argv'];need(Path(argv[0]).resolve()==Path(config['binary']).resolve(),'benchmark executable differs')
 for opt in ('--batch','--threads','--game-log-dir','--game-trace-dir'):need(argv.count(opt)==1,'benchmark missing/duplicate '+opt)
 need(Path(argv[argv.index('--batch')+1]).resolve()==Path(config['benchmark_manifest']).resolve(),'wrong paired benchmark manifest')
 need(int(argv[argv.index('--threads')+1])==32,'benchmark must be one32-worker pool')
 need(read(Path(statusfile).parent/'environment.json')==status.get('env') and read(Path(statusfile).parent/'argv.json')==status['argv'],'benchmark actual environment/argv differs')
 env=status.get('env',{});allowed={'MTG_PGO','MTG_DUMP_UNITS','MTG_SLOW_GAME_MS','MTG_FLAG_NONCONV','MTG_FD_ORACLE','MTG_PLAN_POOL_STATS','MTG_ROLLOUT_STATS','MTG_CYCLE_SEED_PAY_CENSUS'}
 need(set(env)<=allowed and env.get('MTG_DUMP_UNITS')=='1','benchmark has unreviewed policy env or lacks units')
 wins=Path(argv[argv.index('--game-log-dir')+1]);traces=Path(argv[argv.index('--game-trace-dir')+1]);items=[]
 for job in read(config['benchmark_manifest'])['jobs']:
  wp=wins/(job['name']+'.wins');up=wins/(job['name']+'.units');tp=traces/(job['name']+'_gi0.json')
  rows=[l.split() for l in wp.read_text().splitlines() if l.strip() and not l.startswith('#')];units=[l.split() for l in up.read_text().splitlines() if l.strip()]
  need(len(rows)==len(units)==1 and len(rows[0])==3 and rows[0][0]==units[0][0]=='0' and int(units[0][1])>=0,'benchmark singleton rows invalid')
  t=read(tp);need(t['seed']==job['seed'] and t['gameNumber']==0 and t.get('openingHand') and t.get('mulliganSequence') and t.get('turns'),'benchmark fulltrace invalid')
  win=int(rows[0][1]);need((t['result'].get('turn',-1) if t['result'].get('winner')=='player' else -1)==win,'benchmark trace result differs')
  items.append(dict(seed=job['seed'],ai_win=win,digest=rows[0][2],units=int(units[0][1]),files={str(p):sha(p) for p in (wp,up,tp)}))
 return dict(status_file=str(Path(statusfile).resolve()),status_sha256=sha(statusfile),argv=argv,env=env,games=items)

def config():
 plan=read(PLAN);source_check(plan,True);need(plan['runner_sha256']==sha(__file__),'runner changed after seal')
 need(read(GRANT)['plan_sha256']==sha(PLAN),'explicit root launch grant missing/differs')
 need(sha(plan['benchmark']['status_file'])==plan['benchmark']['status_sha256'],'benchmark receipt changed after seal')
 need(read(Path(plan['benchmark']['status_file']).parent/'DONE')==read(plan['benchmark']['status_file']),'benchmark DONE/status differs')
 benchmark(plan,plan['benchmark']['status_file'])
 return plan

def choices(text):
 need(text=='' or bool(re.fullmatch(r'-?\d+(,-?\d+)*',text)),'choices must be CSV integers only')
 return [] if text=='' else [int(x) for x in text.split(',')]
def payload(raw,kind):
 matches=re.findall(r'<<<CLAUDE_'+kind+r'>>>\s*(.*?)\s*<<<END_'+kind+r'>>>',raw,re.S)
 need(len(matches)==1,'missing/duplicate '+kind+' protocol block')
 return json.loads(matches[0])
def step(seed,csv):
 c=config();need(seed in c['seeds'],'seed outside sealed15');vals=choices(csv);game=HERE/'games'/str(seed);need(game.is_dir(),'game not launched')
 need((game/'MODEL-RUNNING.json').exists(),'no actual Claude game process active')
 with (game/'engine.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipts=sorted((game/'steps').glob('*.json'))
  if receipts:
   previous=read(receipts[-1]);old=previous['choices']
   if vals==old:
    print(Path(previous['stdout']).read_text(),end='');return 0
   need(previous['engine_returncode']==70 and len(vals)==len(old)+1 and vals[:-1]==old,'append exactly one choice; no branch rewinds/auto fallback')
  else:need(not vals,'first call must have empty choices')
  index=len(vals);stem=game/'steps'/f'{index:04d}';out=stem.with_suffix('.stdout');err=stem.with_suffix('.stderr')
  argv=[c['binary'],str(Path(c['worktree'])/'decks/Unpredictable Cyclone/Unpredictable Cyclone.cod'),'--profile',str(Path(c['worktree'])/'decks/Unpredictable Cyclone/Unpredictable Cyclone.profile.json'),'--claude-play','--seed',str(seed),'--game-index','0','--max-turns','8','--reveal','6','--threads','1','--choices',csv,'--log-dir',str(game/'engine-traces'/f'prefix-{index:04d}')]
  env={k:v for k,v in os.environ.items() if not k.startswith('MTG_')};env['MTG_PGO']='1';env['OMP_NUM_THREADS']='1'
  with out.open('x') as so,err.open('x') as se:
   proc=subprocess.Popen(argv,cwd=c['worktree'],env=env,stdout=so,stderr=se);rc=proc.wait()
  raw=out.read_text();need(rc in (0,70),'engine protocol failed; raw evidence retained at '+str(stem))
  data=payload(raw,'RESULT' if rc==0 else 'DECISION')
  record=dict(seed=seed,game_index=0,choices=vals,choices_csv=csv,engine_returncode=rc,argv=argv,env={'MTG_PGO':'1','OMP_NUM_THREADS':'1'},source_tree=c['source_tree'],binary_sha256=c['binary_sha256'],stdout=str(out),stderr=str(err),stdout_sha256=sha(out),stderr_sha256=sha(err),protocol=data,finished=now())
  write_new(stem.with_suffix('.json'),record)
  if rc==0:write_new(game/'ENGINE-COMPLETE.json',record)
  print(raw,end='');return 0

SCHEMA={'type':'object','additionalProperties':False,'required':['ai_win','claude_win','choices','flags','summary'],'properties':{'ai_win':{'type':'integer','minimum':-1,'maximum':8},'claude_win':{'type':'integer','minimum':-1,'maximum':8},'choices':{'type':'string'},'flags':{'type':'array','items':{'type':'object','required':['category','decision_index','choices_prefix','evidence','card_data_basis','rules_basis'],'properties':{'category':{'type':'string'},'decision_index':{'type':'integer'},'choices_prefix':{'type':'string'},'evidence':{'type':'string'},'card_data_basis':{'type':'string'},'rules_basis':{'type':'string'}}}},'summary':{'type':'string'}}}

def cli_argv(c,seed):
 game=HERE/'games'/str(seed);wt=Path(c['worktree'])
 reads=[wt/'CLAUDE.md',wt/'.claude/skills/claude-play.md',wt/'.claude/skills/mtg-rules.md',HERE/'cards22.json',game/'benchmark.json']
 # Claude absolute-path Read permission syntax is //path.
 allow=[f'Read(/{p})' for p in reads]
 allow.append(f'Bash(python3 {HERE}/sweep.py step --seed {seed} --choices *)')
 argv=[c['claude_cli'],'-p','--model','sonnet','--safe-mode','--no-session-persistence','--disable-slash-commands','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--setting-sources','','--add-dir',str(wt),str(HERE),'--tools','Read,Bash','--allowedTools',*allow,'--permission-mode','dontAsk','--permission-prompts','none','--output-format','stream-json','--verbose','--json-schema',json.dumps(SCHEMA,separators=(',',':'))]


 validate_cli_argv(c,seed,argv)
 return argv

def validate_cli_argv(c,seed,argv):
 """Pure guard: actual permission entries, not merely the available tool names."""
 need(seed in c['seeds'],'CLI seed outside prepared15')
 need(argv.count('--allowedTools')==1 and argv.count('--permission-mode')==1,'missing/duplicate permission options')
 allowed=argv[argv.index('--allowedTools')+1:argv.index('--permission-mode')]
 wt=Path(c['worktree']);game=HERE/'games'/str(seed)
 expected_reads={f'Read(/{path})' for path in (wt/'CLAUDE.md',wt/'.claude/skills/claude-play.md',wt/'.claude/skills/mtg-rules.md',HERE/'cards22.json',game/'benchmark.json')}
 bash=f'Bash(python3 {HERE}/sweep.py step --seed {seed} --choices *)'
 need(len(allowed)==6 and len(set(allowed))==6 and set(allowed)==expected_reads|{bash},'actual allowedTools must contain exact five Reads plus seed-bound Bash step')
 for option,value in [('--model','sonnet'),('--tools','Read,Bash'),('--permission-mode','dontAsk'),('--permission-prompts','none'),('--output-format','stream-json')]:
  need(argv.count(option)==1 and argv[argv.index(option)+1]==value,'wrong CLI policy '+option)
 need('--safe-mode' in argv and '--strict-mcp-config' in argv and '--no-session-persistence' in argv,'missing controlled CLI flags')
 need('--fallback-model' not in argv and '--dangerously-skip-permissions' not in argv,'unexpected fallback or blanket permission bypass')
 return True

def verify_model_result(c,seed,events,rc):
 import oracle_verify
 receipt=oracle_verify.verify_game(seed,c,rc)
 receipt['resolved_assistant_models']=receipt['native_assistant_models']
 return receipt

def run_game(c,seed):
 game=HERE/'games'/str(seed);(game/'steps').mkdir();argv=cli_argv(c,seed);write_new(game/'MODEL-RUNNING.json',dict(started=now(),argv=argv,requested_model='sonnet',source_tree=c['source_tree'],binary_sha256=c['binary_sha256']))
 prompt=(HERE/'prompts'/f'{seed}.md').read_text();events=[]
 with (game/'claude.stream.jsonl').open('x') as out,(game/'claude.stderr').open('x') as err:
  proc=subprocess.Popen(argv,cwd=HERE,stdin=subprocess.PIPE,stdout=out,stderr=err,text=True);proc.communicate(prompt);rc=proc.returncode
 try:
  for line in (game/'claude.stream.jsonl').read_text().splitlines():
   if line.strip():events.append(json.loads(line))
  receipt=verify_model_result(c,seed,events,rc);write_new(game/'CLAUDE-COMPLETE.json',receipt);return receipt
 except Exception as error:
  write_new(game/'CLAUDE-FAILED.json',dict(seed=seed,actual_cli_exit=rc,error=repr(error),finished=now(),no_substitute=True,raw_stream=str(game/'claude.stream.jsonl'),scope='Not a completed clean oracle game. Preserve raw tool/model errors.'));raise

def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='action',required=True);sub.add_parser('check-preparation')
 seal=sub.add_parser('seal');seal.add_argument('--binary-sha256',required=True);seal.add_argument('--benchmark-status',type=Path,required=True)
 grant=sub.add_parser('grant');grant.add_argument('--root-message',required=True)
 sub.add_parser('run');st=sub.add_parser('step');st.add_argument('--seed',type=int,required=True);st.add_argument('--choices',required=True);args=ap.parse_args()
 if args.action=='check-preparation':source_check(read(PREP));print('PASS source/assets/15 distinct seeds/22 definitions; no engine/model launched, PGO SHA and grant still required');return 0
 if args.action=='seal':
  c=read(PREP);c['binary_sha256']=args.binary_sha256;source_check(c,True);need(read(args.benchmark_status).get('validation_pass') is True,'root benchmark validation must pass');need(read(args.benchmark_status.parent/'DONE')==read(args.benchmark_status),'benchmark must have exact DONE receipt');c['benchmark']=benchmark(c,args.benchmark_status);c.update(status='SEALED_AWAITING_ROOT_GRANT',runner_sha256=sha(__file__),prompt_sha256={str(p):sha(p) for p in sorted((HERE/'prompts').glob('*.md'))});need(len(c['prompt_sha256'])==15,'need exactly15 prompt files');write_new(PLAN,c)
  for item in c['benchmark']['games']:
   game=HERE/'games'/str(item['seed']);game.mkdir(parents=True);write_new(game/'benchmark.json',item)
  print('SEALED exact finalPGO and completed paired benchmark; no oracle model/engine launched');return 0
 if args.action=='grant':
  c=read(PLAN);source_check(c,True);need(args.root_message.strip(),'explicit root grant required');write_new(GRANT,dict(created=now(),root_message=args.root_message,plan_sha256=sha(PLAN)));print('Recorded explicit root grant; no launch in this action');return 0
 if args.action=='step':return step(args.seed,args.choices)
 c=config()
 for path,digest in c['prompt_sha256'].items():need(sha(path)==digest,'prompt changed after seal')
 need(not (HERE/'RUNNING.json').exists(),'refuse duplicate sweep run');write_new(HERE/'RUNNING.json',dict(started=now(),source_tree=c['source_tree'],binary_sha256=c['binary_sha256'],plan_sha256=sha(PLAN),parallel_agents=15,resource_contract='15 simultaneous pergame engines max, one serial engine per actual Claude; root separately may run memory1. No32 build/batch during sweep.'))
 receipts=[];failures=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=15) as pool:
  futures={pool.submit(run_game,c,seed):seed for seed in c['seeds']}
  for future in concurrent.futures.as_completed(futures):
   seed=futures[future]
   try:r=future.result();receipts.append(r);print(json.dumps({'seed':seed,'status':'CLAUDE_COMPLETED','models':r['resolved_assistant_models'],'ai_win':r['answer']['ai_win'],'claude_win':r['answer']['claude_win'],'flags':len(r['answer']['flags'])}),flush=True)
   except Exception as error:failures.append(dict(seed=seed,error=repr(error)));print(json.dumps({'seed':seed,'status':'FAILED_NO_SUBSTITUTE','error':repr(error)}),flush=True)
 import observational_types
 observed=observational_types.build(HERE);write_new(HERE/'observational-types.json',observed)
 report=dict(observational_types_report=str(HERE/'observational-types.json'),observational_types_sha256=sha(HERE/'observational-types.json'),finished=now(),source_tree=c['source_tree'],binary_sha256=c['binary_sha256'],requested_games=15,completed_actual_claude_games=len(receipts),failures=failures,receipts=sorted(receipts,key=lambda r:r['seed']),no_fake_oracle=True,all_flags_require_root_verification=True,scope='Small standard Stage5d correctness backstop, not policy experiment/adoption or model substitution.')
 write_new(HERE/('DONE.json' if not failures else 'INCOMPLETE.json'),report);return 0 if not failures else 2
if __name__=='__main__':raise SystemExit(main())
