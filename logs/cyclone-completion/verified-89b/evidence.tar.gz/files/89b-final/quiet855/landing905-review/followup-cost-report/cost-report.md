# V6 quiet855 cost measurement

Original suite gate: max(sum exact job ms / completed games) across searched depth>0,budget>0 logical seed/configuration cells, divided by same-run Hinata maximum. BatchRunner ms is summed integer steady-clock per-game wall duration, historically called core-ms; it is not measured thread CPU or batch makespan.

| Arm | Worst searched cell | ms/game | Same-run Hinata ms/game | Ratio | Observed3x point gate | Descriptive95% interval |
|---|---|---:|---:|---:|---|---|
| live | cyclone_live_play_s2002 | 27923.650 | 2040.213 | 13.687 | FAIL | [9.046, 23.562] |
| pb_on | cyclone_pb_on_play_s2002 | 7176.500 | 2040.213 | 3.518 | FAIL | [2.577, 5.919] |
| pb_keep_myriad | cyclone_pb_keep_myriad_play_s2002 | 7243.300 | 2040.213 | 3.550 | FAIL | [2.626, 6.056] |

Original535 controls are preserved in original535-view.json. Hinata375 games appear once; PB-only adds160 and PB+KEEP_AMEND+KEEP_MYRIAD adds160 matched games. All855 per-game outcomes/digests/units and exact86 job timings were validated after exclusive DONE/0.

| Candidate contrast | n | Win-round delta ± SE | Faster/slower/tied | Digest changes | Unit ratio | Candidate/control ms ratio |
|---|---:|---:|---|---:|---:|---:|
| cyclone_pb_on_d3_s2002-vs-cyclone_live_d3_s2002 | 40 | 0.0000 ± 0.0801 | 5/5/30 | 26 | 0.2306 | 0.2963 |
| cyclone_pb_keep_myriad_d3_s2002-vs-cyclone_live_d3_s2002 | 40 | 0.0500 ± 0.0797 | 4/6/30 | 28 | 0.2277 | 0.2940 |
| cyclone_pb_keep_myriad_d3_s2002-vs-cyclone_pb_on_d3_s2002 | 40 | 0.0500 ± 0.0349 | 0/2/38 | 16 | 0.9874 | 0.9924 |
| cyclone_pb_on_play_s2002-vs-cyclone_live_play_s2002 | 20 | 0.0500 ± 0.0881 | 1/2/17 | 12 | 0.2121 | 0.2570 |
| cyclone_pb_keep_myriad_play_s2002-vs-cyclone_live_play_s2002 | 20 | 0.1500 ± 0.0819 | 0/3/17 | 13 | 0.2150 | 0.2594 |
| cyclone_pb_keep_myriad_play_s2002-vs-cyclone_pb_on_play_s2002 | 20 | 0.1000 ± 0.0688 | 0/2/18 | 8 | 1.0136 | 1.0093 |
| cyclone_pb_on_d3_s3003-vs-cyclone_live_d3_s3003 | 40 | -0.0500 ± 0.0944 | 7/4/29 | 32 | 0.2068 | 0.2494 |
| cyclone_pb_keep_myriad_d3_s3003-vs-cyclone_live_d3_s3003 | 40 | -0.0750 ± 0.0905 | 7/3/30 | 32 | 0.2018 | 0.2443 |
| cyclone_pb_keep_myriad_d3_s3003-vs-cyclone_pb_on_d3_s3003 | 40 | -0.0250 ± 0.0669 | 2/2/36 | 14 | 0.9754 | 0.9792 |
| cyclone_pb_on_play_s3003-vs-cyclone_live_play_s3003 | 20 | -0.1500 ± 0.1500 | 5/1/14 | 17 | 0.2445 | 0.2796 |
| cyclone_pb_keep_myriad_play_s3003-vs-cyclone_live_play_s3003 | 20 | -0.1000 ± 0.1433 | 4/1/15 | 17 | 0.2503 | 0.2885 |
| cyclone_pb_keep_myriad_play_s3003-vs-cyclone_pb_on_play_s3003 | 20 | 0.0500 ± 0.0500 | 0/1/19 | 6 | 1.0237 | 1.0319 |
| cyclone2hg_pb_on_d3_s2002-vs-cyclone2hg_live_d3_s2002 | 40 | -0.1750 ± 0.0940 | 11/4/25 | 32 | 0.2268 | 0.2889 |
| cyclone2hg_pb_keep_myriad_d3_s2002-vs-cyclone2hg_live_d3_s2002 | 40 | -0.1500 ± 0.0764 | 8/2/30 | 32 | 0.2279 | 0.2947 |
| cyclone2hg_pb_keep_myriad_d3_s2002-vs-cyclone2hg_pb_on_d3_s2002 | 40 | 0.0250 ± 0.0565 | 2/3/35 | 21 | 1.0048 | 1.0200 |

Descriptive percentile cluster bootstrap: resample chunks within original seed/configuration, sharing indices across allthree matched Cyclone arms; independent Hinata chunks; recompute every deck maximum per draw. No per-game wall variance is invented.

Only2-4 Cyclone chunks per logical cell and8/15 Hinata chunks; intervals are coarse and conditional on this sample/quiet schedule. Host/compiler systematics are omitted. This does not change the existing point-estimate3x gate.

Quiet timing uses its controlled cost environment; FD/nonconv oracles are not enabled here. Candidate quality evidence is separate. V5 histories are not relabelled as fresh integrated-source quality.

Three configurations are measured without adopting any. PB-only and PB+KEEP_AMEND+KEEP_MYRIAD preserve the current leaf/profile/all other defaults. No policy, suite membership, GT or artifact generation changes; other leaf/Ponder combinations are unmeasured.
