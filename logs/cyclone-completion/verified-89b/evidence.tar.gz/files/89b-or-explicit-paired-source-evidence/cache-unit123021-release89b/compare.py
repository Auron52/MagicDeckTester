#!/usr/bin/env python3
"""Require3 closed new-Release probes and exact repair parity; never runs engines."""
import csv
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
INPUTS=HERE.parents[1]/'v7-905-lean/prepared-89b146d-final'
sys.path.insert(0,str(INPUTS/'helpers'))
import v6_common as c

def main():
    context,_,_=c.guard(INPUTS,sealed=False);obj=c.read(HERE/'proposal.json');reader=c.reader(INPUTS)
    assert context['expected_source']==obj['source_tree'] and c.sha(obj['binary'])==obj['binary_sha256']
    job=obj['single_game_job'];data={}
    for plan in obj['stages']:
        run=Path(plan['stdout']).parent;status=c.read(run/'status.json')
        assert status==c.read(run/'DONE') and status['status']=='DONE' and status['returncode']==0
        assert status['source_tree']==obj['source_tree'] and status['binary_sha256']==obj['binary_sha256']
        assert status['argv']==plan['argv'] and status['env']==plan['env'] and status['proposal_sha256']==c.sha(HERE/'proposal.json')
        assert status['results']==c.validate_results(INPUTS,[job],plan)
        rows=reader.read_job(job,run/'wins');row=rows[(123021,21)]
        trace=run/'traces'/f'{job["name"]}_gi21.json';game=c.read(trace)
        for key in ('deckId','runId'):game.pop(key,None)
        census=list(csv.DictReader([line for line in(run/'turn-census.tsv').read_text().splitlines()if not line.startswith('#')],delimiter='\t'))
        assert census and all(x['contended']=='0' for x in census)
        unit_rows=[{k:v for k,v in x.items()if k.startswith('u_')or k in('seed','turn','pre','root','depth','budget','units','site','probe','skey')}for x in census]
        fidelity=reader.memory_diagnostics(plan['stderr'],plan)
        assert fidelity['clean'],fidelity
        data[plan['name']]=dict(row={k:row[k]for k in('win','digest','units')},game=game,unit_rows=unit_rows,trace=str(trace),trace_sha256=c.sha(trace),census_sha256=c.sha(run/'turn-census.tsv'),fidelity=fidelity)
    control=data['normal'];report=dict(source_tree=obj['source_tree'],binary_sha256=obj['binary_sha256'],scope='FreshRelease repair probes only; does not replace full972 memory proof or compiler parity.',results={},pass_=True)
    for name,d in data.items():
        result=dict(row=d['row'],row_exact=d['row']==control['row'],full_trace_exact_except_container_ids=d['game']==control['game'],per_decision_unit_sites_exact=d['unit_rows']==control['unit_rows'],trace=d['trace'],trace_sha256=d['trace_sha256'],census_sha256=d['census_sha256'])
        report['results'][name]=result
        report['pass_'] &= result['row_exact'] and result['full_trace_exact_except_container_ids'] and result['per_decision_unit_sites_exact']
    out=HERE/'comparison.json';assert not out.exists(),'Preserve existing comparison'
    c.write(out,report);print(json.dumps(report,indent=2));raise SystemExit(0 if report['pass_'] else 1)

if __name__=='__main__':main()
