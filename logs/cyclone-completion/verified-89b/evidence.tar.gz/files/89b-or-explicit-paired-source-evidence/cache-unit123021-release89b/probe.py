#!/usr/bin/env python3
"""Prepared diagnostic; root explicitly chooses one stage. Never builds."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
HERE=Path(__file__).resolve().parent
INPUTS=HERE.parents[1]/'v7-905-lean/prepared-89b146d-final'
sys.path.insert(0,str(INPUTS/'helpers'))
import v6_common as c

def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['normal','pool1KB','no_plan_memos']);p.add_argument('--run',action='store_true');a=p.parse_args()
    obj=c.read(HERE/'proposal.json');stage=next(x for x in obj['stages']if x['name']==a.stage)
    if not a.run:print(json.dumps(dict(prepared=stage,engine_launched=False),indent=2));return
    context,_,_=c.guard(INPUTS,sealed=False)
    seal=dict(source_tree=context['expected_source'],binary_sha256=c.sha(obj['binary']))
    assert seal['source_tree']==obj['source_tree'] and seal['binary_sha256']==obj['binary_sha256']
    assert c.read(HERE/'manifest.json')['jobs']==[obj['single_game_job']]
    run=Path(stage['stdout']).parent;run.mkdir(parents=True,exist_ok=False)
    (run/'wins').mkdir();(run/'traces').mkdir()
    env={k:v for k,v in os.environ.items()if not k.startswith('MTG_')};env.update(stage['env']);env['GIT_OPTIONAL_LOCKS']='0'
    status=dict(stage=a.stage,source_tree=obj['source_tree'],binary_sha256=obj['binary_sha256'],argv=stage['argv'],env=stage['env'],cwd=stage['cwd'],proposal_sha256=c.sha(HERE/'proposal.json'),status='RUNNING')
    c.write(run/'status.json',status)
    with Path(stage['stdout']).open('x')as out,Path(stage['stderr']).open('x')as err:
        rc=subprocess.run(stage['argv'],cwd=stage['cwd'],env=env,stdout=out,stderr=err).returncode
    status.update(returncode=rc,status='STOPPED')
    if rc==0:
        c.guard(INPUTS,sealed=False)
        assert c.sha(obj['binary'])==obj['binary_sha256']
        status['results']=c.validate_results(INPUTS,[obj['single_game_job']],stage)
        status['status']='DONE'
    c.write(run/'status.json',status);c.write(run/status['status'],status)
    raise SystemExit(rc)

if __name__=='__main__':main()
