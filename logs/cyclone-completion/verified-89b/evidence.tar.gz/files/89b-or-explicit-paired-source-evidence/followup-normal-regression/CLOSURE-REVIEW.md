The fresh source89b/PGO20de full regression closed at 2026-10-31 13:40:08 UTC with its original exit code **1**: 246 PASS, 7 FAIL, 0 NEW. The engine batch completed all253 jobs and72413 of72414 requested games. The existing accepted Melira d5/s30001 backstop omission is the sole missing game: GI11/seed30012 hit exactly2000000 units, matching the baseline absent GI. No game was filled or normalized.

The fresh strict reference gate passed all709 refs:266 ok,442 repaired,1 beaten, zero in every failure category. The two suboptimal references were both strictly beaten. This passes those gates; it does not turn the seven GT mismatches into a passing suite or authorize acceptance.

The preserved mechanical audit contains exactly seven changed searched games: Goblins s2002/GI57; Minotaur s2002/GI438 and s3003/GI168; Melira s2002/GI98; Hinata2HG s2002/GI21; Landfall s3003/GI125; MidrangeBurn2HG s2002/GI14. Three are slower (Minotaur GI168, Hinata2HG GI21, MidrangeBurn2HG GI14), four keep their win turn. All40000 depth0 games are unchanged. Those seven identities were handed to the separate legality/control/recovery reviewer; this addendum makes no acceptance verdict.

Fresh measured FD evidence is three ordinary, non-leaf-estimate rows; NONCONV and counter-overflow counts are both zero:

| Job/global GI | Actual seed | Predicted → realized; proven at | Actual win/digest/units |
|---|---:|---|---|
| Niv s3003/GI92 |3095|5 →6; T4|6 /6517d5cbeacb7f9e /38367|
| EDF s2002/GI71 |2073|5 →6; T2|6 /f156bbf319e267ae /37624|
| Treasure Hunt s3003/GI457 |3460|5 →7; T2|7 /e50374c3faba4199 /26223|

Every fresh89b tuple, actual win, digest and units value matches the prior exact C2 and native upstream controls. Each singleton simulation-field projection matches the old control, including real seed/global GI, profile, play-depth behavior and budget. Treasure Hunt scheduling weight is7251 now versus7250 in the old control; this is only LPT queue priority (`src/runner/BatchRunner.cpp`:153,729,1236), and is recorded rather than erased. Both actual runs used32 workers; the old control additionally printed slow-game observations. All19 relevant card/deck/profile/model asset hashes remain equal to both the old C2 bridge and dfcb baseline.

Historical physical context comes from the **old source** C2/native control pair, whose full JSON traces were exactly equal. Niv's old trace casts Niv-Mizzet, Parun T5, Curiosity in main2, and wins T6. EDF's old trace performs its repeated untap/draw sequence T5 and records Combo Off T6. Treasure Hunt's old trace casts Hunt and Land's Edge T4, plays a land T5, and wins T7. These are context for an already observed defect, not new89b physical traces or a root-cause explanation. The fresh normal batch did not capture full game JSON. Equal fresh outcome/digest/units plus forecast tuple supports the narrowly scoped matching-preexisting-observation classification; it does not establish a new physical trace comparison, repair the defect, or prove absence at other seeds.

`closure-fd-review.json` binds the actual later status/logs, source and binary, each new measured wins/units file, the exact historical receipts/traces, all19 input hashes and the bounded omission witness. `audit/audit.json` deliberately remains byte-identical to its earlier collection while strict replay was pending. No source/GT changes, engine/build/model runs or acceptance occurred in this review.
