# Follow-up Release smoke review — physical controls pending

Reviewed by `/root/cyclone_prunes_review`, source89b146 / Releaseaca52, against accepted C2 ground truth3889a0a11. Strict audit checks all157jobs/51,675games and their per-game aggregate folds. Result:154PASS/3FAIL/0NEW, with exactly three searched same-score changes and no searched slower/faster or d0 changes. All390scenarios pass.

The changes are Bruna d3GI3 (T4), EDF playGI87 (T7), and Landfall playGI60 (T5). Bruna delays Greaves and adds a late Birds cast; its kept hand/draws agree. EDF’s printed per-turn summaries agree completely, so they cannot explain its digest change. Landfall chooses different first lands, then draws diverge after the T2 ramp search. These observations are not yet a full physical legality verdict.

The fixed harness ran correct-setting old/new summaries, but its temporary full JSON traces were deleted. Exact old/new physical snapshots for these three identities are not otherwise retained. The prepared paired control packet preserves the accepted C2 native primary PGO and requires the actual fresh89 PGO before sealing. It runs two sequential3-game pools at32requestedworkers with full traces and units. No engine was launched here. Final acceptance waits for these paired traces and PGO parity; no aggregate-only acceptance is proposed.

Raw stderr contains exactly one known ordinary Niv1082 FD and zero NONCONV/overflow. It is not a zero-FD run. The old C2 baseline/controls/raw evidence are untouched. REVIEW-PENDING.json binds author, timestamp, source/bin, exact changed rows and raw audit hash.
