#!/usr/bin/env python3
"""Root-owned seal/run for two sequential three-game PGO pools. Never builds."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def require(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def write(p, value):
    with p.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def guard(plan):
    env = {**os.environ, "GIT_OPTIONAL_LOCKS":"0"}
    for name, arm in plan["arms"].items():
        cwd = Path(arm["cwd"])
        source = subprocess.check_output(["git", "-C", str(cwd), "rev-parse", "HEAD:src"], env=env, text=True).strip()
        dirty = subprocess.check_output(["git", "-C", str(cwd), "status", "--porcelain", "--untracked-files=no", "--", "src"], env=env)
        require(source == arm["source_tree"] and not dirty.strip(), name+": source mismatch/dirty")
        stamp = Path(arm["binary"]).parent / "SRC_TREE"
        require(stamp.read_text().strip() == source, name+": stale PGO stamp")
        require(bool(arm["binary_sha256"]) and sha(arm["binary"]) == arm["binary_sha256"], name+": binary mismatch/unsealed")
        require(sha(arm["manifest"]) == arm["manifest_sha256"], name+": manifest mismatch")
        for rel, digest in plan["assets"].items():
            require(sha(cwd / rel) == digest, name+": asset mismatch "+rel)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--seal-current-sha256")
    group.add_argument("--run", action="store_true")
    group.add_argument("--check", action="store_true")
    args = ap.parse_args()
    if args.seal_current_sha256:
        require(re.fullmatch("[0-9a-f]{64}", args.seal_current_sha256), "invalid SHA256")
        plan = json.loads((ROOT / "plan.UNSEALED.json").read_text())
        plan["arms"]["current"]["binary_sha256"] = args.seal_current_sha256
        guard(plan)
        plan.update(status="SEALED", sealed_utc=datetime.now(timezone.utc).isoformat(),
                    recipe_sha256=sha(ROOT / "plan.UNSEALED.json"), runner_sha256=sha(__file__))
        write(ROOT / "plan.SEALED.json", plan)
        print("SEALED; no engine run")
        return
    plan = json.loads((ROOT / "plan.SEALED.json").read_text())
    require(plan["runner_sha256"] == sha(__file__), "runner changed after sealing")
    require(plan["recipe_sha256"] == sha(ROOT / "plan.UNSEALED.json"), "recipe changed after sealing")
    guard(plan)
    require(plan["threads"] == 32 and len(plan["cases"]) == 3, "protocol count/threads mismatch")
    if args.check:
        print("PASS sealed source/binary/assets/manifest guards; no engine run")
        return
    out = ROOT / "runs"
    out.mkdir(exist_ok=False)
    env = {k:v for k,v in os.environ.items() if not k.startswith("MTG_")}
    env.update(plan["process_env"])
    receipt = dict(status="RUNNING", started=datetime.now(timezone.utc).isoformat(),
                   plan_sha256=sha(ROOT / "plan.SEALED.json"), arms={})
    write(out / "RUNNING.json", receipt)
    try:
        # Each native source owns one 3-game queue; never split to scalar per-case processes.
        for name in ["baseline", "current"]:
            guard(plan)
            arm = plan["arms"][name]
            stage = out / name
            stage.mkdir(exist_ok=False)
            argv = [arm["binary"], "--batch", arm["manifest"], "--threads", "32",
                    "--cards-json", str(Path(arm["cwd"]) / "src/cards/data/cards.json"),
                    "--game-log-dir", str(stage / "wins"), "--game-trace-dir", str(stage / "traces")]
            write(stage / "argv.json", argv)
            write(stage / "environment.json", {k:v for k,v in env.items() if k.startswith("MTG_") or k == "OMP_NUM_THREADS"})
            with (stage / "batch.log").open("xb") as stdout, (stage / "batch.err").open("xb") as stderr:
                result = subprocess.run(argv, cwd=arm["cwd"], env=env, stdout=stdout, stderr=stderr)
            require(result.returncode == 0, name+": engine exited "+str(result.returncode))
            observed = []
            for case in plan["cases"]:
                job = case["job"]["name"]
                wins = stage / "wins" / (job + ".wins")
                units = stage / "wins" / (job + ".units")
                trace = stage / "traces" / (job + "_gi" + str(case["gi"]) + ".json")
                rows = wins.read_text().strip().splitlines()
                urows = units.read_text().strip().splitlines()
                require(len(rows) == len(urows) == 1, name+": incomplete singleton rows")
                require(int(rows[0].split()[0]) == int(urows[0].split()[0]) == case["gi"], name+": GI mismatch")
                tr = json.loads(trace.read_text())
                require(tr["seed"] == case["seed"] and tr["gameNumber"] == case["gi"], name+": trace identity mismatch")
                expected = case["baseline_row"] if name == "baseline" else case["release_row"]
                observed.append(dict(key=case["key"], gi=case["gi"], actual_seed=case["seed"],
                                     wins_row=rows[0], original_expected_row=expected,
                                     original_row_reproduced=rows[0] == expected, units=urows[0],
                                     trace_sha256=sha(trace), wins_sha256=sha(wins), units_sha256=sha(units)))
            stderr = (stage / "batch.err").read_text()
            diagnostics = [dict(line=i, text=line) for i,line in enumerate(stderr.splitlines(),1)
                           if re.search(r"\[(?:fd-diverge|fd)\]|FORECAST.DISAGREEMENT|NONCONV|OVERFLOW", line, re.I)]
            arm_receipt = dict(status="DONE", returncode=0, source_tree=arm["source_tree"],
                               binary_sha256=arm["binary_sha256"], cases=observed, diagnostics=diagnostics,
                               batch_log_sha256=sha(stage / "batch.log"), batch_err_sha256=sha(stage / "batch.err"))
            write(stage / "DONE.json", arm_receipt)
            receipt["arms"][name] = arm_receipt
        receipt.update(status="DONE", finished=datetime.now(timezone.utc).isoformat(),
                       scope="All six native-source results/units/full traces preserved. Completion is not reproduction, legality or adoption approval.")
        write(out / "DONE.json", receipt)
        print(json.dumps(receipt, indent=2))
    except BaseException as error:
        receipt.update(status="FAILED", error=str(error), finished=datetime.now(timezone.utc).isoformat())
        write(out / "FAILED.json", receipt)
        raise


if __name__ == "__main__":
    main()
