# Combined follow-up controls — prepared, not launched

Root selected32games in three sequential native-CWD pools, each requesting32workers. Original three-smoke packet is preserved and must not also be launched. No model, build, engine, timeout or source edit occurred during preparation.

| Stage | Native source / PGO | Games |
|---|---|---:|
| baseline_normal | Primary C2 /962bc5… |10|
| current_normal_and_recovery | Landing90589b /20de8d… |19|
| baseline_no_plan_memos | Primary C2 /962bc5… |3|

The normal comparison has seven new regression identities plus three preserved Release-smoke ties. The current queue adds three recovery variants per slower game. Its original-budget counterpart is an alias of the normal control and is not repeated. All10 normal jobs preserve their original explicit/omitted depth, profile, life and heads, with only singleton seed/globalGI/name changes. Weights are preserved as scheduling metadata.

| Slower case | Actual seed / GI | Original budget |4x|16x|Depth8 unlimited|
|---|---|---:|---:|---:|---|
| minotaur_regression_d5_s3003 | 3171 /168 |20|80|320|depth8,budget0,ignore profile depth|
| hinata2hg_regression_d5_s2002 | 2023 /21 |30|120|480|depth8,budget0,ignore profile depth|
| midrangeburn2hg_regression_d5_s2002 | 2016 /14 |20|80|320|depth8,budget0,ignore profile depth|

Old memo-disabled controls reproduce the ACTUAL old cache-unit123021 environment: `MTG_ENUM_MEMO=0` and `MTG_NO_BP_ENUM_CACHE=1`. Common explicit default-on cache-key/isolation/hit-price pins and observers are matched in all stages; no quota or resource-shape override was added. The only old-probe environment changes are the new stage-local census path and explicit OMP1. The source old environment record/hash is in plan.json.

The hypothesis is that old uncached behavior may match newly metered behavior after the billing-key fix. It is unmeasured. The runner records every raw row, full physical trace, decision units, turn census and diagnostic. It reports normal-row reproduction separately from completion; recovered outcomes, causal equivalence and acceptance require review. No result is promised.

Thirty-seven runtime asset/card files are byte-identical across source-native roots. Sources, clean src, PGO source stamps, actual binary SHA and all three manifest SHA are checked before launch and between stages. Outputs are exclusive; an existing runs directory refuses overwrite. Normal1/32 memory proofs and the active root-owned run lifecycle remain separate.

After root closes all other heavy runs:

```bash
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/followup89-combined-controls/run.py --check
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/followup89-combined-controls/run.py --run
```

Both Python syntax and --check passed without starting an engine. DFCB is the new regression GT baseline;3889 is only the preserved three-smoke baseline. PD/Slivers artifact changes are not silently compared against old inputs.
