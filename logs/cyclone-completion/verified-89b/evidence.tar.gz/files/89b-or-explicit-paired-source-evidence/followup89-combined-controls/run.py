#!/usr/bin/env python3
"""Root-owned three-pool controls; no build, model, timeout or overwrite."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)


def write(p, obj):
    with p.open("x") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def guard(plan):
    need(plan["threads"] == 32 and len(plan["rows"]) == 10, "protocol changed")
    need([s["games"] for s in plan["stages"]] == [10,19,3], "stage counts changed")
    env = {**os.environ, "GIT_OPTIONAL_LOCKS":"0"}
    for name, arm in plan["arms"].items():
        cwd = Path(arm["cwd"])
        src = subprocess.check_output(["git","-C",str(cwd),"rev-parse","HEAD:src"], env=env, text=True).strip()
        dirty = subprocess.check_output(["git","-C",str(cwd),"status","--porcelain","--untracked-files=no","--","src"], env=env)
        need(src == arm["source_tree"] and not dirty.strip(), name+": source mismatch/dirty")
        need((Path(arm["binary"]).parent/"SRC_TREE").read_text().strip() == src, name+": stale PGO")
        need(sha(arm["binary"]) == arm["binary_sha256"], name+": binary mismatch")
        for rel, digest in plan["assets"].items():
            need(sha(cwd/rel) == digest, name+": asset mismatch "+rel)
    for stage in plan["stages"]:
        need(sha(stage["manifest"]) == stage["manifest_sha256"], "manifest changed")
        jobs = json.loads(Path(stage["manifest"]).read_text())["jobs"]
        need(len(jobs) == stage["games"] and all(j["games"] == 1 for j in jobs), "singleton count mismatch")
        need(len({j["name"] for j in jobs}) == len(jobs), "duplicate job name")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = ap.parse_args()
    plan_path = ROOT/"plan.json"
    plan = json.loads(plan_path.read_text())
    guard(plan)
    if args.check:
        print("PASS exact sources/PGOs/assets/three manifests; 10+19+3 games,32workers; no engine")
        return
    out = ROOT/"runs"
    out.mkdir(exist_ok=False)
    receipt = dict(status="RUNNING", started=datetime.now(timezone.utc).isoformat(),
                   plan_sha256=sha(plan_path), runner_sha256=sha(__file__), stages={})
    write(out/"RUNNING.json", receipt)
    try:
        for spec in plan["stages"]:
            guard(plan)
            stage = out/spec["name"]
            stage.mkdir(exist_ok=False)
            arm = plan["arms"][spec["arm"]]
            env = {k:v for k,v in os.environ.items() if not k.startswith("MTG_")}
            env.update({k:v.replace("@STAGE@",str(stage)) for k,v in spec["environment"].items()})
            env["GIT_OPTIONAL_LOCKS"] = "0"
            argv = [arm["binary"],"--batch",spec["manifest"],"--threads","32",
                    "--cards-json",str(Path(arm["cwd"])/"src/cards/data/cards.json"),
                    "--game-log-dir",str(stage/"wins"),"--game-trace-dir",str(stage/"traces")]
            write(stage/"argv.json", argv)
            write(stage/"environment.json", {k:v for k,v in env.items() if k.startswith("MTG_") or k=="OMP_NUM_THREADS"})
            with (stage/"batch.log").open("xb") as stdout, (stage/"batch.err").open("xb") as stderr:
                result = subprocess.run(argv, cwd=arm["cwd"], env=env, stdout=stdout, stderr=stderr)
            need(result.returncode == 0, spec["name"]+": nonzero engine exit "+str(result.returncode))
            jobs = json.loads(Path(spec["manifest"]).read_text())["jobs"]
            results = []
            for job in jobs:
                name, gi = job["name"], job["game_index"]
                wf, uf = stage/"wins"/(name+".wins"), stage/"wins"/(name+".units")
                tf = stage/"traces"/(name+"_gi"+str(gi)+".json")
                wins, units = wf.read_text().strip().splitlines(), uf.read_text().strip().splitlines()
                need(len(wins) == len(units) == 1, name+": missing/duplicate result")
                wp, up = wins[0].split(), units[0].split()
                need(len(wp)==3 and int(wp[0])==int(up[0])==gi, name+": malformed GI/row")
                need(bool(re.fullmatch("[0-9a-f]{16}",wp[2])) and int(up[1])>=0, name+": digest/units malformed")
                trace = json.loads(tf.read_text())
                need(trace["seed"]==job["seed"] and trace["gameNumber"]==gi, name+": physical trace identity mismatch")
                win = int(wp[1]); tr = trace["result"]
                need((win>0 and tr["winner"]!="none" and tr["turn"]==win)
                     or (win<=0 and tr["winner"]=="none"), name+": trace/outcome mismatch")
                case = next(r for r in plan["rows"] if r["gi"]==gi and name.startswith(r["key"]+"_"))
                expected = (case["baseline_row"] if spec["arm"]=="baseline" else case["current_row"])
                results.append(dict(job=name, key=case["key"], seed=job["seed"], gi=gi,
                                    outcome_row=wins[0], units_row=units[0], expected_normal_row=expected,
                                    normal_row_equal=wins[0]==expected,
                                    role="counterfactual_no_plan_memos" if spec["name"]=="baseline_no_plan_memos"
                                    else "recovery" if name!=case["control_job"]["name"] else "exact_normal",
                                    wins_sha256=sha(wf), units_sha256=sha(uf), trace_sha256=sha(tf), trace_path=str(tf)))
            diagnostics = [dict(line=i,text=line) for i,line in enumerate((stage/"batch.err").read_text().splitlines(),1)
                           if re.search(r"\[(?:fd-diverge|fd)\]|FORECAST.DISAGREEMENT|NONCONV|OVERFLOW",line,re.I)]
            r = dict(status="DONE", returncode=0, source_tree=arm["source_tree"], binary_sha256=arm["binary_sha256"],
                     jobs=len(jobs), results=results, diagnostics=diagnostics,
                     batch_log_sha256=sha(stage/"batch.log"), batch_err_sha256=sha(stage/"batch.err"),
                     turn_census_sha256=sha(stage/"turn-census.tsv") if (stage/"turn-census.tsv").exists() else None)
            write(stage/"DONE.json",r)
            receipt["stages"][spec["name"]]=r
        receipt.update(status="DONE", finished=datetime.now(timezone.utc).isoformat(),
                       scope="Completion/identity/trace guards only. Counterfactual equivalence, recovery, physical legality and adoption require review.")
        write(out/"DONE.json",receipt)
        print(json.dumps(receipt,indent=2))
    except BaseException as e:
        receipt.update(status="FAILED",error=str(e),finished=datetime.now(timezone.utc).isoformat())
        write(out/"FAILED.json",receipt)
        raise


if __name__=="__main__":
    main()
