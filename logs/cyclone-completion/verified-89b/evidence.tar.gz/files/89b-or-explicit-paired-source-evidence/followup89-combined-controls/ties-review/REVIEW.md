# Seven tied physical games reviewed

All seven normal paired games reproduce the measured old/new outcome rows. Opening and mulligan sequences match. No new legality defect was found in the reviewed alternate lines. Four regression ties are closed; the three slower regression cases remain with the payment reviewer. No source, ground-truth, or engine operations were performed.

The three smoke changes are suitable for root filtered acceptance using `--smoke --accept --deck=bruna,edf,landfall`, after the parent checks harness/PGO status and verifies the GT diff preserves the newer PD/Slivers artifacts. The prior three-game smoke packet remains unrun and superseded.

EDF is a real source-choice change: Mariposa tap-draw becomes Conservatory investigate plus the paid Clue crack. Untap routing changes, while all phase-end physical boards and the same drawn-card sequence match. Raw digest changes are preserved.

## goblins_regression_d5_s2002 GI57

T2 MAIN_2: Chainwhirler#4, Chieftain#5, Hordemaster#50 versus Muxus#46, reveal4 Goblins, Hordemaster#50, Lackey#12, War Marshal#23.

Both Mountains were already tapped; Skirk Prospector#56 is the no-tap Goblin-sacrifice red source. Old cast costs3+3+2=8 and eight Goblins move to graveyard; new costs6+2+1+2=11 and eleven Goblins move to graveyard. Muxus reveal and Marshal token add the bodies needed for later payments. Prospector survives both lines. Pashalik death triggers explain life19→15/16. New T3 two Mountains tapped while Marshal survives is consistent with its1R echo upkeep, an implicit non-action in this JSON; fresh Mountain then remains available. Chieftain haste permits the old new-cast Lackey/Piledriver attack; the new pre-existing team attacks for17. Lackey puts Siege-Gang midcombat without casting or attacking with the fresh Commander. Old combat14 leaves1 and paid Siege-Gang/sacrifice reaches−1 in MAIN_2; new combat17 reaches−1. No double-use of sacrificed bodies or unpaid Goblin mana required.

Both T3, differing legal sacrifice/cast/kill lines.

## minotaur_regression_d5_s2002 GI438

T1 MAIN_1 after Cavern#13: Scarhide#21 for B versus Aether Vial#1 for1.

Cavern can make unrestricted colorless for the artifact, and creature-restricted B/R for these Minotaurs. New Vial charge snapshots climb1,2,3 on T2/T3/T4, matching Scarhide MV1, Slaughter-Priest MV2, Rageblood MV3. Vial taps once per turn. Bloodstained Mire fetches basic Mountain#30 and life20→19, no shock entry choice. T3 Rageblood1RR is paid from Cavern plus two Mountains. T4 Vial puts second Rageblood, then Burning-Fist pays1R and discards a card; two Mountains tap and the non-tap pump leaves the creature attack-ready. Old T3/T4 lord/cast sequence and Karoo return also fit available sources. New damage6 then17 versus old2/8/11 is compatible with lords, first strike and the pump; both lethals T4.

Both T4, different legal early deployment/Vial line.

## melira_regression_d5_s2002 GI98

T5 MAIN_1 action6 Chord of Calling#24 chooses X3 versus X4; the entire physical trace before this action matches.

Common T5 spells cost G+G+B, Pod1 plus2life, then second Hierarch G after the fifth land. Five land mana fund those five pips; Chord is paid through convoke, not fresh dork mana. Convoke may tap summoning-sick creatures: no tap symbol, green bodies pay G and others generic. The Melira/Finks/Ranger/Feeder/Celes/dork board supports six convoke payments for X3GGG or seven for X4GGG; green Birds, Hierarch and Finks can cover the three green pips. The post-Chord persist burst can return a previously tapped Finks untapped, so final untapped-body counts are not an exact per-cost transcript. Old fetch is Kitchen Finks#35; Feeder+persist+Melira/Celes produces the counters/life burst and combat20. New fetch is Redcap#46, ETB2 reduces16→14, combat4 leaves10, and MAIN_2 has the retained Feeder/persist enablers plus Redcap: the implicit sac/persist burst finishes−5. Newly cast/fetched bodies do not attack in the new line. Zone/counter/life differences fit distinct tutor/finish choices, not the same board mislabeled.

Both T5; old combat kill, new postcombat persist/Redcap kill.

## landfall_regression_d5_s3003 GI125

T3 MAIN_1 after playing Myriad#38: Rampant Growth#54 versus activating old Myriad#36.

At T3 Search-for-Tomorrow has arrived before draw: Forests#21/#22 and old Myriad#36 are available. New Myriad#38 enters tapped; old#36 taps/sacrifices and the two Forests pay2, fetching two same-type Mountains tapped. Old Rampant pays1G with Forest plus old Myriad and fetches tapped Forest instead. New T4 Rampant then second Myriad activation+Wilds fetch is supported by four starting untapped basics; Myriad cannot fund its own2 and the displayed taps honor that. Both Avenger casts T5 cost5GG from seven available lands. Old seven Plants get three counters T6 (land drop plus Myriad2) and attack21+Avenger5=26. New eight Plants get one counter from post-Avenger T5 Myriad drop; T6 starts nine lands plus Forest drop=10 to pay Wave7GGG. Wave puts two Forests, Courser and fresh Titan; Titan puts two more lands. Five T6 landfall events raise existing Plants1→6; eight*6+Avenger5=53, while fresh Titan/Courser do not attack. No mana credit from tapped fetches needed.

Both T6, different legal ramp/search/Wave finish.

## bruna_smoke_d3_s1001 GI3

T2 MAIN_1: Wild Growth#60 then Greaves#36 then Chancery#6 versus Chancery#6 then Wild Growth#60.

Old Birds pays Growth G onto Botanical#12; Botanical then produces two for Greaves. Chancery bounces Botanical and Growth goes to graveyard. New Chancery bounces Botanical before Growth: FloatKarooBouncedLand preserves its G in the same phase, paying Growth onto Chancery while Birds remains untapped. T3 enchanted Chancery WU+G plus Birds funds Armory1W and Greaves2; old only needs Armory. T4 two existing lands mean Botanical fastland enters untapped. New sources ChanceryWU+G, FarmWW, Birds1, Botanical1 total7 pay Bruna3WWU plus second BirdsG; old sources total6 pay only Bruna. Farm depletion2→1 recorded. Equip0 gives haste; Bruna attack non-targeting attachment legally puts Colossification despite Greaves shroud, taps the attacker without removing it from combat and deals25. Both T4−5 opponent life.

Both T4, valid Karoo float/Aura-host and Greaves-timing change.

## edf_smoke_d5_s1001 GI87

T7 MAIN_1 action2: Mariposa#35 draw-a-card versus Conservatory#13 investigate. Prefix through drawing Displacer#18 matches.

Definitions differ materially: Mariposa has5,T draw (rad discount only if counters); Conservatory has4,T investigate and its generated Clue costs2,sac draw. Default FusedClueCrackCost/ApplyPermAbility charges the extra2 and cracks it; this is a real source/cost choice, not a renamed ability. Prior board includes Hub#3 with Fertile+Trace (C plus2wild) and Hub#4 with two Overgrowth+Wild Growth+Fertile (C plus5G+wild), plus Coast lands; both5 and6 generic draw payments excluding their tapped source leave Displacer2W payable. Training Grounds reduces Displacer2C toC, not generic/color mana; Hubs provide realC and Cloud untaps two actual lands repeatedly. New/old untap pairs differ at actions5/7 and around Emiel draw. Both draw the same physical card sequence, wish for sideboard Essence Depleter, and execute blink x60/realC drain; every phase boardAfter is EXACT identical, ending life32/opponent0. No claimed exact per-tap payment transcript or per-cache-hit witness: this JSON has phase snapshots, costs and untap events, not every internal mana allocation.

Both T7. Real paid draw-source/loop routing change with identical physical phase-end states.

## landfall_smoke_d5_s1001 GI60

T1 MAIN_1: Mountain#33 versus Forest#18. New Search-for-Tomorrow#57 leaves hand and Forest taps in the same phase.

Search suspension is implicit in this trace schema: new hand loses#57 at T1 and an untapped Forest#19 appears before T3 draw, exactly theG suspend2→T3 upkeep search route. Old retains#57 for hardcast. Both T2 pay Rampant1G using Forest+Mountain and fetch tapped Forest. New off-suspend shuffle precedes T3 draw (Phylath#42), so different later draws are downstream of a different legal search schedule, not hidden deck drift. Old T3 Cultivate2G and new T3 Rampant1G both build six basics for Phylath4RG on T4. New then plays/sacrifices Terramorphic: two landfalls on existing Plants; T5 Search, Cultivate, and land drop add three more. Old T5 Search/Cultivate/drop/Rampant gives four landfalls. One target Plant carries4 per landfall: new20 plus Phylath5=25, old16+5=21; fresh Plants wait untilT5 to attack. Search-fetched basic enters untapped and can fund later spells; Rampant/Cultivate fetched basics are tapped. No free mana from those tapped puts assumed.

Both T5, valid suspend/ramp/landfall schedule; implicit suspend inferred from source and physical zones, not a nonexistent emitted SUSPEND event.

Source applicability: C2→89b production diff adds billing-context bit64 in FoldPhysicalCards and fetched-land human hook. These autonomous runs install no human land-entry chooser; its null-hook branch is literally the old LandEntersTapped path. Billing-context separation can change charged search work and selected plans. No per-hit diagnostic was captured, so no particular collided cache entry is identified or attributed solely from first divergence. Menu metadata/test hooks do not drive these batch choices.

Limits: All7 tied normal physical traces reviewed, card definitions/costs checked, entry/zone/haste/convoke/activation/fetch and mana-source feasibility inspected through lethal. JSON omits some automatic suspension/echo/sac-burst/mana microactions; those are distinguished from emitted evidence and checked against source. This is regression acceptance review within existing modeled card contracts, not an assertion that this engine models all MTG timing. No engine/source/GT mutation by reviewer. Three slower cases and recoveries are separate payment-review ownership.

`verdict.json` binds both14 full traces by SHA to the completed process receipt, original outcomes/units, full physical diffs and the exact84-name card inventory (76 database definitions plus8 generated labels). `smoke-verdict.json` is the separate three-game smoke closure. Both process queues report no FD/NONCONV.
