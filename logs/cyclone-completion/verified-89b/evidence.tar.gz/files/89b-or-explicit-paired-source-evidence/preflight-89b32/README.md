# Final89b compiler parity —32 requested workers, unsealed

Final source89b146d10406063213d9abe41e1cfdf1a616c021. Actual ReleaseSHA:
aca52a788964b4b80ab321477595a348221652a749c27c936f57b93362e0e56d.
PGOSHA is mandatory and currentlyNULL. Earlier preflight-89b worker1 draft
is preserved unsealed/unrun and superseded. C2 evidence remains historical.

Exactly3games:107008/GI8,127012/GI12leaf0,131117/GI117, with original flags/
profile/setup. Both compilers request32workers (only3jobs available). They
run serially; no whole-smoke compiler rerun. Guard checks cleanHEAD:src,
exact Release/PGO hashes, PGO SRC_TREE, manifest/script and asset directories.
InheritedMTG_/VPC_ settings are cleared, units/FD/NONCONV enabled. All raw
output is exclusive; no timeout. Check compares exact rows/units/full JSON
physical trace excluding only top-level deckId/runId container fields.

Root commands after PGO completes:

```bash
PARITY=/workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/preflight-89b32
python3 "$PARITY/preflight.py" --seal-pgo-sha256 ACTUAL_64_HEX_PGO_SHA256
python3 "$PARITY/preflight.py" --run
python3 "$PARITY/preflight.py" --check
```

Historical4/5/4 turns are retained as a separate sanity check; any legitimate
new-source difference requires review, not forced old digest/unit values.
Preparation precheck/syntax passes. No compiler, engine or model was run.

Fresh full normal regression wrapper:

```bash
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/run_normal_89b.py \
  regression --binary-sha256 ACTUAL_64_HEX_PGO_SHA256
```

Its exclusive output is followup-normal-regression, at32workers. It preserves
initialrc1 for reviewed GT mismatches rather than relabeling the harness0.
Normal regression automatically runs the fullstrict reference sweep with
the same snapshot binary, plus suboptimal require-beat. Do not duplicate a
standalone fullstrict sweep. Smoke89b was already measured in Release; parity
and full PGO regression are the required compiler follow-up here.
