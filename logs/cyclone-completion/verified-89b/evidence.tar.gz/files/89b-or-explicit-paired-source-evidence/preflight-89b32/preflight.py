#!/usr/bin/env python3
"""Prepare-only by default; explicit --run launches fresh Release and PGO processes."""
import argparse
import datetime
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(65536),b''):h.update(block)
    return h.hexdigest()


def git(tree, *args):
    return subprocess.check_output(["git", "-C", str(tree), *args], text=True, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"}).strip()


def precheck(prepared, sealed=True):
    tree = Path(prepared["source_worktree"])
    assert git(tree, "rev-parse", "HEAD:src") == prepared["source_tree"]
    assert not git(tree, "status", "--porcelain", "--untracked-files=all", "--", "src")
    assert sha(HERE / "manifest.json") == prepared["manifest_sha256"]
    for path, value in prepared["assets"].items():
        assert sha(Path(path)) == value, path
    for directory, expected in prepared['asset_directories'].items():
        folder=Path(directory)
        assert {str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()}==expected, directory
    assert prepared['threads']==32
    release=prepared['compilers']['release']
    assert sha(Path(release['path']))==release['sha256'], 'Release bytes changed'
    if sealed:
        original=json.loads((HERE/'run-preparation.UNSEALED.json').read_text())
        normalized=json.loads(json.dumps(prepared))
        for key in ('sealed_input_hashes','sealed_at'):normalized.pop(key,None)
        normalized['compilers']['pgo']['sha256']=None
        assert normalized==original, 'Sealed recipe changed beyond explicit PGO hash binding'
        for spec in prepared['compilers'].values():
            assert re.fullmatch('[0-9a-f]{64}',spec['sha256'] or ''), 'Compiler hash unsealed'
            assert sha(Path(spec['path']))==spec['sha256'], spec['path']
        assert Path(prepared['compilers']['pgo']['path']).parent.joinpath('SRC_TREE').read_text().strip()==prepared['source_tree']
        for path, value in prepared['sealed_input_hashes'].items():assert sha(Path(path))==value, path


def run(prepared):
    precheck(prepared)
    tree = Path(prepared["source_worktree"])
    runs = HERE / "runs"
    runs.mkdir(exist_ok=False)
    env = {k: v for k, v in os.environ.items() if not k.startswith(("MTG_", "VPC_"))}
    env["GIT_OPTIONAL_LOCKS"] = "0"
    env.update(prepared["expected_env_additions"])
    provenance = {"source_tree": prepared["source_tree"], "head_at_launch": git(tree, "rev-parse", "HEAD"),
                  "preparation_sha256": sha(HERE / "run-preparation.json"), "manifest_sha256": sha(HERE / "manifest.json"),
                  "controls": {k: v for k, v in sorted(env.items()) if k.startswith(("MTG_", "VPC_"))}, "compilers": {}}
    for arm in ("release", "pgo"):
        precheck(prepared)
        output = runs / arm
        output.mkdir()
        (output / "wins").mkdir()
        (output / "traces").mkdir()
        spec = prepared["compilers"][arm]
        argv = [spec["path"], "--batch", str(HERE / "manifest.json"), "--threads", str(prepared["threads"]),
                "--cards-json", str(tree / "src/cards/data/cards.json"),
                "--game-log-dir", str(output / "wins"), "--game-trace-dir", str(output / "traces")]
        entry = {"argv": argv, "cwd": str(tree), "binary_sha256": spec["sha256"],
                 "started": datetime.datetime.now(datetime.timezone.utc).isoformat()}
        print("START", arm, flush=True)
        with (output / "batch.log").open("wb") as stdout, (output / "batch.err").open("wb") as stderr:
            entry["returncode"] = subprocess.run(argv, cwd=tree, env=env, stdout=stdout, stderr=stderr).returncode
        entry["finished"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        entry["output_sha256"] = {str(p.relative_to(output)): sha(p) for p in sorted(output.rglob("*")) if p.is_file()}
        entry["warnings"] = [line for line in (output / "batch.err").read_text().splitlines()
                             if "[fd-diverge]" in line or "[nonconv]" in line]
        provenance["compilers"][arm] = entry
        (runs / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
        print("DONE", arm, "exit", entry["returncode"], "fidelity_warnings", len(entry["warnings"]), flush=True)
        precheck(prepared)
        if entry["returncode"] != 0 or entry["warnings"]:
            print("STOP: failed process/fidelity gate; later compiler not launched", flush=True)
            return 1
    return check(prepared)


def check(prepared):
    precheck(prepared)
    provenance = json.loads((HERE / "runs/provenance.json").read_text())
    jobs = json.loads((HERE / "manifest.json").read_text())["jobs"]
    checks = [{"check": "preparation unchanged", "ok": sha(HERE / "run-preparation.json") == provenance["preparation_sha256"]},
              {"check": "manifest unchanged", "ok": sha(HERE / "manifest.json") == provenance["manifest_sha256"]}]
    for arm, entry in provenance["compilers"].items():
        folder = HERE / "runs" / arm
        checks.append({"check": arm + " launch and diagnostics", "ok": entry["returncode"] == 0 and not entry["warnings"]})
        checks.append({"check": arm + " output hashes", "ok": all(sha(folder / rel) == digest for rel, digest in entry["output_sha256"].items())})
        text=(folder/'batch.log').read_text()
        assert text.splitlines().count('=== BATCH done (3 jobs, 3 games) ===')==1
        complete=re.findall(r'^(\S+): played=(\d+) avg=[\d.]+ digest=\S+ ms=\d+ units=\d+$',text,re.M)
        assert len(complete)==3 and {n for n,g in complete}=={j['name'] for j in jobs} and all(g=='1' for n,g in complete)
    results = []
    for job in jobs:
        armdata, traces = {}, {}
        for arm in ("release", "pgo"):
            folder = HERE / "runs" / arm
            win = folder / "wins" / (job["name"] + ".wins")
            units = win.with_suffix(".units")
            trace = folder / "traces" / (job["name"] + "_gi" + str(job["game_index"]) + ".json")
            row, work = win.read_text().strip(), units.read_text().strip()
            values, work_values = row.split(), work.split()
            assert len(values) == 3 and len(work_values) == 2
            assert int(values[0]) == job["game_index"] == int(work_values[0])
            armdata[arm] = {"win_row": row, "units_row": work, "win_turn": int(values[1]), "trace_sha256": sha(trace)}
            traces[arm] = json.loads(trace.read_text())
            # Only file-container IDs are excluded; every physical/choice/zone field remains.
            for key in ("deckId", "runId"):
                traces[arm].pop(key, None)
        result = {"job": job["name"], "seed": job["seed"], "game_index": job["game_index"], "compilers": armdata,
                  "wins_digests_equal": armdata["release"]["win_row"] == armdata["pgo"]["win_row"],
                  "units_equal": armdata["release"]["units_row"] == armdata["pgo"]["units_row"],
                  "full_physical_trace_equal_except_container_ids": traces["release"] == traces["pgo"],
                  "historical_turn_sanity": prepared["sanity_turns"][job["name"]],
                  "turn_sanity_matches": all(x["win_turn"] == prepared["sanity_turns"][job["name"]] for x in armdata.values())}
        result["compiler_parity_ok"] = result["wins_digests_equal"] and result["units_equal"] and result["full_physical_trace_equal_except_container_ids"]
        results.append(result)
        print("PASS" if result["compiler_parity_ok"] else "FAIL", job["name"], armdata["release"]["win_row"], armdata["release"]["units_row"], "turn_sanity=" + str(result["turn_sanity_matches"]))
    report = {"scope": "fresh Landing905 Release versus PGO identity, no old-source row/units carry",
              "checks": checks, "results": results,
              "compiler_parity_ok": all(x["ok"] for x in checks) and all(x["compiler_parity_ok"] for x in results),
              "all_turn_sanity_matches": all(x["turn_sanity_matches"] for x in results),
              "turn_delta_policy": "A changed historical sanity turn requires source-delta/legality review; do not force old digest/units or silently classify legitimate source changes as compiler failures."}
    (HERE / "review.json").write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["compiler_parity_ok"] and report["all_turn_sanity_matches"] else 1


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--seal-pgo-sha256")
    group.add_argument("--run", action="store_true")
    group.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.seal_pgo_sha256:
        assert not (HERE/'run-preparation.json').exists(), 'Seal is exclusive; preserve old seal'
        prepared=json.loads((HERE/'run-preparation.UNSEALED.json').read_text())
        precheck(prepared,sealed=False)
        assert re.fullmatch('[0-9a-f]{64}',args.seal_pgo_sha256), 'Explicit actual fresh PGO SHA256 required'
        prepared['compilers']['pgo']['sha256']=args.seal_pgo_sha256
        prepared['sealed_input_hashes']={str(HERE/name):sha(HERE/name) for name in ('preflight.py','manifest.json','run-preparation.UNSEALED.json')}
        precheck(prepared)
        prepared['sealed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (HERE/'run-preparation.json').open('x') as f:f.write(json.dumps(prepared,indent=2)+'\n')
        print('SEALED ONLY; no engine launched')
        return 0
    if not (HERE/'run-preparation.json').exists():
        assert not args.run and not args.check, 'Explicit fresh PGO seal required before run/check'
        prepared=json.loads((HERE/'run-preparation.UNSEALED.json').read_text());precheck(prepared,sealed=False)
        print('PREPARED/UNSEALED: actual PGO SHA required; no engine launched')
        return 0
    prepared = json.loads((HERE / "run-preparation.json").read_text())
    if args.run:
        return run(prepared)
    if args.check:
        return check(prepared)
    print("PREPARED ONLY: use --run after fresh compiler sealing and root scheduling, or --check to inspect completed outputs. No engine launched.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
