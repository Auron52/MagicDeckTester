# Frozen89b PGO profiling, first16 matched play_s2002 identities

Preparation only. Root owns engine lease and launch after shared landing. Run exactly once:

```bash
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/profile89-first16-live-pb/run.py --check
python3 /workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/profile89-first16-live-pb/run.py --run
```

This executes one32-worker queue of32 singletons: globalGI0–15 / actualseeds2002–2017, in BOTH measured shipping live flags{} and originalPB-on flags{MTG_CYCLONE_PB_PLANS:true}. The first16 are chosen by GI, with no outcome/time filtering. `selection.json` preserves every original chunk job, expected win/digest/unit row, and only singleton normalization. Original omitted depth/profile, budget20, horizon8, life20/heads1, salts0 and weights remain exact. No Ponder/KEEP/SITU/SEED/cast-policy changes.

`plan.json` and `packet-seal.json` bind source89b, PGO20de, exact binary executable, runtime cards JSON and all Cyclone sidecars (including absence of unrecorded new sidecars), perf executable, manifest and original quiet855 evidence bytes. Source HEAD may change through docs-only shared landing but clean source tree must stay exact. All inherited MTG variables are cleared, then ONLY original quiet environment MTG_PGO=1, MTG_DUMP_UNITS=1, MTG_SLOW_GAME_MS=1 is installed. Other inherited process environment is retained as in the actual cost runner; relevant OMP/loader/allocator values are recorded. No new engine diagnostic flags or fullJSON tracing are added.

Actual outer command is `perf record -e cycles:u -F49 --call-graph dwarf,8192 -o runs/perf.data -- <frozen-PGO> --batch <manifest> --threads32 --game-log-dir runs/wins`, as a real argv list (the actual CLI passes `--threads` and `32` separately). Full per-game wins/digests/decisionunits are preserved. Root signals are forwarded to that process group; no timeout, automatic cancellation, overwrite, build, model invocation or follow-up engine stage exists. All logs/status/argv are new exclusive files. DONE requires rc0, nonempty perf.data and source/asset guard recheck; a separate explicit field requires all32 exact result+unit reproductions to quiet855. A mismatch returns nonzero, preserves raw data, and blocks interpretation as the original exact apparatus.

This is attribution ONLY: perf overhead and singleton scheduling differ from the quiet gate. No new ms ratio/gate/adoption claim. Raw quiet cost has no FD/nonconv oracles enabled, so neither does this profiler; missing warnings are not a new fidelity proof.

Use `target-proof.json` and `target-symbols.txt` for actual frozen-symbol/instruction evidence. The binary has symbol/unwind tables but no source-line debug info. The one process mixes both arms and current logs lack workerTID/job bindings; cycle shares are pooled, not separate live/PB claims. After DONE root can use `perf report --stdio --no-children`, callchains and instruction annotation of the named symbols; retain sample/lost/unwind diagnostics. The proof distinguishes label/string work, actual telemetry lock-add sites, exact cache key/derive/hit-billing stacks and full apply/rollout work. Function exposure does not automatically equal removable cost, and cycles-only sampling does not itself prove cacheline contention. No engine was launched while preparing/checking this packet.
