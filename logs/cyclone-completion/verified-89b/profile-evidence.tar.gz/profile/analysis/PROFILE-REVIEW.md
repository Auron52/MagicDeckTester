# Actual frozen89b PGO profile

18,086 cycles:u samples,0lost; weightedperiod1,682,932,655,878. All32 originalquiet855 win/digest/unit rows reproduce exactly. The152,729,556byte perfdata SHA is`13b3593bc8012389f0db42b6c75c76593b3f3c0c0bdbcd32bab0581e02f8f9d7`. Source89b/PGO20de pinned by completedrunner. Onefirst16-GI matched live/PB pool at32workers, attributiononly: no perarm cycle shares, wallcomparison or newgate/adoption claim.

## Measured priority

Ponder human disposition/label builder has0.607%exclusive and0.893%observedlocalinclusive exposure. Allocatorleaves underneath it are0.115%; onlypart ofthe subtree is labelconstruction. The named solve/leaf telemetry lock-add instructions receive ZERO exact-IP samples; the UNIONof±16byte instruction neighborhoods is0.0895%weightedcycles. Those neighborhoods include ordinary neighboringinstructions and sampling skid. This is not provedatomiccost or a cacheline-contention measurement. Actualprocess counters show9,064,238 solve/leaf report increments, so exposure occurred, but count alone did not establish material cost.

The larger observed workload is plan application, put-back resolution, exact keys and payment. Inclusivecategories overlap; do not add them or equate their wholecost with removable work. No singlehelper explains a78%livecost reduction.

| Family | Exclusive% | Observedlocalinclusive% |
|---|---:|---:|
|ApplyPlanDirect body+named lambdas|10.411|63.520|
|Put-back resolver|2.420|13.552|
|TapForCostShared family|7.651|14.390|
|Observed exact-key family|8.291|9.092|
|BuildSimKeyBase|6.936|6.953|
|ComputePlanTraits|2.433|2.644|
|CollectActions|2.575|4.620|
|EnumeratePlans and named lambdas|1.505|4.184|
|ScoredReorderCandidates and named lambdas|0.627|3.191|
|Human disposition/label builder|0.607|0.893|
|BP enumerationcache lookup/entry|0.257|3.818|
|BP continuation derivation|0.184|1.120|

## Top20 exclusivefunctions

|%|Samples|Function(shortened)|
|---:|---:|---|
|6.94%|1236|BuildSimKeyBase(GameState const&, int, bool) [clone .lto_priv.0]|
|4.11%|728|ApplyPlanDirect(GameState&, TurnSolver::Plan const&, bool, std::vector<Action, std::allocator<Action> >*, BpPrefixSnap*, BpPrefixSnap const*, int) [cl|
|3.24%|588|bool TapForCostSharedOnceImpl(GameState&, ManaCost const&, bool, unsigned long, ManaPool*, bool)::{lambda(auto:1&, Color, bool, bool)#1}::operator()<{|
|2.54%|458|CollectActions(GameState const&, bool) [clone .lto_priv.0]|
|2.54%|449|__memmove_avx512_unaligned_erms|
|2.43%|438|TurnSolver::ComputePlanTraits(GameState const&, std::vector<Action, std::allocator<Action> > const&)|
|2.42%|430|ResolvePutBackFromHand(GameState&, int, int, std::__cxx11::basic_string<char, std::char_traits<char>, std::allocator<char> > const&)|
|2.38%|433|ApplyPlanDirect(GameState&, TurnSolver::Plan const&, bool, std::vector<Action, std::allocator<Action> >*, BpPrefixSnap*, BpPrefixSnap const*, int)::{l|
|2.11%|364|TurnSolver::SolveWithLookahead(GameState const&, bool, int, int, SearchBudget*, bool, bool, TranspositionTable*, int*, int*)|
|2.07%|373|ApplyPlanDirect(GameState&, TurnSolver::Plan const&, bool, std::vector<Action, std::allocator<Action> >*, BpPrefixSnap*, BpPrefixSnap const*, int)::{l|
|1.86%|335|operator new(unsigned long)|
|1.66%|295|ShuffleAfterSearch(GameState&, int)|
|1.62%|294|TapForCostShared(GameState&, ManaCost const&, bool, ManaPool*, bool)|
|1.40%|259|TurnSolver::SolveUncached(GameState const&, bool, TurnSolver::GreedyPermit const&) [clone .isra.0]|
|1.32%|230|TapForCostSharedOnceImpl(GameState&, ManaCost const&, bool, unsigned long, ManaPool*, bool) [clone .lto_priv.0]|
|1.29%|232|ManaSourceRankBase(GameState const&, CardDefinition const&) [clone .lto_priv.0]|
|1.20%|205|unsigned long& std::vector<unsigned long, std::allocator<unsigned long> >::emplace_back<unsigned long>(unsigned long&&)|
|1.19%|200|CycloneProvider::ScoreTopDisposition(GameState const&, int, CantripReadiness const&, TopDispositionView const&, int&) const|
|1.15%|214|GameState::GameState(GameState const&) [clone .lto_priv.0]|
|1.11%|194|SimulateEndAndStartNextTurn(GameState&) [clone .lto_priv.0]|

Unshortened symbols/periods are in `top20.json` and `exclusive-flat.tsv`.

## Concrete source-backed optimization targets

1. **Exact common-prefix reuse.** ApplyPlanDirect body+lambdas has10.411%self/63.520%observedlocalinclusive; castlambda alone34.15%inclusive. Put-back13.552%inclusive includes actual resolver/scorer/vector work. Existing sourceidentity at TurnSolver.cpp27176 states sibling applies share the prefix through the first consumingcantrip; fullprefixresume remains unbuilt. The record does not identify how much of63.52%is beforethat choice or reusable. Capture/restore wholeline paymentholds, physicalcard identities/knowninformation, consumedpins, BPlatent/dirty/ancestorprovenance and EXACTreplayed billing/work. A state-onlysnapshot that makes prefixwork free is not pure. This is the larger opportunity, with the larger proof burden.

2. **Put-back preparation before its cache hit.** Observedinclusive stacks include CycloneProvider::PutBackRanking3.87%, genericbase3.82% and CleanupDiscardShedOrder4.18%(overlap). One chain from CycloneBucketRankOf through cleanup/default ranking to ResolvePutBack contributes0.859%globalcycles. PutBackPickAt40338 first buildsclasses/provider ranking and the pair sequence, then checksrankcache40463. The currentcache skips scoring/sort, leaving this measuredprelude. An early finalfan cache read can be pure ONLYwith all current state/class/condemnation/physical-copy inputs retained. Do not drop pair-sequence/class-side dependencies for earlier hits. Same-key finalpairs/counts/ranks must match with flags, handorder, staged/M1boundaries, P/T and k0/k1dualroles. No newquota/default/keyweakening.

3. **Library deadprefix reuse.** The observed vector<Card>::_M_realloc_insert→vector.insert→ResolvePutBack chain is1.003%globalcycles; resolver2.420%self and other Cardmoves overlap. Libraryhas m_top/dead drawnslots, but both insert overloads at Library.h191–203 always vector-insert. Brainstorm/Brainsurge draw3/4 justbefore two frontinserts at SpellEffects.h40699. A leading-slot reuse path can assign into the deadprefix when m_top>0 rather than shifting/allocating the livesuffix. Preserve KnownInsert(0,oldsize), BottomPlaced/KnownBottom, alias/move/iterator behavior and existing indexcarry whole-library-read witness from begin(). Retain unchangedfallback withoutheadroom or atotherpositions. Concrete small optimization; not a4.56xspeedupprediction.

4. **Exact keys and invariantmetadata.** BuildSimKeyBase6.936%self is the largest helper. Its two largest observed localcallerchains are BuildDedupKeyBeforeLandSearchPins→SolveWithLookahead2.171%global and the sameviaLaWaveDup1.228%; breakpointkey/enumlookup0.903%; rolloutmemo0.854%. Allobserved keyhelpers8.291%self. Hotannotated ELF125414/12541c are in a0x80-stride hashloop;125e15 is a0x10-stride canonicalpair-emissionloop. These are instructionobservations, not source-line mappings. Lookfor repeatedbuilds on an unchangedstate, retaining exactlyexisting foldwords/order/physicalcontext/knowledge/billing64. ComputePlanTraits2.433%self (REP-STOS zerofill sampled) supports localfan metadatareuse only when physicalcomputationpoint/state and actualcontinuation-actionsubset match. Do not reuse traitsbased only on actionnames after differingprefixes: the recent filterpayer failure already falsifiedthat shortcut.

Ponderlabels and telemetry aggregation remain possible smallcleanup, but this actualprofile does not support prioritizingthem as the gate solution. Every purported purechange must preserve exact candidateorder, physical/observable/TLSstates and all units, then pass meaningfulnegative key/context tests and normalregression gates. Paymentreviewer separately owns pure enumeration-cache identity/charge analysis.

## Actual32-game enumeration/cachedwork

43,352,647units; exactfans895,232 plusboundfans235,169; exactranks31,340,958. Lazy364,409lists already avoid54,654,388clones, and BPcache260,824lazylists avoid33,558,852entries. Enummemo149hits/3,630misses; greedy Solvememo1,971,118hits/3,869,966misses/219clears. These are counts, not durations or reasons to change quotas. BPentry3.818%inclusive contains keybuild/derive/lookup; it is not hitpathcostalone.

## Limits and reproducibility

Raw stacks contain an unknown0xffffffffffffffff ancestor in99.529%weightedperiod; perf report children displays98.60%at that unknownnode. SelfunresolvedIPs are1.413%. Knownlocalcallee/caller chains show exposure, but complete root/window/leaf/real-game/bottoming-trial ancestry is unavailable. Unknownchaincause is not diagnosed here. Existing logs have no workerTID→arm map. Inclusivegroups count eachsampleonce pergroup, overlap and form no partition.

The binary has symbols/unwindtables but no source-line debuginfo. Corrected `annotate-v2-*.txt` provides actualsymbol+instruction evidence. Filteredannotation percentages normalize within selectedfunction data and are NOTquoted as globalpercentages; this report recomputesglobalweights from rawIP/callchain periods. Initial malformed-symbol annotationattempts are preserved as unusederrors. `commands-index.json` binds every rawperf report/script/annotate argv/returncode; rawstdout/stderr and actualsource-bound results remain. `analyze_samples.py` deterministically parsesrawsamples without engines; `sample-summary.json` retains exactperiods/atomic-IP neighborhoods. No engines/builds/source changes performed in thisanalysis.
