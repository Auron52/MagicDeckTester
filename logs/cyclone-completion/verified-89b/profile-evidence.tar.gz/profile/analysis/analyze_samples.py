#!/usr/bin/env python3
"""Engine-free parsing of immutable perf stdio/script output; no measured runs."""
from pathlib import Path
import json,re,subprocess,collections,hashlib
R=Path(__file__).resolve().parent; P=R.parent
p=json.loads((P/'plan.json').read_text());nm=subprocess.check_output(['nm','-n','-C',p['binary']],text=True);syms={}
for l in nm.splitlines():
 v=l.split(maxsplit=2)
 if len(v)==3:
  try:syms[v[2]]=int(v[0],16)
  except ValueError:pass
rx=re.compile(r'^\s*\S+\s+(\d+)/(\d+)\s+([\d.]+):\s+(\d+) cycles:u:\s+([0-9a-f]+) (.*)$')
ips=[];biases=collections.Counter()
for l in(R/'sample-ips.txt').read_text().splitlines():
 m=rx.match(l)
 if not m:raise RuntimeError('unparsed IPline '+l[:150])
 pid,tid,t,w,ip,rest=m.groups();sym,sep,dso=rest.rpartition(' (');assert sep and dso.endswith(')');dso=dso[:-1];sm=re.match(r'^(.*)\+0x([0-9a-f]+)$',sym);name=sm[1]if sm else sym;off=int(sm[2],16)if sm else 0
 item={'pid':int(pid),'tid':int(tid),'time':t,'period':int(w),'runtime_ip':int(ip,16),'name':name,'offset':off,'dso':dso};ips.append(item)
 if dso==p['binary']and name in syms:biases[int(ip,16)-syms[name]-off]+=1
bias=biases.most_common(1)[0][0]
assert all(x['runtime_ip']-syms[x['name']]-x['offset']==bias for x in ips if x['dso']==p['binary'] and x['name'].startswith('BuildSimKeyBase('))
total=sum(x['period']for x in ips)
for x in ips:
 if x['dso']==p['binary']:x['elf_ip']=x['runtime_ip']-bias
blocks=(R/'samples.txt').read_text().strip().split('\n\n');samples=[]
for b in blocks:
 lines=b.splitlines();m=re.match(r'^\S+\s+(\d+)/(\d+)\s+([\d.]+):\s+(\d+) cycles:u:\s*$',lines[0].strip());assert m,lines[0]
 frames=[]
 for l in lines[1:]:
  z=re.match(r'^\s*([0-9a-f]+) (.*?) \((.*)\)$',l);assert z,l
  frames.append({'ip':int(z[1],16),'name':z[2],'dso':z[3]})
 samples.append({'period':int(m[4]),'tid':int(m[2]),'frames':frames})
assert len(ips)==len(samples)and total==sum(x['period']for x in samples)
# Inclusive patterns intentionally overlap. One sample counted once per group, never once per recursion.
groups={'ApplyPlanDirect_any':['ApplyPlanDirect('],'Ponder_all':['ScoredReorderCandidates('],'Ponder_disposition_label_builder':['EnumerateTopDispositions('],'PutBack_resolution':['ResolvePutBackFromHand('],'PutBack_pick':['PutBackPickAt('],'Pay_mana':['TapForCostShared'],'Key_BuildSimKeyBase':['BuildSimKeyBase('],'Key_all_observed':['BuildSimKey','BuildBreakpointKey','BpEnumBuildKey','FoldPhysicalCards','CantripOrderKey','BuildDedupKey'],'ComputePlanTraits':['TurnSolver::ComputePlanTraits('],'CollectActions':['CollectActions('],'EnumeratePlans':['EnumeratePlans('],'BpEnumEntryFor':['BpEnumEntryFor('],'BpDeriveContinuationList':['BpDeriveContinuationList('],'SimulateToEnd':['SimulateToEnd('],'SolveWithLookahead':['TurnSolver::SolveWithLookahead(']}
summary={}
for k,terms in groups.items():
 hit=[x for x in samples if any(any(t in f['name']for t in terms)for f in x['frames'])];selfhit=[x for x in ips if any(t in x['name']for t in terms)];summary[k]={'inclusive_samples':len(hit),'inclusive_period':sum(x['period']for x in hit),'inclusive_pct':100*sum(x['period']for x in hit)/total,'exclusive_samples':len(selfhit),'exclusive_period':sum(x['period']for x in selfhit),'exclusive_pct':100*sum(x['period']for x in selfhit)/total}
# Keep label and malloc stack evidence; absence in a truncated chain is not proof of no allocation.
alloc_terms=['operator new(','malloc','free','_M_create','_M_mutate','_M_append','_M_replace','_M_construct']
label_alloc=[x for x in samples if any('EnumerateTopDispositions('in f['name']for f in x['frames'])and any(t in x['frames'][0]['name']for t in alloc_terms)]
for k,term in [('ponder','ScoredReorderCandidates('),('putback','ResolvePutBackFromHand('),('keys','BuildSimKeyBase(')]:
 c=collections.Counter()
 for x in samples:
  if any(term in f['name']for f in x['frames']):
   chain=tuple(f['name']for f in x['frames'][:12]);c[chain]+=x['period']
 with(R/f'{k}-top-callchains.json').open('x')as f:json.dump([{'global_pct':100*w/total,'period':w,'frames':list(chain)}for chain,w in c.most_common(15)],f,indent=2);f.write('\n')
locks=json.loads((P/'target-proof.json').read_text())['telemetry_lock_add_sites_hex'];locksummary={}
for k,aa in locks.items():
 addrs=[int(a,16)for a in aa];hit=[x for x in ips if 'elf_ip'in x and x['elf_ip']in addrs];near=[x for x in ips if 'elf_ip'in x and min(abs(x['elf_ip']-a)for a in addrs)<=16]
 locksummary[k]={'addresses':aa,'exact_samples':len(hit),'exact_period':sum(x['period']for x in hit),'exact_pct':100*sum(x['period']for x in hit)/total,'within16byte_samples':len(near),'within16byte_pct':100*sum(x['period']for x in near)/total,'nearby_IPs':[{'elf_ip':hex(a),'samples':sum(1 for x in near if x['elf_ip']==a),'period':sum(x['period']for x in near if x['elf_ip']==a)}for a in sorted({x['elf_ip']for x in near})]}
unknown=[x for x in samples if any(f['ip']==0xffffffffffffffff for f in x['frames'])];leafunknown=[x for x in ips if x['name']=='[unknown]']
byself=collections.Counter();selfn=collections.Counter()
for x in ips:byself[x['name']]+=x['period'];selfn[x['name']]+=1
result={'sample_count':len(ips),'total_period':total,'executable_load_bias_hex':hex(bias),'unknown_ffff_ancestor_samples':len(unknown),'unknown_ffff_ancestor_pct':100*sum(x['period']for x in unknown)/total,'self_unknown_samples':len(leafunknown),'self_unknown_pct':100*sum(x['period']for x in leafunknown)/total,'depth_histogram':dict(collections.Counter(len(x['frames'])for x in samples)),'inclusive_groups_overlap':True,'groups':summary,'labels_allocation_leaf_samples':len(label_alloc),'labels_allocation_leaf_global_pct':100*sum(x['period']for x in label_alloc)/total,'telemetry_lock_sites':locksummary,'top30_exclusive':[{'symbol':n,'samples':selfn[n],'period':w,'global_pct':100*w/total}for n,w in byself.most_common(30)],'scope':'Pooled cycles only. Inclusive values count only observed local ancestry and overlap. Unknown sentinel truncates nearly all ancestry; no root/window/leaf or perarm partition. Exact instruction samples are not an overhead estimate; nearby skid evidence is not proof of contention.'}
with(R/'sample-summary.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:result[k]for k in['sample_count','total_period','unknown_ffff_ancestor_pct','self_unknown_pct','labels_allocation_leaf_global_pct']}))
for k,v in summary.items():print(k,'self',round(v['exclusive_pct'],3),'inclusive',round(v['inclusive_pct'],3),'samples',v['exclusive_samples'])
print('LOCKS',json.dumps(locksummary,indent=1))
