# Independent cache/billing perf review

Frozen89b/PGO20de, one mixed live/PB32-game process; all32 wins/digests/units reproduce quiet855. This review only reads `perf.data` (SHA13b3593bc8012389f0db42b6c75c76593b3f3c0c0bdbcd32bab0581e02f8f9d7); no engine, build, source or policy changes.

18,086 self samples, `cycles:u`,49Hz, no lost samples. Fractions below are estimated cycle-period shares, not wall time.

| Function | Self | Captured inclusive |
|---|---:|---:|
| BuildSimKeyBase | 6.94% | 6.95% |
| ApplyPlanDirect body | 4.11% | 27.22% |
| TapForCostShared | 1.62% | 14.34% |
| ResolvePutBackFromHand | 2.42% | 13.55% |
| CollectActions | 2.54% | 4.62% |
| EnumeratePlans | .82% | 4.13% |
| BpEnumEntryFor | .26% | 3.82% |
| BpEnumBuildKey | .11% | 2.50% |
| BpDeriveContinuationList body | .06% | 1.12% |
| BpCanonFront | .01% | .27% |
| FoldPhysicalCards | .44% | .44% |
| CacheHitCharge | .04% (8samples) | .04% |
| cachecharge::Scope::Done | .00% rounded (1sample) | .00% rounded |

The large apply cast lambda separately has2.38% self/34.15% captured inclusive. ComputePlanTraits has2.43% self; memmove2.54%, allocation1.86%. Inclusive categories overlap and cannot be summed.

Exact annotations resolve charge functions as real callable code, rather than silently assuming all accounting was inlined. ScopeDone's one sample is struct zeroing at0x3544ad. Its three telemetry lock sites have no sampled IP. CacheHitCharge has75.30% of its own tiny local period at0x38003e, immediately after the hits_replayed lock; skid can move attribution past a lock, so this does not prove or disprove contention. EnumChargeScope's destructor (call target0x17ae70) and ConsumeAtN (0x624270) have no sampled IP/callchain entries; perf annotate reports no samples. Raw `.annotate.txt` and `.err` preserve this negative result. There is no distinct89b function named RecordCharge; captured budgets use CacheChargeNote and Scope setup.

The results do not identify bill bookkeeping or bit64 as the dominant cost. Removing the context boundary or enabling general charged-cache mode2 remains unsupported. A certified exit-only pure memo could avoid whole derivations, so tiny charging-function self cost alone does not disprove that idea. However this profile does not establish sufficient attributable repeated derivation cost to prioritize it. Keep the source proof/eligibility requirements in `billing-cache-performance-analysis/REVIEW.md`, especially subsearch warmth, nested charges, per-walk rounding, exact unit-site and side-counter behavior.

Ancestry is incomplete:98.60% accumulated under0xffffffffffffffff with0self is a sentinel/unresolved ancestor, not a98.60% exclusive hotspot. The8192-byte DWARF stack captures and large optimized frames limit parent recovery. Therefore1.12% BP derivation and4.13% raw enumeration are **not** rigorous Amdahl upper bounds: some descendants may have lost those ancestors. There is no TID→job map, so these are pooled shares and cannot be assigned separately to live/PB. No new timing gate, policy adoption or unique bit64 causality is claimed.

`REPORT.json` binds source, data, exact commands' reports/annotations and limitations. Based on actual exclusive samples, hashing, plan application, payer work and putback/card-state work deserve examination before a charged-cache redesign. The tiny Mode1 positive-presence bookkeeping optimization remains source-plausible but unmotivated as the principal performance repair by this sample.
