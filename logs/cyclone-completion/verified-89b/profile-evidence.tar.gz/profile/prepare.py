#!/usr/bin/env python3
"""Preparation only: exact first16 matched identities from the completed quiet855."""
from pathlib import Path
import json,hashlib,copy,shutil
ROOT=Path(__file__).resolve().parent
OLD=Path('/workspaces/MagicDeckTester/build/scratch/cyclone-finish/v7-905-lean/prepared-89b146d-final')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def write(name,x):
 with (ROOT/name).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
manifest=load(OLD/'cost_gate_arms.json');cost=load(OLD/'stage-plans.json')['cost'];seal=load(OLD/'seal.json');context=load(OLD/'context.json');status=load(OLD/'runs/cost/status.json')
assert status['status']=='DONE'and status.get('returncode',status.get('rc',0))==0
jobs=[];mapping=[];bindings={}
for f in [OLD/'cost_gate_arms.json',OLD/'stage-plans.json',OLD/'seal.json',OLD/'context.json',OLD/'runs/cost/status.json']:
 bindings[str(f)]=sha(f)
for arm,prefix in [('live','cyclone_live_play_s2002'),('pb','cyclone_pb_on_play_s2002')]:
 candidates=[]
 for original in manifest['jobs']:
  if not original['name'].startswith(prefix+'_off'):continue
  for offset in range(original['games']):
   gi=original.get('game_index',0)+offset
   candidates.append((gi,original['seed']+offset,original))
 candidates.sort(key=lambda t:t[0]);assert [v[0]for v in candidates]==list(range(20))
 for gi,seed,original in candidates[:16]:
  job=copy.deepcopy(original);job.update(name=f'profile89_{arm}_play_s2002_gi{gi:02d}',games=1,seed=seed,game_index=gi)
  assert job['budget_ms']==20 and'depth'not in job and'ignore_play_profile'not in job
  assert job['flags']==({}if arm=='live'else{'MTG_CYCLONE_PB_PLANS':True})
  expected={}
  for ext in ['wins','units']:
   f=OLD/'runs/cost/wins'/(original['name']+'.'+ext);bindings[str(f)]=sha(f)
   rows={int(line.split()[0]):line for line in f.read_text().splitlines()if line.strip()};expected[ext]=rows[gi]
  jobs.append(job);mapping.append({'job':job['name'],'arm':arm,'original_job':original,'original_gi':gi,'actual_seed':seed,'normalization_only':['name','games=1','seed=originalseed+localoffset','game_index=globalGI'],'expected':expected})
assert len(jobs)==32
for gi in range(16):
 a=next(j for j in jobs if j['name']==f'profile89_live_play_s2002_gi{gi:02d}');b=next(j for j in jobs if j['name']==f'profile89_pb_play_s2002_gi{gi:02d}');assert {k:v for k,v in a.items()if k not in['name','flags']}=={k:v for k,v in b.items()if k not in['name','flags']}
write('manifest.json',{'jobs':jobs});write('selection.json',{'selection':'FIRST16_GLOBAL_GI_ASCENDING_NO_OUTCOME_FILTER','logical_cell':'searched play_s2002','gi':list(range(16)),'actual_seeds':list(range(2002,2018)),'arms':['live shipping defaults flags{}','PB same defaults plus original perjob MTG_CYCLONE_PB_PLANS=true'],'mappings':mapping})
cwd=Path(cost['cwd']);deckroot=cwd/'decks/Unpredictable Cyclone';assets={str(p.relative_to(cwd)):sha(p)for p in deckroot.iterdir()if p.is_file()};assets['src/cards/data/cards.json']=sha(cwd/'src/cards/data/cards.json')
assert {p.name for p in deckroot.iterdir()if p.is_file()}==set(context['apparatus']['Unpredictable Cyclone'])
for name,h in context['apparatus']['Unpredictable Cyclone'].items():assert assets['decks/Unpredictable Cyclone/'+name]==h
perf=Path(shutil.which('perf')).resolve()
plan={'status':'PREPARED_NOT_LAUNCHED_ROOT_RUN_ONLY','source_tree':seal['source_tree'],'binary':seal['binary'],'binary_sha256':seal['binary_sha256'],'cwd':str(cwd),'threads':32,'manifest':str(ROOT/'manifest.json'),'manifest_sha256':sha(ROOT/'manifest.json'),'selection':str(ROOT/'selection.json'),'selection_sha256':sha(ROOT/'selection.json'),'games':32,'environment':cost['env'],'environment_contract':'Clear every inherited MTG_* then install exact original cost environment. Other inherited env retained and recorded, matching the actual cost runner. No new engine diagnostics/flags or fullJSON logging.','perf':str(perf),'perf_sha256':sha(perf),'perf_record_options':['record','-e','cycles:u','-F49','--call-graph','dwarf,8192'],'assets':assets,'deck_file_set':sorted(p.name for p in deckroot.iterdir()if p.is_file()),'original_bindings':bindings,'scope':'Attribution only. One mixed-arm32workerqueue. No separate live/PB perf-share or wall-gate claim without a valid per-TID job map; BatchRunner does not emit one. Verify all32 wins/digests/units reproduce quiet855. No policy adoption or extra-stage launches.'}
assert plan['source_tree']=='89b146d10406063213d9abe41e1cfdf1a616c021'and plan['binary_sha256']=='20de8d519c6c7c8494925d5170ff91ed06f5b4fcde4fd1bc04d1325113bb5e80'
write('plan.json',plan)
print(json.dumps({'jobs':32,'selection_sha256':plan['selection_sha256'],'manifest_sha256':plan['manifest_sha256']}))
