#!/usr/bin/env python3
"""Root launch only. One frozen PGO/perf pool; no build, timeout, overwrite or policy change."""
import argparse
from datetime import datetime, timezone
import hashlib,json,os,re,signal,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def need(v,msg):
 if not v:raise RuntimeError(msg)
def save(p,x):
 with Path(p).open('x')as f:json.dump(x,f,indent=2);f.write('\n')
def now():return datetime.now(timezone.utc).isoformat()

def guard():
 seal=load(ROOT/'packet-seal.json')
 for name,h in seal['files'].items():need(sha(ROOT/name)==h,'packet changed: '+name)
 p=load(ROOT/'plan.json');jobs=load(p['manifest'])['jobs'];selection=load(p['selection'])
 need(p['threads']==32 and p['games']==32 and len(jobs)==32,'count/worker mismatch')
 need(p['environment']=={'MTG_PGO':'1','MTG_DUMP_UNITS':'1','MTG_SLOW_GAME_MS':'1'},'cost env changed')
 need(sha(p['manifest'])==p['manifest_sha256']and sha(p['selection'])==p['selection_sha256'],'manifest/selection mismatch')
 need(p['perf_record_options']==['record','-e','cycles:u','-F49','--call-graph','dwarf,8192'],'perf protocol changed')
 need(sha(p['perf'])==p['perf_sha256'],'perf executable changed')
 need(sha(p['binary'])==p['binary_sha256'],'PGO bytes changed')
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'};cwd=Path(p['cwd'])
 src=subprocess.check_output(['git','-C',str(cwd),'rev-parse','HEAD:src'],env=env,text=True).strip()
 dirty=subprocess.check_output(['git','-C',str(cwd),'status','--porcelain','--untracked-files=no','--','src'],env=env,text=True)
 need(src==p['source_tree']and not dirty.strip(),'source changed/dirty')
 need((Path(p['binary']).parent/'SRC_TREE').read_text().strip()==src,'PGO source stamp stale')
 need(sorted(x.name for x in(cwd/'decks/Unpredictable Cyclone').iterdir()if x.is_file())==p['deck_file_set'],'runtime sidecar set changed')
 for rel,h in p['assets'].items():need(sha(cwd/rel)==h,'runtime asset changed: '+rel)
 for f,h in p['original_bindings'].items():need(sha(f)==h,'original evidence changed: '+f)
 need(len({j['name']for j in jobs})==32,'duplicate job name')
 for j,m in zip(jobs,selection['mappings']):
  need(j['name']==m['job']and j['games']==1 and j['seed']==2002+j['game_index'],'singleton normalization drift')
  expect=dict(m['original_job']);expect.update(name=m['job'],games=1,seed=m['actual_seed'],game_index=m['original_gi'])
  need(j==expect,'policy field changed for '+j['name'])
  need(j['flags']==({}if m['arm']=='live'else{'MTG_CYCLONE_PB_PLANS':True}),'arm flags drift')
 for arm in['live','pb']:need([m['original_gi']for m in selection['mappings']if m['arm']==arm]==list(range(16)),'not first16')
 return p,jobs,selection

def main():
 ap=argparse.ArgumentParser(description=__doc__);g=ap.add_mutually_exclusive_group(required=True);g.add_argument('--check',action='store_true');g.add_argument('--run',action='store_true');a=ap.parse_args()
 p,jobs,selection=guard()
 if a.check:print('PASS 16matchedidentities/32singletonjobs/one32workerqueue; exact quietcost fields/env/source/PGO/assets; no engine');return
 out=ROOT/'runs';out.mkdir(exist_ok=False);(out/'wins').mkdir()
 engine=[p['binary'],'--batch',p['manifest'],'--threads','32','--game-log-dir',str(out/'wins')]
 argv=[p['perf'],*p['perf_record_options'],'-o',str(out/'perf.data'),'--',*engine]
 env=dict(os.environ);cleared=sorted(k for k in env if k.startswith('MTG_'))
 for k in cleared:env.pop(k)
 env.update(p['environment']);env['GIT_OPTIONAL_LOCKS']='0'
 record={'status':'STARTED','started':now(),'owner_pid':os.getpid(),'source_tree':p['source_tree'],'binary_sha256':p['binary_sha256'],'plan_sha256':sha(ROOT/'plan.json'),'runner_sha256':sha(__file__),'packet_seal_sha256':sha(ROOT/'packet-seal.json'),'argv':argv,'engine_argv':engine,'cwd':p['cwd'],'threads':32,'cleared_inherited_MTG_names':cleared,'actual_MTG_environment':{k:v for k,v in env.items()if k.startswith('MTG_')},'other_execution_environment':{k:env.get(k)for k in['OMP_NUM_THREADS','OMP_THREAD_LIMIT','LD_PRELOAD','LD_LIBRARY_PATH','MALLOC_ARENA_MAX']},'cpu_affinity':sorted(os.sched_getaffinity(0)),'scope':p['scope']}
 save(out/'STARTED.json',record);save(out/'argv.json',argv);save(out/'environment.json',record['actual_MTG_environment'])
 child=None
 def forward(sig,frame):
  if child is not None and child.poll()is None:os.killpg(child.pid,sig)
 signal.signal(signal.SIGINT,forward);signal.signal(signal.SIGTERM,forward)
 try:
  with(out/'batch.log').open('xb')as stdout,(out/'batch.err').open('xb')as stderr:
   child=subprocess.Popen(argv,cwd=p['cwd'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   save(out/'PERF-PID.json',{'pid':child.pid,'at':now()});rc=child.wait()
  need(rc==0,'perf/engine returned '+str(rc));need((out/'perf.data').stat().st_size>0,'missing/empty perf.data');guard()
  rows=[]
  for j,m in zip(jobs,selection['mappings']):
   got={};hashes={}
   for ext in['wins','units']:
    f=out/'wins'/(j['name']+'.'+ext);lines=f.read_text().splitlines();need(len(lines)==1,'wrong rowcount '+str(f));got[ext]=lines[0];hashes[ext]=sha(f)
   need(re.fullmatch(r'\d+ -?\d+ [0-9a-f]{16}',got['wins'])and re.fullmatch(r'\d+ \d+',got['units']),'bad result schema')
   need(int(got['wins'].split()[0])==j['game_index']and int(got['units'].split()[0])==j['game_index'],'wrong globalGI')
   rows.append({'job':j['name'],'arm':m['arm'],'seed':j['seed'],'gi':j['game_index'],'actual':got,'expected':m['expected'],'exact':got==m['expected'],'sha256':hashes})
  matched=all(x['exact']for x in rows)
  receipt={**record,'status':'DONE_EXACT_REPRODUCTION'if matched else'DONE_REPRODUCTION_MISMATCH','ended':now(),'returncode':rc,'results':rows,'all32_win_digest_units_exact_to_quiet855':matched,'perf_data':{'path':str(out/'perf.data'),'bytes':(out/'perf.data').stat().st_size,'sha256':sha(out/'perf.data')},'batch_log_sha256':sha(out/'batch.log'),'batch_err_sha256':sha(out/'batch.err'),'attention_lines':[s for s in(out/'batch.err').read_text(errors='replace').splitlines()if re.search(r'fd-diverge|FORECAST DISAGREEMENT|NONCONV|MISMATCH|overflow',s,re.I)],'note':'Original cost env has no FD/nonconv diagnostic oracles enabled. Their absence is not a fidelity proof. Perf stack samples are pooled across live/PB; no wall comparison/adoption gate claim.'}
  save(out/'DONE.json',receipt);print(json.dumps({'status':receipt['status'],'games':32,'all_exact':matched,'perf_bytes':receipt['perf_data']['bytes']}))
  if not matched:raise SystemExit(1)
 except Exception as exc:
  save(out/'FAILED.json',{**record,'status':'FAILED','ended':now(),'error':str(exc),'perf_returncode':None if child is None else child.poll(),'raw_preserved':True});raise
if __name__=='__main__':main()
