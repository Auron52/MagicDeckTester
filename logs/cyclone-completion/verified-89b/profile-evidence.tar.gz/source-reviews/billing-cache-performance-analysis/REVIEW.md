# Billing/cache performance review — source 89b

The general cache needs bit64. Existing free-entry metadata cannot supply the bill it would have incurred inside `CanonWaveBillScope`. A narrowly certified enumeration-only cache is worth investigating; changing to general charged-cache mode2 or deleting the context bit is not supported.

This review reads existing artifacts and source only. It runs no engine/model/build and changes no source or runtime inputs. `analysis.json` binds the raw metrics, paths and hashes.

| Quiet cell | Games | ms/game | units/game | ms/unit |
|---|---:|---:|---:|---:|
| Hinata d5 s3003 | 150 | 2040.213 | 72,656 | .028080 |
| Cyclone live play s2002 | 20 | 27923.650 | 2,051,891.15 | .013609 |
| Cyclone PB play s2002 | 20 | 7176.500 | 435,257.35 | .016488 |
| Cyclone PB+keep play s2002 | 20 | 7243.300 | 441,168.60 | .016418 |

The live wall ratio is 13.687 but its unit ratio is 28.241. PB's ratios are 3.518 and 5.991. Cyclone's per-unit throughput is better than Hinata's in this run; these aggregates establish excess work volume, not a cache bottleneck. Quiet stderr has per-game duration/units but no cache/refusal census. Its live worst is seed2009/GI7 (126232ms, 8558345 units); PB worst is seed2011/GI9 (30920ms, 1677110 units).

The separate same-source memory1 corpus reports 3,486,878 cache computations, 2,297 charging computations, 16,890 unstorable computations, 22,478,770 free hits, and zero pool refusals. It is a different 158-game instrumented corpus. Neither these counts nor quiet aggregate ratios establish how much quiet855 work bit64 causes.

## What the source establishes

- `TurnSolver.cpp:30009–30024`: canon billing arms only for positive weight/finite budget; nested scopes inherit or replace the billed budget and restore it on exit. All reads of `g_cw_bill_budget` outside context construction are the scope and `EnumChargeScope` destructor.
- `69496–69515,70156,71001`: one enumeration increments `visits` on each selected-combination evaluation, then bills **at its function exit**. General enum charging takes precedence; otherwise canon billing uses `ceil(visits/W)`. A single isolated walk does not test this private visits count as a budget while walking.
- **That does not prove the full cacheable derivation pure.** It invokes providers and candidate trial applications, may re-enter derivation, and can run budget-sensitive sub-searches. Equip route `DecisionProviders.cpp:42629+` explicitly marks that its existence, work and answer depend on decision budget/context and per-decision memo warmth; AA route is similarly marked at49724. Direct decision-meter charges and weighted residuals are also observable. The derivation's meter/backstop can interrupt it (`71009–71033`, `106085–106096`). Nested exit charges can therefore precede later semantic work.
- `86482–86488` plus86620/86859/105950/107441 separate this active billing context at m1/m2/BP/canon-front lookup. These keys must stay intact for the general case.
- `4040–4045,4125–4127`: default `cachecharge::Mode()==1` declines **every computation with any billed units**, not merely truncated ones. Thus a positive-visit billed derivation normally cannot populate its armed-context cache entry; identical billed keys may re-enumerate. This is a structural opportunity, not a measured hotspot.
- The other guards remain load bearing: unknown budget targets, exhaustion, fractional residual changes, direct meter changes, interruption/AA cuts, and side-counter replay. Mode2 was measured wrong for a warm provider sub-search; no general switch is recommended.
- Existing cost capture knows actual consumed units, not uncharged hypothetical visits. An unarmed entry's zero cost cannot be reinterpreted as its future armed bill. Generic hit replay also uses `kCacheHit` (`4152–4167`), whereas an enumeration-only optimization must preserve `kEnumCharge` if exact per-site counts are required.

## Concrete optimization route

First investigate **same-context, pure exit-only enumeration reuse**, retaining64. Capture a small immutable enum-price record (per completed walk's rounded units, not only aggregate raw visits), separately from general sub-search costs. A candidate must exclude provider sub-searches, direct meter/residual changes, non-enum charges, unknown targets, interrupted/cut computations and nested charge-before-later-work cases. A particularly narrow first target is one leaf walk with its sole charge at the final semantic exit; static review must verify the wrapper's later postprocessing does not read a changed budget. Merely seeing `c.dec == enum_units` is insufficient to certify that property.

On a proven eligible hit, replay the same enum charge at the same logical return boundary and target budget, with the existing side-counter semantics. Admit only where the replay cannot cross an applicable decision/pass/game bound; otherwise recompute. Sum **per-walk ceilings**: `ceil(v1/W)+ceil(v2/W)` need not equal `ceil((v1+v2)/W)`. Do not reuse a full entry for a front-only derivation unless their prices are also proven identical under the new capture class. Front-only mode skips clone expansion; raw subset work and nested callback work need separate accounting.

Cross-free/billed reuse is a later, stronger version of the same certificate: record counterfactual enum price even during free computation, prove all generated plans and semantic side effects independent of that billing context, and reject when charging could affect intermediate work. The current source and recorded `Cost` do not prove this for all derivations. Do not toggle the key bit to obtain that experiment.

There is also a tiny source-safe accounting optimization independent of memo eligibility: in default mode1, refused-entry charge totals are only tested for zero/positive. `CacheChargeNote` can saturate each **budget class** (decision/greedy/other) at positive presence and stop traversing enclosing records when that same class is already marked. A prior propagation marked every enclosing record, so the break preserves that invariant. Mode2 must keep exact totals, and `Done()` must still call the same `Exhausted()` tests to preserve bind counters. This reduces bookkeeping only; its benefit is unmeasured and likely much smaller than avoiding a costly derivation. It is not presented as the fix for a13.69x gate.

## Minimal next measurement and proof

Use the exact original live2009/GI7 and PB2011/GI9 d5b20 jobs, preserving profiles/flags/apparatus. Existing `MTG_PLAN_POOL_STATS`, `MTG_BP_DERIVE_STATS`, `MTG_BP_DERIVE_SLOW_MS`, `MTG_ENUM_STATS` and a **single-worker diagnostic** turn census can identify list sizes, repeated full keys, refused stores and charged work. Keep this instrumentation outside quiet timing. CPU sampling can distinguish raw enumeration, axis materialization, payer/application and copying.

Existing `seen_full` versus `seen_raw` does **not** isolate64: raw omits every physical/exact fold. If additional observational counters are authorized, split armed/unarmed derivations and store-refusal reasons, count nested enum callbacks/price events, and compare exact keys differing **only** in64. Add no policy flag or quota. If costly repeated eligible keys are not observed, do not prioritize this cache route on the basis of the context-bit hypothesis.

Any new memo class needs actual hot/cold/free/billed negative controls, near-budget/exhaustion and nested-provider/warm-memo counterexamples, full plan-order/physical trace/wins/digest/total-unit/per-site/side-counter equality, and existing billing regression coverage. The prior seed123021 single-worker repair proof is separate; pooled three-slower census remains unsuitable for per-decision attribution. None of these proposed probes was launched in this review.
