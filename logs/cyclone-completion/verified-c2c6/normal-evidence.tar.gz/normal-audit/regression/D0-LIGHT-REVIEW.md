# d0 regression sanity review

All 94 changed rows were inspected numerically: seven slower, five faster and 82 same-score digest changes, net +4 loss-penalized turns. Anti-Lifegain has 17 changes and net +6; Snow has 11 and net −2; Fluctuator’s 12 and PD’s 54 are all score ties. The seven slower cases are not hidden by the aggregate or called neutral.

A physical current-line sample is available without a new engine call: Anti-Lifegain GI373/seed2375 d0 has exactly the same T7 and decision-stream digest as the completed current searched control. That trace has legal fetch/life accounting and a legal T7 finish: Tainted Remedy, Fiery Justice (5 damage plus replacement of its 5-life gain), then Reverent Silence’s alternate-cost gain6 replacement. Opponent life15→5→−1, own life5. The alternate cost is paid while Remedy is still present; the later destroy-enchantments effect does not undo that loss. The T6 fetch attempt sacrifices its land without finding a replacement, consistent with the mandatory shuffle path now implemented.

This is a same-result/decision-stream physical witness, not a claim that d0 and d5 policy settings are identical. No direct new d0 trace was run. The old d0 loss’s exact cause is not isolated. Prior d0 family sanity reviews remain documented, but their different seed identities are not relabelled as new regression controls.

This meets the lighter numerical/source/representative-line scope for d0; it is not 94 isolated causal proofs. All exact old/new rows, the seven slower transitions and sample hash/context limits are in d0-light-review.json. No engine, source or GT change was made.
