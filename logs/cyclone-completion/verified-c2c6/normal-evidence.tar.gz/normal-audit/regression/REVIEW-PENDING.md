# Full regression review — exact controls pending

253jobs request72,414games;72,413wins rows were recorded. Both current and accepted GT omit Melira backstopGI11 under the positive2M-unit ceiling. Current raw structured abandonment is explicit; no old-side diagnostic was invented. All253 aggregate folds match their corresponding raw rows.

Changed127games: searched1slower,2faster,30ties (net−1totalturn);d0 7slower,5faster,82ties (net+4totalturns). Every changed row is in audit.json and causal-review-pending.json. Same-score legality/first-divergence review remains pending the root-selected exact paired controls for all33searched changes. No fullregV5run exists for automatic carry. No GT acceptance verdict is implied by net scores.

Sole slower: FiveColour seed3146/GI143, actualshippedd7/b40,5→6. Old6ac6585fca37f3e6/newae08ebc53368a4a6. The old diagnostic replay forcedd5/ignoreprofile and itsT5 is invalid as an exactsetting recovery. The helper is now fixed/tested. Exactoriginal-context first-repro is prepared; b160/b640/d8b0 remain UNSELECTED unless root chooses them.

Ordinary leafnoneFD3:Niv3095/GI92,realized6/predicted5/provenT4;TH3460/GI457,7/5/provenT2;EDF2073/GI71,6/5/provenT2. Allblind_salt−1. NONCONV0,overflow0. None is declared pre-existing from realizedGT equality. Root is building exactupstream2c source520d6… for controls.

## All searched changed cases

| Job | GI | Actual depth | Score | Kind | Pre-fix explain matches depth? |
|---|---:|---:|---|---|---|
| antilife_regression_d5_s2002 | 373 | 5 | 7→7 | same_score_play_change | yes |
| goblins_regression_d3_s2002 | 57 | 3 | 3→3 | same_score_play_change | yes |
| mirrorwing_regression_d5_s2002 | 63 | 6 | 5→5 | same_score_play_change | NO |
| fivecolour_regression_d5_s3003 | 143 | 7 | 5→6 | slower | NO |
| kittyv3_regression_d5_s2002 | 99 | 5 | 5→5 | same_score_play_change | yes |
| melira_regression_d5_s3003 | 52 | 5 | 4→4 | same_score_play_change | yes |
| melira_regression_d5_s3003 | 139 | 5 | 4→4 | same_score_play_change | yes |
| fluctuator_regression_d5_s3003 | 35 | 6 | 4→4 | same_score_play_change | NO |
| selesnyav2_regression_d3_s2002 | 3 | 3 | 5→5 | same_score_play_change | yes |
| selesnyav2_regression_d5_s2002 | 3 | 6 | 5→5 | same_score_play_change | NO |
| selesnyav2_regression_d5_s3003 | 55 | 6 | 5→5 | same_score_play_change | NO |
| selesnyav2_regression_d5_s3003 | 115 | 6 | 5→5 | same_score_play_change | NO |
| selesnyav22hg_regression_d5_s2002 | 3 | 6 | 6→6 | same_score_play_change | NO |
| selesnyav22hg_regression_d5_s2002 | 86 | 6 | 7→7 | same_score_play_change | NO |
| selesnyav22hg_regression_d5_s2002 | 97 | 6 | 5→5 | same_score_play_change | NO |
| edf_regression_d5_s2002 | 70 | 5 | 4→4 | same_score_play_change | yes |
| edf_regression_d5_s2002 | 123 | 5 | 5→5 | same_score_play_change | yes |
| snow_regression_d3_s2002 | 3 | 3 | 6→6 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 3 | 5 | 6→6 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 26 | 5 | 6→6 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 31 | 5 | 7→7 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 47 | 5 | 7→6 | faster | yes |
| snow_regression_d5_s2002 | 76 | 5 | 6→6 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 101 | 5 | 8→8 | same_score_play_change | yes |
| snow_regression_d5_s2002 | 141 | 5 | 5→5 | same_score_play_change | yes |
| snow_regression_d5_s3003 | 5 | 5 | 5→5 | same_score_play_change | yes |
| snow_regression_d5_s3003 | 51 | 5 | 6→6 | same_score_play_change | yes |
| snow_regression_d5_s3003 | 70 | 5 | 7→7 | same_score_play_change | yes |
| snow_regression_d5_s3003 | 111 | 5 | 7→6 | faster | yes |
| vampires2hg_regression_d5_s2002 | 40 | 6 | 7→7 | same_score_play_change | NO |
| alchemist_regression_d5_s3003 | 86 | 5 | -1→-1 | same_score_play_change | yes |
| alchemist_regression_d5_s3003 | 153 | 5 | 8→8 | same_score_play_change | yes |
| elementals_regression_d3_s2002 | 22 | 3 | 5→5 | same_score_play_change | yes |
