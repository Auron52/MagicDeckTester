# Landing2c76 smoke per-game review — closed

Verdict: recommend normal smoke acceptance after root’s remaining final gates. No GT was changed.

Pinned baseline `2c76c854e7ce593f129c0aced8f6854339dd00c2`, source `c2c6d4a03a5c1df9cf72c55bd29940aacff41efc`, PGO `962bc5a514a3128b6a141bfdc1d2f3b21353ea8fd11572cb4d2fd6055249788d`.

157 jobs /51,675games;150PASS/7FAIL/0NEW;390scenariosPASS. ALL81 changed old/new tuples and ALL7affected result files exactly match the previously reviewed V5 smoke. Twenty-six relevant asset files and all used main-card definitions for the5affected deck families exactly match their prior committed versions. No hidden searched score cancellation: searched0slower/0faster/9same-score changes; d0 2slower/3faster/67same-score changes, net−1total loss-penalized turn.

## All nine searched changes

| Job | GI | Turn | Old digest | New digest | Review |
|---|---:|---:|---|---|---|
| goblins2hg_smoke_d5_s1001 | 41 | 3 | `2a713f15d6191818` | `ece28b437b33e2a2` | Exact historical legal T3 alternate line |
| snow_smoke_d3_s1001 | 18 | 6 | `8170b29c29dc230d` | `e74b4f48c42700e0` | Exact historical independent upstream-control result |
| snow_smoke_d3_s1001 | 20 | 6 | `bf6629b96c50d8e7` | `3b71cba64e2159f5` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 18 | 6 | `8170b29c29dc230d` | `e74b4f48c42700e0` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 20 | 6 | `bf6629b96c50d8e7` | `3b71cba64e2159f5` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 39 | 7 | `e11b1052aaab004a` | `f880d19ca8516222` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 41 | 6 | `30caedd106a60183` | `2cab947ee8e305b1` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 94 | 7 | `136ec3dfa83b0ffd` | `311a38a66251c4a9` | Exact historical independent upstream-control result |
| snow_smoke_d5_s1001 | 111 | 7 | `57356a69b3f30f88` | `f3396359deb800d2` | Exact historical independent upstream-control result |

GoblinsGI41: current T2Piledriver preserves both Lackeys, then T3Stingscourger. Six eligible old attackers deal30against29life; newly cast Stingscourger does not attack but legally adds to Muxus’s Goblin count. The old line sacrifices both Lackeys to pay PiledriverT2, declines Stingscourger echo and casts hasty ChieftainT3 for29damage. Both original expected rows were previously reproduced in exact paired controls. The current harness’s new T1–T3 line agrees. This proves a legal alternative selected line, not an isolated source/flag cause. Paired physical proof remains at `v5-current-review/goblins-gi41-pair/{VERDICT.md,human-review.json,runs/}`.

Snow d3GI18/20 and d5GI18/20/39/41/94/111: each current exact win/digest equals the independent historical current-main control, as do all7Snow d0 changes. Representative GI18d3,GI39d5 andGI41d0 main/integrated physical JSON traces were identical; trace-on/off controls agree. All relevant definitions and apparatus are unchanged. Current harness lines were read for all8searched cases; no new score or fingerprint behavior appears. The earlier upstream change causing the GT drift remains unisolated; do not invent one. Full evidence remains `smoke-audit/verdict.md`, `snow-all/wins/` and `main/int` traces.

## All72 d0 changes

AntiLifegain7,Fluctuator9,PD49,Snow7: every exact old/new row and full result file is already in prior reviewed evidence. AntiLifegain GI944T7→loss and Fluctuator GI295T6→8 are the2slower cases; the3faster cases offset them with net−1total turn across d0. Historical exact raw sanity traces cover AntiGI944,FluctuatorGI295,PDGI19; Snow has independent controls for all7. This meets the lighter d0 review scope; no common isolated cause is claimed for the other45PD fingerprint changes.

## Raw diagnostics and collector correction

Raw stderr172lines contains EXACTLY1ordinary `[fd-diverge]`: Niv seed1082/GI81,actual6/predicted5,provenT1,leaf_estnone,blind_salt−1. It matches the previously demonstrated pre-existing Niv warning. NONCONV0,CounterList overflow0; all other stderr prefixes were inspected as profile/play configuration, slow-game or cache diagnostics. The uncompressed MidrangeBurn profile warning is advisory, with its result exactly matching current2c76GT. This is NOT a zero-FD run.

The first collector report missed `[fd-diverge]` because its regex handled only other FD forms. That immutable v1report is retained. The corrected helper/test explicitly handles the actual enriched FD and NONCONV records; fresh `smoke-v2/audit.json` reportsFD1/NONCONV0. `REVIEW-RECEIPT.json` hashes both reports and asserts exact unchanged raw hashes, cases and changed rows. No raw log, outcome, digest or GT was edited.

No unresolved smoke per-game trace roster remains. Regression/reference/parity closure and the overall landing decision stay with root; optional-policy adoption and generation are separate.
