# Landing905 three-game compiler/fulltrace preflight

Prepared only; no engine/build ran. Source:
`c2c6d4a03a5c1df9cf72c55bd29940aacff41efc`.
Actual current Release SHA256:
`bc1b4af3c693dc6dfbe644191f0667b928379b8b0f6e6bc9e291b3d7ebaf49bd`.
PGO SHA is deliberately absent until root supplies the completed binary.

Exact old three identities are preserved: seed107008/GI8 d3b10 ordinary;
seed127012/GI12 d3b10 leaf0 with its original package; seed131117/GI117
d3b10 with its original package. No flags/profile settings changed. Deck and
ordinary profile paths rebind to Landing905; leaf0 remains the byte-frozen
V5 profile. All lexical sibling filename presence/bytes in both directories,
current cards.json, manifest and preflight script are guarded. Release lacks
a SRC_TREE file, so its actual hash is pinned now following root's reported
completed canonical build; PGO additionally requires matching SRC_TREE.

Root commands after PGO completes:

```bash
PREFLIGHT=/workspaces/MagicDeckTester/build/scratch/cyclone-finish/landing905-review/preflight
python3 "$PREFLIGHT/preflight.py"
python3 "$PREFLIGHT/preflight.py" --seal-pgo-sha256 ACTUAL_64_HEX_PGO_SHA256
python3 "$PREFLIGHT/preflight.py" --run
python3 "$PREFLIGHT/preflight.py" --check
```

Seal is exclusive and launches nothing. Run creates exclusive `runs/`, then
Release and PGO serially with1 worker each, full game traces and no timeout.
Every inherited MTG_/VPC_ setting is removed; only DUMP_UNITS, FD_ORACLE and
FLAG_NONCONV are enabled. Any FD/NONCONV or nonzero process exit stops before
the next compiler. Source, assets and binary/input hashes are checked before
and after each process. Documentation-only HEAD advances are descriptive.

Strict checker requires both compiler closures, all3 job summaries, exact
3-game footer, correct GI and single win/unit rows. It compares wins/digests,
units and the entire parsed trace, excluding only top-level deckId/runId
container identifiers. All physical/zone/action/choice fields remain. It
preserves historical sanity turns4/5/4 as a separate check; a legitimate
source-driven difference needs review rather than forcing old rows or
classifying it automatically as a compiler failure. Raw hashes/provenance
remain in runs/provenance.json and review.json. No old138 result is carried.

## Strict viewer is already wired into normal regression

Landing905 test/regression.sh lines505–535 invokes:

```bash
MTG_BIN="$BIN" python3 test/viewer_protocol_check.py --strict --threads "$THREADS"
```

`BIN` is the same snapshot binary used for the preceding deck batch. It runs
after the batch in **regression mode only** (or VPC_ALWAYS=1); VPC_SKIP=1
disables it. Full recursive reference selection is inside the checker;
no `--only` or sample filter is passed. Strict gates contract failure,
play-drift and ENUM-GAP with the checker's established accepted classes.
The next regression stage also runs suboptimal `ref_bench --require-beat`.

Therefore root's ordinary full regression with THREADS=32 and VPC_SKIP=0
already supplies the fresh full strict sweep on this source. Preserve its
complete summary plus actual harness/checker verdict; do not launch a
duplicate standalone full strict wave. Smoke and overnight alone skip this
gate and cannot supply that evidence. Frontend checks remain standalone and
are not provided by this engine protocol gate. These are static wiring
findings, not a claim that the upcoming regression or strict sweep passed.
