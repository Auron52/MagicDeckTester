# Last 16 searched regression cases — closed

These are zero-based searched-change indices 17–32. Both native-source controls completed successfully: current source C2/PGO962 and exact upstream2c source520d6. Every current row reproduces the normal regression result. Seed, global GI, opening hand, mulligans and raw trace hashes were checked. No engine or GT changes were made.

All twelve Snow cases have identical entire physical JSON between baseline and current, including the two apparent faster cases. They are upstream-versus-GT drift. Four remaining cases are legal alternatives with unchanged scores.

| Index | Job | GI | Classification |
|---:|---|---:|---|
| 17 | snow_regression_d3_s2002 | 3 | Exact upstream control; full JSON equal |
| 18 | snow_regression_d5_s2002 | 3 | Exact upstream control; full JSON equal |
| 19 | snow_regression_d5_s2002 | 26 | Exact upstream control; full JSON equal |
| 20 | snow_regression_d5_s2002 | 31 | Exact upstream control; full JSON equal |
| 21 | snow_regression_d5_s2002 | 47 | Exact upstream control; full JSON equal |
| 22 | snow_regression_d5_s2002 | 76 | Exact upstream control; full JSON equal |
| 23 | snow_regression_d5_s2002 | 101 | Exact upstream control; full JSON equal |
| 24 | snow_regression_d5_s2002 | 141 | Exact upstream control; full JSON equal |
| 25 | snow_regression_d5_s3003 | 5 | Exact upstream control; full JSON equal |
| 26 | snow_regression_d5_s3003 | 51 | Exact upstream control; full JSON equal |
| 27 | snow_regression_d5_s3003 | 70 | Exact upstream control; full JSON equal |
| 28 | snow_regression_d5_s3003 | 111 | Exact upstream control; full JSON equal |
| 29 | vampires2hg_regression_d5_s2002 | 40 | Legal alternate line; same score |
| 30 | alchemist_regression_d5_s3003 | 86 | Legal alternate line; same score |
| 31 | alchemist_regression_d5_s3003 | 153 | Legal alternate line; same score |
| 32 | elementals_regression_d3_s2002 | 22 | Legal alternate line; same score |

Vampires GI40 first differs at T3: current plays a third Estate and Captain; baseline plays Vial and delays Captain to T4. The fresh Captain does not attack. Current Vial, cast T4, reaches one counter for Dire Moon at T5 and two for Bloodghast at T6. Both puts happen after combat. Socialite, Captain and its as-enters counter make Dire Moon a three-power lifelinker. Final damage is 3+2+3+4=12, against nine remaining life in current and twelve in baseline. Estate life payments and both three-life lifelink events match the trace. Both wins are legal T7 lines.

Alchemist GI86 has identical physical play through T6. Baseline casts Sprawl then Weather on T7; current delays Weather until T8 after Crab Umbra. Each Weather follows one cast, gains six life, and both traces end at own life36/opponent life5, unwon at T8. Attack damage respects the two Alchemists’ arrival turns.

Alchemist GI153 first differs at T3: baseline adds Living Wish for an Alchemist before Weather; current holds Wish until T5 and gets Brindle Boar. Current wins through the T8 mechanical combo route, not combat damage; the logger summarizes its nested plays. Four Forests with three Sprawls plus the new Forest can supply eight mana: Staff3 + Boar3 leaves two for Staff’s gain-one activation after sacrificing Boar for four life. At five life gained, the old Alchemist yields five; Staff’s creature untap3 plus self untap1 nets one per cycle, supporting the Stroke outlet. The physical after-state contains Staff, has Boar and the second Stroke in the graveyard, and records life31→36. The source’s copied-board trial and proven replay gate the committed route. Baseline instead reaches an Elf combat finish at T8. No shared payment sequence or isolated flag cause is claimed.

Elementals GI22 first differs at T3: Mountain versus Myriad Landscape. Both cast Soulstoke. Current plays Myriad T4, then T5 Soulstoke puts Hydra with haste before Myriad fetches two Mountains. The Hydra’s one entry counter doubles twice to four; Soulstoke adds one power, and two Harbingers contribute two each: 5+2+2=9, exactly lethal. Soulstoke and Smokebraider are tapped for activation/mana and are not counted as attackers. Fresh Hydra attacks legally because Soulstoke grants haste.

There is no unresolved case in this assigned last-16 scope. First17, FiveColour recovery and the three ordinary FD warnings remain owned separately by root/cost/payment reviewers. This report does not authorize overall regression acceptance. Full source, status and trace bindings are in review.json.
