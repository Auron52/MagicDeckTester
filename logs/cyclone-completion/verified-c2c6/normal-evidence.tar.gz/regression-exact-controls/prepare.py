#!/usr/bin/env python3
"""Prepare strict33 searched movers +3 FD identities; no engine, model or build."""
import copy,datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path('/workspaces/MagicDeckTester');HERE=Path(__file__).resolve().parent
CURRENT=ROOT/'.claude/worktrees/cyclone-landing905';BASE=ROOT/'.claude/worktrees/cyclone-upstream2c76'
C2='c2c6d4a03a5c1df9cf72c55bd29940aacff41efc';B2='520d6ef09669321b0ab80c3252a15f487a7db01c';COMMIT='2c76c854e7ce593f129c0aced8f6854339dd00c2'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def git(wt,*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(wt),*a],text=True).strip()
def single(j,seed,gi):
 x=copy.deepcopy(j);x.update(name=j['name']+'_exact_gi'+str(gi),games=1,seed=seed,game_index=gi);return x
def canonical(j):
 x=copy.deepcopy(j);x.pop('name',None);x.pop('weight',None);return json.dumps(x,sort_keys=True,separators=(',',':'))
def decknames(p):
 if p.suffix=='.cod':
  zones=ET.parse(p).getroot().findall('zone');return ({c.attrib['name'] for z in zones if z.attrib['name']=='main' for c in z.findall('card')},{c.attrib['name'] for z in zones if z.attrib['name']=='side' for c in z.findall('card')})
 return ({re.sub(r'^\d+x?\s+','',line.strip()) for line in p.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')},set())
def strings(x):
 if isinstance(x,str):yield x
 elif isinstance(x,dict):
  for v in x.values():yield from strings(v)
 elif isinstance(x,list):
  for v in x:yield from strings(v)
def main():
 auditpath=HERE.parent/'normal-audit/regression/audit.json';audit=read(auditpath);assert audit['source_tree']==C2 and audit['baseline_commit']==COMMIT
 rows=[r for r in audit['changed'] if r['band']=='searched'];assert len(rows)==33 and sum(r['score_delta']>0 for r in rows)==1 and sum(r['score_delta']<0 for r in rows)==2
 for label,wt,src in [('current',CURRENT,C2),('baseline',BASE,B2)]:assert git(wt,'rev-parse','HEAD:src')==src and not git(wt,'status','--porcelain','--untracked-files=no','--','src')
 fdpacket=HERE.parent/'fd-three-controls';fdcases=read(fdpacket/'cases.json');cases=[];lookup={}
 for r in rows:
  j=r['original_job'];seed=r['actual_seed'];gi=r['gi'];assert seed==j['seed']+gi-j.get('game_index',0)
  candidate=single(j,seed,gi);key=canonical(candidate);assert key not in lookup
  item=dict(control_job=candidate,original_job=j,source_job=j['name'],actual_seed=seed,global_gi=gi,reasons=['searched_'+r['kind']],GT_row=f"{gi} {r['old_turn']} {r['old_digest']}",current_regression_row=f"{gi} {r['new_turn']} {r['new_digest']}",original_audit_row=r)
  lookup[key]=item;cases.append(item)
 for r in fdcases:
  j=r['source_job'];candidate=single(j,r['actual_seed'],r['global_game_index']);key=canonical(candidate)
  if key in lookup:item=lookup[key];item['reasons'].append('ordinary_FD')
  else:
   item=dict(control_job=candidate,original_job=j,source_job=j['name'],actual_seed=r['actual_seed'],global_gi=r['global_game_index'],reasons=['ordinary_FD'],GT_row=r['baseline2c_GT_row'],current_regression_row=r['current_regression_row']);lookup[key]=item;cases.append(item)
  item['original_current_FD']=r['raw_current_FD'];item['original_current_units_row']=r['current_regression_units_row']
 assert len(cases)==36 and len({c['control_job']['name'] for c in cases})==36
 for c in cases:
  original=dict(c['original_job']);actual=dict(c['control_job']);actual.pop('name');original.pop('name');actual.update(games=original['games'],seed=original['seed'])
  if 'game_index' in original:actual['game_index']=original['game_index']
  else:actual.pop('game_index')
  assert actual==original
 write(HERE/'cases.json',cases)
 for arm in ('current','baseline'):write(HERE/(arm+'-manifest.json'),{'jobs':[c['control_job'] for c in cases]})
 registries={label:{c['name']:c for c in read(wt/'src/cards/data/cards.json')['cards']} for label,wt in [('current',CURRENT),('baseline',BASE)]};assets={label:{} for label in registries};bridges={}
 for rel in sorted({c['original_job']['deck'] for c in cases}):
  main,side=decknames(CURRENT/rel);reg=registries['current'];wish=any(any('wish' in k.lower() and bool(v) for k,v in reg[n].get('parameters',{}).items()) or 'outside the game' in reg[n].get('oracle_text','').lower() for n in main)
  closure=main|(side if wish else set());assert not closure-set(reg)
  while True:
   expanded=closure|{v for n in closure for v in strings(reg[n].get('parameters',{})) if v in reg}
   if expanded==closure:break
   closure=expanded
  carddiff=[];missing=[];prose=[];hashes=[]
  for name in sorted(closure):
   a=reg[name];b=registries['baseline'].get(name)
   if b is None:missing.append(name);continue
   ar={k:v for k,v in a.items() if k!='oracle_text'};br={k:v for k,v in b.items() if k!='oracle_text'}
   if ar!=br:carddiff.append(dict(name=name,changed_fields=[k for k in sorted(set(ar)|set(br)) if ar.get(k)!=br.get(k)],current=ar,baseline=br))
   elif a!=b:prose.append(name)
   hashes.append(dict(name=name,current_full_sha256=digest(a),baseline_full_sha256=digest(b),current_runtime_sha256=digest(ar),baseline_runtime_sha256=digest(br)))
  directory=Path(rel).parent;sets={label:{p.name for p in (wt/directory).iterdir() if p.is_file()} for label,wt in [('current',CURRENT),('baseline',BASE)]};filediff=[]
  for label,wt in [('current',CURRENT),('baseline',BASE)]:
   for name in sets[label]:p=wt/directory/name;assets[label][str(p)]=sha(p)
  for name in sorted(sets['current']|sets['baseline']):
   a=CURRENT/directory/name;b=BASE/directory/name
   if not a.exists() or not b.exists() or a.read_bytes()!=b.read_bytes():filediff.append(dict(relative_path=str(directory/name),current_sha256=sha(a) if a.exists() else None,baseline_sha256=sha(b) if b.exists() else None))
  bridges[rel]=dict(main=sorted(main),side=sorted(side),side_reachable=wish,closure=sorted(closure),runtime_card_differences=carddiff,missing_baseline_definitions=missing,prose_only_card_differences=prose,card_hashes=hashes,native_directory_filenames={k:sorted(v) for k,v in sets.items()},deck_profile_model_differences=filediff)
 for label,wt in [('current',CURRENT),('baseline',BASE)]:assets[label][str(wt/'src/cards/data/cards.json')]=sha(wt/'src/cards/data/cards.json')
 bridge=dict(current_source=C2,baseline_source=B2,asset_sha256=assets,decks=bridges,projection_rule='Only oracle_text excluded, because CardDatabase.cpp explicitly treats it as cosmetic; name and EVERY runtime field/parameter retained.',scope='Native apparatus differences are recorded explicitly, never hidden or turned into an assumed regression. Frozen-file mutations fail; expected differences between source versions are evidence for review.')
 write(HERE/'assets-bridge.json',bridge)
 pgo=HERE.parent/'final-pgo.json';p=read(pgo);assert p['source_tree']==C2 and sha(CURRENT/'build/PGO/mtg')==p['binary_sha256']
 prep=dict(status='PREPARED_UNSEALED_NOT_AUTHORIZED',created=datetime.datetime.now(datetime.timezone.utc).isoformat(),selection={'searched_movers':33,'ties':30,'slower':1,'faster':2,'additional_FD_identities':3,'deduplicated_controls_per_arm':36,'source_audit_games':audit['games'],'source_audit_requested_games':audit['requested_games'],'source_audit_jobs':audit['jobs']},source_audit=str(auditpath),source_audit_sha256=sha(auditpath),cases_file=str(HERE/'cases.json'),cases_sha256=sha(HERE/'cases.json'),assets_bridge=str(HERE/'assets-bridge.json'),assets_bridge_sha256=sha(HERE/'assets-bridge.json'),threads=32,environment={'MTG_FD_ORACLE':'1','MTG_FLAG_NONCONV':'1','MTG_DUMP_UNITS':'1','MTG_SLOW_GAME_MS':'1'},environment_policy='Clear every inherited MTG_* key before applying observer-only environment. No policy/blinding/cache/budget change.',arms={'current':dict(cwd=str(CURRENT),source_tree=C2,binary=str(CURRENT/'build/PGO/mtg'),binary_sha256=p['binary_sha256'],attestation=str(pgo),attestation_sha256=sha(pgo),manifest=str(HERE/'current-manifest.json'),manifest_sha256=sha(HERE/'current-manifest.json')),'baseline':dict(cwd=str(BASE),commit=COMMIT,source_tree=B2,binary=str(BASE/'build/Release/mtg'),binary_sha256=None,required='Future actual canonical Release SHA and root build receipt, never guessed',manifest=str(HERE/'baseline-manifest.json'),manifest_sha256=sha(HERE/'baseline-manifest.json'))},success_guards=['source/binary/asset identity','exact36 completed rows/full traces/units/footer per binary','diagnostic parsing/raw ambiguity'],not_success_guards=['baseline actual equals GT','current actual equals original regression','any ordinary FD existence','a benign source-native data difference'],recovery_selection='ALL recovery extras including FiveColour b160/b640/d8b0 remain UNSELECTED until exact-pair review; not in either36-job manifest.',scope='Actual legality/source-context controls only, not optional policy research, aggregate adoption or GT acceptance.')
 write(HERE/'preparation.json',prep)
 print(json.dumps({'prepared':str(HERE),'controls_per_arm':36,'normal_workers_per_binary':32,'actual_requested':(audit['games'],audit['requested_games']),'deck_bridges':len(bridges),'runtime_diffs':{k:len(v['runtime_card_differences']) for k,v in bridges.items()},'model_diffs':{k:len(v['deck_profile_model_differences']) for k,v in bridges.items()},'engines_builds_models':0}))
if __name__=='__main__':main()
