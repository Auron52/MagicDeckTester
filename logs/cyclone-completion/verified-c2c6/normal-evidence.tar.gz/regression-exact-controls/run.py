#!/usr/bin/env python3
"""Two serial native-source36-game pools, max32 workers. Seal/check never launch engines."""
import argparse,datetime,hashlib,json,os,re,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
PREP=HERE/'preparation.json';PLAN=HERE/'sealed-plan.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(v,msg):
 if not v:raise ValueError(msg)
def new(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2);f.write('\n')
def atomic(p,x):
 temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(x,indent=2)+'\n');temp.replace(p)
def git(wt,*a):return subprocess.check_output(['git','--no-optional-locks','-C',wt,*a],text=True).strip()
def guard(c):
 need(sha(c['cases_file'])==c['cases_sha256'] and sha(c['assets_bridge'])==c['assets_bridge_sha256'],'case/bridge input changed')
 need(sha(c['source_audit'])==c['source_audit_sha256'],'strict selection audit changed')
 r=read(c['baseline_build_receipt']);need(r['status']=='DONE' and r['returncode']==0 and r['source_tree']==c['arms']['baseline']['source_tree'] and r['binary_sha256']==c['arms']['baseline']['binary_sha256'],'baseline canonical build receipt differs')
 need(sha(c['baseline_build_receipt'])==c['baseline_build_receipt_sha256'],'baseline receipt changed')
 bridge=read(c['assets_bridge'])
 for label,a in c['arms'].items():
  need(git(a['cwd'],'rev-parse','HEAD:src')==a['source_tree'] and not git(a['cwd'],'status','--porcelain','--untracked-files=no','--','src'),label+' source differs/dirty')
  need(re.fullmatch('[0-9a-f]{64}',a['binary_sha256'] or '') and sha(a['binary'])==a['binary_sha256'],label+' actual executable differs')
  need(sha(a['manifest'])==a['manifest_sha256'],'manifest changed')
  for p,digest in bridge['asset_sha256'][label].items():need(sha(p)==digest,'native asset changed '+p)
  for rel,b in bridge['decks'].items():
   present=sorted(p.name for p in (Path(a['cwd'])/Path(rel).parent).iterdir() if p.is_file());need(present==b['native_directory_filenames'][label],'native model/sidecar presence changed')
 need(c['threads']==32 and len(read(c['cases_file']))==36,'wrong selected size/worker count')
 return True

def diagnostics(raw,jobs):
 text=raw.decode('utf-8');records=[];offset=0
 for line_no,line in enumerate(text.splitlines(keepends=True),1):
  data=line.encode();length=len(data)
  if '[fd-diverge]' not in line and '[nonconv]' not in line:offset+=length;continue
  count=line.count('[fd-diverge]')+line.count('[nonconv]');need(count==1,'interleaved diagnostic markers; raw retained')
  need(not any(k in line for k in ('[goldfish]','[batch]','[fd-trace]')),'interleaved unrelated log marker; raw retained')
  pairs=re.findall(r'\b([A-Za-z_][A-Za-z_0-9]*)=([^\s|]+)',line);fields={}
  for key,val in pairs:
   need(key not in fields or key in ('hand','plan'),'duplicate diagnostic field; raw retained');fields[key]=val
  kind='fd-diverge' if '[fd-diverge]' in line else 'nonconv';required={'seed','realized_win','predicted_win','proven_at_turn','leaf_est'} if kind=='fd-diverge' else {'seed','turn','verified_win_now','verified_win','proven_at_turn'}
  need(required<=set(fields),'incomplete diagnostic; raw retained');seed=int(fields['seed']);candidates=[j for j in jobs if j['seed']==seed]
  if 'job' in fields:candidates=[j for j in candidates if j['name']==fields['job']]
  need(len(candidates)==1,'ambiguous diagnostic identity; raw retained');j=candidates[0]
  if 'gi' in fields:need(int(fields['gi']) in (0,j['game_index']),'diagnostic GI neither singleton-local nor true global')
  if 'blind_salt' in fields:need(int(fields['blind_salt'])<0,'unexpected blinded control')
  records.append(dict(kind=kind,job=j['name'],actual_seed=seed,global_gi=j['game_index'],fields=fields,effective_blind_mode='ordinary (hermetic process and no job salt)',line=line_no,byte_offset=offset,raw_hex=data.hex(),raw_sha256=hashlib.sha256(data).hexdigest(),raw=line.rstrip('\n')));offset+=length
 return records

def check_results(c,label,run):
 jobs=read(c['arms'][label]['manifest'])['jobs'];stdout=(run/'batch.log').read_text();rows=re.findall(r'^(\S+): played=(\d+) avg=([\d.]+) digest=([0-9a-f]{16}) ms=(\d+) units=(\d+)$',stdout,re.M)
 need(len(rows)==36 and len({r[0] for r in rows})==36 and {r[0] for r in rows}=={j['name'] for j in jobs} and all(r[1]=='1' for r in rows),'completion coverage differs')
 need(re.findall(r'^=== BATCH done \((\d+) jobs, (\d+) games\) ===$',stdout,re.M)==[('36','36')],'missing exact36 footer')
 ds=diagnostics((run/'batch.err').read_bytes(),jobs);result={}
 for j in jobs:
  n=j['name'];gi=j['game_index'];paths={'wins':run/'wins'/(n+'.wins'),'units':run/'wins'/(n+'.units'),'trace':run/'traces'/f'{n}_gi{gi}.json'}
  w=[l.split() for l in paths['wins'].read_text().splitlines() if l.strip() and not l.startswith('#')];u=[l.split() for l in paths['units'].read_text().splitlines() if l.strip()]
  need(len(w)==len(u)==1 and len(w[0])==3 and len(u[0])==2 and w[0][0]==u[0][0]==str(gi) and int(u[0][1])>=0,'singleton wins/units identity invalid')
  t=read(paths['trace']);need(t['seed']==j['seed'] and t['gameNumber']==gi and t.get('openingHand') and t.get('mulliganSequence') and t.get('turns'),'full trace identity/state missing')
  win=int(w[0][1]);need((t['result'].get('turn',-1) if t['result'].get('winner')=='player' else -1)==win,'trace result differs from wins')
  sr=next(r for r in rows if r[0]==n);need(int(sr[5])==int(u[0][1]),'summary counter differs')
  result[n]=dict(seed=j['seed'],global_gi=gi,wins_row=' '.join(w[0]),win=win,digest=w[0][2],units=int(u[0][1]),diagnostics=[d for d in ds if d['job']==n],files={k:dict(path=str(p),sha256=sha(p)) for k,p in paths.items()})
 return {'cases':result,'diagnostics':ds,'raw_sha256':{n:sha(run/n) for n in ('batch.log','batch.err','argv.json','environment.json')},'scope':'Completion/source/identity/asset/parser checks only; actual outcomes/FD presence versus GT are observations, never success gates.'}

def launch(c,label):
 guard(c);a=c['arms'][label];run=HERE/'runs'/label;run.mkdir(parents=True,exist_ok=False);(run/'wins').mkdir();(run/'traces').mkdir()
 argv=[a['binary'],'--batch',a['manifest'],'--cards-json',str(Path(a['cwd'])/'src/cards/data/cards.json'),'--threads','32','--game-log-dir',str(run/'wins'),'--game-trace-dir',str(run/'traces')]
 env={k:v for k,v in os.environ.items() if not k.startswith('MTG_')};env.update(c['environment']);env['GIT_OPTIONAL_LOCKS']='0'
 status=dict(status='RUNNING',started=now(),source_tree=a['source_tree'],binary_sha256=a['binary_sha256'],cwd=a['cwd'],argv=argv,env=c['environment'],threads=32,timeout=None,sealed_plan_sha256=sha(PLAN));new(run/'argv.json',argv);new(run/'environment.json',c['environment']);atomic(run/'status.json',status)
 with (run/'batch.log').open('x') as out,(run/'batch.err').open('x') as err:
  child=subprocess.Popen(argv,cwd=a['cwd'],env=env,stdout=out,stderr=err);status['child_pid']=child.pid;atomic(run/'status.json',status);print(json.dumps({'arm':label,'status':'RUNNING','child_pid':child.pid,'status_file':str(run/'status.json')}),flush=True);rc=child.wait()
 status.update(status='DONE' if rc==0 else 'STOPPED',returncode=rc,finished=now());atomic(run/'status.json',status)
 if rc!=0:new(run/'STOPPED',status);raise RuntimeError('engine stopped; raw evidence retained')
 try:guard(c);result=check_results(c,label,run)
 except Exception as error:status.update(status='FAILED_VALIDATION',engine_returncode=0,returncode=2,error=repr(error));atomic(run/'status.json',status);new(run/'FAILED_VALIDATION.json',status);raise
 status.update(validation_pass=True,result=result);atomic(run/'status.json',status);new(run/'DONE',status);print(json.dumps({'arm':label,'status':'DONE','cases':36,'FD':sum(d['kind']=='fd-diverge' for d in result['diagnostics']),'NONCONV':sum(d['kind']=='nonconv' for d in result['diagnostics'])}),flush=True);return result

def compare(c,results):
 records=[]
 for case in read(c['cases_file']):
  n=case['control_job']['name'];current=results['current']['cases'][n];baseline=results['baseline']['cases'][n];ct=read(current['files']['trace']['path']);bt=read(baseline['files']['trace']['path']);keys=(set(ct)|set(bt))-{'deckId','runId'};equal=all(ct.get(k)==bt.get(k) for k in keys);first=None
  for key in ('mulliganSequence','openingHand','turns','result'):
   a=bt.get(key);b=ct.get(key)
   if a==b:continue
   if isinstance(a,list) and isinstance(b,list):
    for i in range(max(len(a),len(b))):
     av=a[i] if i<len(a) else None;bv=b[i] if i<len(b) else None
     if av!=bv:first=dict(kind=key,ordinal=i,baseline=av,current=bv);break
   else:first=dict(kind=key,baseline=a,current=b)
   break
  gt=case['GT_row'];current_reg=case['current_regression_row'];oldfd=any(d['kind']=='fd-diverge' for d in baseline['diagnostics']);newfd=any(d['kind']=='fd-diverge' for d in current['diagnostics'])
  if baseline['wins_row']==current['wins_row'] and baseline['wins_row']!=gt:verdict='EXACT_BASELINE_AND_CURRENT_AGREE_GT_DRIFT'
  elif baseline['wins_row']==current['wins_row']==gt:verdict='BOTH_REPRODUCE_GT_FINGERPRINT'
  elif baseline['wins_row']==gt:verdict='CURRENT_DIFFERS_FROM_EXACT_BASELINE_REVIEW_LEGALITY_AND_CAUSE'
  else:verdict='BOTH_NATIVE_CONTEXTS_REQUIRE_REVIEW_AGAINST_GT'
  records.append(dict(control=n,source_job=case['source_job'],reasons=case['reasons'],GT_row=gt,original_current_regression_row=current_reg,current_target_reproduces_original_regression_row=current['wins_row']==current_reg,baseline_matches_GT=baseline['wins_row']==gt,current_matches_GT=current['wins_row']==gt,current=current,baseline=baseline,exact_trace_equal_excluding_only_run_labels=equal,first_JSON_state_or_action_difference=first,classification=verdict,FD_classification=('PREEXISTING_EXACT_2C_FD' if oldfd else 'OLD_TARGET_NEGATIVE_NOT_AUTOMATIC_SOURCE_REGRESSION') if newfd else 'CURRENT_TARGET_FD_NOT_REPRODUCED_KEEP_ORIGINAL_RAW_POSITIVE'))
 return dict(source_trees={k:a['source_tree'] for k,a in c['arms'].items()},cases=records,scope='36 exact native-source controls; GT is reference evidence, not a success requirement. Cold/warm history, trace schema-only fields and unchanged actual wins do not clear a projected-win mismatch. Root must inspect legal lines/first transitions. No recoveries/adoption/GT acceptance.')

def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='action',required=True);seal=sub.add_parser('seal');seal.add_argument('--baseline-sha256',required=True);seal.add_argument('--baseline-build-receipt',type=Path,required=True);sub.add_parser('check');run=sub.add_parser('run');run.add_argument('--root-authorization',required=True);a=ap.parse_args()
 if a.action=='seal':
  c=read(PREP);c['arms']['baseline']['binary_sha256']=a.baseline_sha256;c.update(status='SEALED_AWAITING_ROOT_LAUNCH',baseline_build_receipt=str(a.baseline_build_receipt.resolve()),baseline_build_receipt_sha256=sha(a.baseline_build_receipt),runner_sha256=sha(__file__));guard(c);new(PLAN,c);print(json.dumps({'sealed_plan':str(PLAN),'sha256':sha(PLAN),'engines_launched':0}));return 0
 c=read(PLAN);need(c['runner_sha256']==sha(__file__),'runner changed after seal');guard(c)
 if a.action=='check':print('PASS sealed72games/36perarm/32workers/source/assets/parser; no engine launched');return 0
 need(a.root_authorization.strip(),'explicit root grant required after other heavy work closes');new(HERE/'ROOT-LAUNCH-GRANT.json',dict(created=now(),message=a.root_authorization,plan_sha256=sha(PLAN)));results={}
 for label in ('current','baseline'):results[label]=launch(c,label)
 report=compare(c,results);new(HERE/'comparison.json',report);print(json.dumps({'status':'DONE','comparison':str(HERE/'comparison.json'),'cases':36}));return 0
if __name__=='__main__':raise SystemExit(main())
